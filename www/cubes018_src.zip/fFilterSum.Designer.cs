﻿namespace cubes {
  partial class fFilterSum {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components=null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if(disposing&&(components!=null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.eRule=new System.Windows.Forms.TextBox();
      this.eCount=new System.Windows.Forms.TextBox();
      this.bOK=new System.Windows.Forms.Button();
      this.bCancel=new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // eRule
      // 
      this.eRule.Location=new System.Drawing.Point(12,12);
      this.eRule.Name="eRule";
      this.eRule.Size=new System.Drawing.Size(92,20);
      this.eRule.TabIndex=0;
      this.eRule.Text="32766";
      // 
      // eCount
      // 
      this.eCount.Location=new System.Drawing.Point(158,12);
      this.eCount.Name="eCount";
      this.eCount.Size=new System.Drawing.Size(67,20);
      this.eCount.TabIndex=1;
      this.eCount.Text="1";
      // 
      // bOK
      // 
      this.bOK.Location=new System.Drawing.Point(158,38);
      this.bOK.Name="bOK";
      this.bOK.Size=new System.Drawing.Size(67,21);
      this.bOK.TabIndex=3;
      this.bOK.Text="OK";
      this.bOK.UseVisualStyleBackColor=true;
      this.bOK.Click+=new System.EventHandler(this.bOK_Click);
      // 
      // bCancel
      // 
      this.bCancel.Location=new System.Drawing.Point(93,38);
      this.bCancel.Name="bCancel";
      this.bCancel.Size=new System.Drawing.Size(59,21);
      this.bCancel.TabIndex=4;
      this.bCancel.Text="Cancel";
      this.bCancel.UseVisualStyleBackColor=true;
      this.bCancel.Click+=new System.EventHandler(this.bCube_Click);
      // 
      // fnew
      // 
      this.AutoScaleDimensions=new System.Drawing.SizeF(6F,13F);
      this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize=new System.Drawing.Size(237,64);
      this.Controls.Add(this.bCancel);
      this.Controls.Add(this.bOK);
      this.Controls.Add(this.eCount);
      this.Controls.Add(this.eRule);
      this.Name="fnew";
      this.Text="Sum filter";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox eRule;
    private System.Windows.Forms.TextBox eCount;
    private System.Windows.Forms.Button bOK;
    private System.Windows.Forms.Button bCancel;
  }
}