﻿namespace cubes {
  partial class fmain {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components=null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if(disposing&&(components!=null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmain));
      this.menu = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileNew = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileOpen = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileSave = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilePrintPage = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilePrint = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.mFileExportOff = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileExportBmp = new System.Windows.Forms.ToolStripMenuItem();
      this.mFileExportSVG = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
      this.mFileViewMesh = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.mFileExit = new System.Windows.Forms.ToolStripMenuItem();
      this.mEdit = new System.Windows.Forms.ToolStripMenuItem();
      this.mEditUndo = new System.Windows.Forms.ToolStripMenuItem();
      this.mEditRedo = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.mEditCut = new System.Windows.Forms.ToolStripMenuItem();
      this.mEditCopy = new System.Windows.Forms.ToolStripMenuItem();
      this.mEditPaste = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.mEditDelete = new System.Windows.Forms.ToolStripMenuItem();
      this.operationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.mOpFloodFill = new System.Windows.Forms.ToolStripMenuItem();
      this.mOpExtend = new System.Windows.Forms.ToolStripMenuItem();
      this.mOpDoubleSize = new System.Windows.Forms.ToolStripMenuItem();
      this.mOpHalfSize = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
      this.mOpMirrorX = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilter = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterNot = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterBoundary = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterExpand = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterImpand = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterSum = new System.Windows.Forms.ToolStripMenuItem();
      this.mMesh = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewMesh = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshRotoid = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
      this.mMeshRelax = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshTriangulation = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshPrecise = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshScale = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
      this.mMeshCutY = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshReverse = new System.Windows.Forms.ToolStripMenuItem();
      this.mView = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshWires = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewWireFron = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewFaceFilter = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterReset = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterFast = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterBack = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterLevels = new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterUpper = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
      this.mFilterInvert = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewCross = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewAnaglyph = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewCrossEye = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
      this.mMeshColor = new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshLight = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewNormalRGB = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewNormalRadial = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewShadows = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewFullscreen = new System.Windows.Forms.ToolStripMenuItem();
      this.mCamera = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewReset = new System.Windows.Forms.ToolStripMenuItem();
      this.miViewCenter = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewAlign = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewHeadReset = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewBodyReset = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewHeadOnly = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewResolution = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes640w = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes1280w = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes1920w = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewRes320 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes480 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes640 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes800 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes1024 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes1280 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRes1600 = new System.Windows.Forms.ToolStripMenuItem();
      this.mViewRecord = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
      this.mViewPovrayCamera = new System.Windows.Forms.ToolStripMenuItem();
      this.mHelp = new System.Windows.Forms.ToolStripMenuItem();
      this.mHelpHelp = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
      this.mHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
      this.bZUp = new System.Windows.Forms.Button();
      this.eZ = new System.Windows.Forms.TextBox();
      this.bZDown = new System.Windows.Forms.Button();
      this.eSize = new System.Windows.Forms.TextBox();
      this.ePen = new System.Windows.Forms.TextBox();
      this.bFill3D = new System.Windows.Forms.Button();
      this.bPen = new System.Windows.Forms.Button();
      this.bFill2D = new System.Windows.Forms.Button();
      this.bAutoSize = new System.Windows.Forms.Button();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.pControl = new System.Windows.Forms.Panel();
      this.eY = new System.Windows.Forms.TextBox();
      this.eX = new System.Windows.Forms.TextBox();
      this.bCyl = new System.Windows.Forms.Button();
      this.bBox = new System.Windows.Forms.Button();
      this.bMesh = new System.Windows.Forms.Button();
      this.bRotoid = new System.Windows.Forms.Button();
      this.bMirrY = new System.Windows.Forms.Button();
      this.bMirrX = new System.Windows.Forms.Button();
      this.tZ = new System.Windows.Forms.TrackBar();
      this.lPen = new System.Windows.Forms.Label();
      this.eRotoidCount = new System.Windows.Forms.TextBox();
      this.bDeletePlaneY = new System.Windows.Forms.Button();
      this.bDeletePlaneX = new System.Windows.Forms.Button();
      this.bDeletePlaneZ = new System.Windows.Forms.Button();
      this.bInsertPlaneY = new System.Windows.Forms.Button();
      this.bInsertPlaneX = new System.Windows.Forms.Button();
      this.bInsertPlaneZ = new System.Windows.Forms.Button();
      this.bMirrZ = new System.Windows.Forms.Button();
      this.bRotXN = new System.Windows.Forms.Button();
      this.bRotXP = new System.Windows.Forms.Button();
      this.bRotZN = new System.Windows.Forms.Button();
      this.bRotYP = new System.Windows.Forms.Button();
      this.bRotZP = new System.Windows.Forms.Button();
      this.bRotYN = new System.Windows.Forms.Button();
      this.pMain = new System.Windows.Forms.Panel();
      this.menu.SuspendLayout();
      this.pControl.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tZ)).BeginInit();
      this.SuspendLayout();
      // 
      // menu
      // 
      this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mEdit,
            this.operationToolStripMenuItem,
            this.mFilter,
            this.mMesh,
            this.mView,
            this.mCamera,
            this.mHelp});
      this.menu.Location = new System.Drawing.Point(0, 0);
      this.menu.Name = "menu";
      this.menu.Size = new System.Drawing.Size(632, 24);
      this.menu.TabIndex = 0;
      this.menu.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFileNew,
            this.mFileOpen,
            this.mFileSave,
            this.mFileSaveAs,
            this.mFilePrintPage,
            this.mFilePrint,
            this.toolStripSeparator1,
            this.mFileExportOff,
            this.mFileExportBmp,
            this.mFileExportSVG,
            this.toolStripSeparator8,
            this.mFileViewMesh,
            this.toolStripSeparator2,
            this.mFileExit});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // mFileNew
      // 
      this.mFileNew.Image = global::cubes.Properties.Resources._new;
      this.mFileNew.Name = "mFileNew";
      this.mFileNew.Size = new System.Drawing.Size(187, 22);
      this.mFileNew.Text = "New";
      this.mFileNew.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
      // 
      // mFileOpen
      // 
      this.mFileOpen.Image = global::cubes.Properties.Resources.open;
      this.mFileOpen.Name = "mFileOpen";
      this.mFileOpen.Size = new System.Drawing.Size(187, 22);
      this.mFileOpen.Text = "&Open ...";
      this.mFileOpen.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
      // 
      // mFileSave
      // 
      this.mFileSave.Image = global::cubes.Properties.Resources.save;
      this.mFileSave.Name = "mFileSave";
      this.mFileSave.Size = new System.Drawing.Size(187, 22);
      this.mFileSave.Text = "Save";
      this.mFileSave.Click += new System.EventHandler(this.mFileSave_Click);
      // 
      // mFileSaveAs
      // 
      this.mFileSaveAs.Name = "mFileSaveAs";
      this.mFileSaveAs.Size = new System.Drawing.Size(187, 22);
      this.mFileSaveAs.Text = "Save as ...";
      this.mFileSaveAs.Click += new System.EventHandler(this.mFileSaveAs_Click);
      // 
      // mFilePrintPage
      // 
      this.mFilePrintPage.Name = "mFilePrintPage";
      this.mFilePrintPage.Size = new System.Drawing.Size(187, 22);
      this.mFilePrintPage.Text = "Page ...";
      this.mFilePrintPage.Click += new System.EventHandler(this.mFilePage_Click);
      // 
      // mFilePrint
      // 
      this.mFilePrint.Image = global::cubes.Properties.Resources.print;
      this.mFilePrint.Name = "mFilePrint";
      this.mFilePrint.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
      this.mFilePrint.Size = new System.Drawing.Size(187, 22);
      this.mFilePrint.Text = "&Print";
      this.mFilePrint.Click += new System.EventHandler(this.mFilePrint_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(184, 6);
      // 
      // mFileExportOff
      // 
      this.mFileExportOff.Image = global::cubes.Properties.Resources.export;
      this.mFileExportOff.Name = "mFileExportOff";
      this.mFileExportOff.Size = new System.Drawing.Size(187, 22);
      this.mFileExportOff.Text = "Export mesh ...";
      this.mFileExportOff.Click += new System.EventHandler(this.mFileExportOff_Click);
      // 
      // mFileExportBmp
      // 
      this.mFileExportBmp.Image = global::cubes.Properties.Resources.exportbmp;
      this.mFileExportBmp.Name = "mFileExportBmp";
      this.mFileExportBmp.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D2)));
      this.mFileExportBmp.Size = new System.Drawing.Size(187, 22);
      this.mFileExportBmp.Text = "Export bmp ...";
      this.mFileExportBmp.Click += new System.EventHandler(this.mFileExportBmp_Click);
      // 
      // mFileExportSVG
      // 
      this.mFileExportSVG.Name = "mFileExportSVG";
      this.mFileExportSVG.Size = new System.Drawing.Size(187, 22);
      this.mFileExportSVG.Text = "Export vector ...";
      this.mFileExportSVG.Click += new System.EventHandler(this.mFileExportVector_Click);
      // 
      // toolStripSeparator8
      // 
      this.toolStripSeparator8.Name = "toolStripSeparator8";
      this.toolStripSeparator8.Size = new System.Drawing.Size(184, 6);
      // 
      // mFileViewMesh
      // 
      this.mFileViewMesh.Image = global::cubes.Properties.Resources.viewmesh;
      this.mFileViewMesh.Name = "mFileViewMesh";
      this.mFileViewMesh.Size = new System.Drawing.Size(187, 22);
      this.mFileViewMesh.Text = "View mesh ...";
      this.mFileViewMesh.Click += new System.EventHandler(this.mFileViewMesh_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(184, 6);
      // 
      // mFileExit
      // 
      this.mFileExit.Name = "mFileExit";
      this.mFileExit.Size = new System.Drawing.Size(187, 22);
      this.mFileExit.Text = "Exit";
      this.mFileExit.Click += new System.EventHandler(this.mFileExit_Click);
      // 
      // mEdit
      // 
      this.mEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mEditUndo,
            this.mEditRedo,
            this.toolStripSeparator3,
            this.mEditCut,
            this.mEditCopy,
            this.mEditPaste,
            this.toolStripSeparator4,
            this.mEditDelete});
      this.mEdit.Name = "mEdit";
      this.mEdit.Size = new System.Drawing.Size(39, 20);
      this.mEdit.Text = "&Edit";
      // 
      // mEditUndo
      // 
      this.mEditUndo.Image = global::cubes.Properties.Resources.undo;
      this.mEditUndo.Name = "mEditUndo";
      this.mEditUndo.Size = new System.Drawing.Size(107, 22);
      this.mEditUndo.Text = "&Undo";
      this.mEditUndo.Click += new System.EventHandler(this.bEditUndo_Click);
      // 
      // mEditRedo
      // 
      this.mEditRedo.Enabled = false;
      this.mEditRedo.Image = global::cubes.Properties.Resources.redo;
      this.mEditRedo.Name = "mEditRedo";
      this.mEditRedo.Size = new System.Drawing.Size(107, 22);
      this.mEditRedo.Text = "&Redo";
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(104, 6);
      // 
      // mEditCut
      // 
      this.mEditCut.Name = "mEditCut";
      this.mEditCut.Size = new System.Drawing.Size(107, 22);
      this.mEditCut.Text = "Cut";
      this.mEditCut.Click += new System.EventHandler(this.mEditCut_Click);
      // 
      // mEditCopy
      // 
      this.mEditCopy.Name = "mEditCopy";
      this.mEditCopy.Size = new System.Drawing.Size(107, 22);
      this.mEditCopy.Text = "Copy";
      this.mEditCopy.Click += new System.EventHandler(this.mEditCopy_Click);
      // 
      // mEditPaste
      // 
      this.mEditPaste.Name = "mEditPaste";
      this.mEditPaste.Size = new System.Drawing.Size(107, 22);
      this.mEditPaste.Text = "Paste";
      this.mEditPaste.Click += new System.EventHandler(this.mEditPaste_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(104, 6);
      // 
      // mEditDelete
      // 
      this.mEditDelete.Name = "mEditDelete";
      this.mEditDelete.Size = new System.Drawing.Size(107, 22);
      this.mEditDelete.Text = "Delete";
      this.mEditDelete.Click += new System.EventHandler(this.mEditDelete_Click);
      // 
      // operationToolStripMenuItem
      // 
      this.operationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mOpFloodFill,
            this.mOpExtend,
            this.mOpDoubleSize,
            this.mOpHalfSize,
            this.toolStripSeparator7,
            this.mOpMirrorX});
      this.operationToolStripMenuItem.Name = "operationToolStripMenuItem";
      this.operationToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
      this.operationToolStripMenuItem.Text = "&Operation";
      // 
      // mOpFloodFill
      // 
      this.mOpFloodFill.Name = "mOpFloodFill";
      this.mOpFloodFill.Size = new System.Drawing.Size(168, 22);
      this.mOpFloodFill.Text = "Flood fill";
      // 
      // mOpExtend
      // 
      this.mOpExtend.Name = "mOpExtend";
      this.mOpExtend.Size = new System.Drawing.Size(168, 22);
      this.mOpExtend.Text = "Extend";
      this.mOpExtend.Click += new System.EventHandler(this.mFilterExtend_Click);
      // 
      // mOpDoubleSize
      // 
      this.mOpDoubleSize.Name = "mOpDoubleSize";
      this.mOpDoubleSize.Size = new System.Drawing.Size(168, 22);
      this.mOpDoubleSize.Text = "Double size";
      this.mOpDoubleSize.Click += new System.EventHandler(this.mOpDoubleSize_Click);
      // 
      // mOpHalfSize
      // 
      this.mOpHalfSize.Name = "mOpHalfSize";
      this.mOpHalfSize.Size = new System.Drawing.Size(168, 22);
      this.mOpHalfSize.Text = "Half size";
      this.mOpHalfSize.Click += new System.EventHandler(this.mOpHalfSize_Click);
      // 
      // toolStripSeparator7
      // 
      this.toolStripSeparator7.Name = "toolStripSeparator7";
      this.toolStripSeparator7.Size = new System.Drawing.Size(165, 6);
      // 
      // mOpMirrorX
      // 
      this.mOpMirrorX.Name = "mOpMirrorX";
      this.mOpMirrorX.Size = new System.Drawing.Size(168, 22);
      this.mOpMirrorX.Text = "Mirror left->right ";
      this.mOpMirrorX.Click += new System.EventHandler(this.mOpMirrorX_Click);
      // 
      // mFilter
      // 
      this.mFilter.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFilterNot,
            this.mFilterBoundary,
            this.mFilterExpand,
            this.mFilterImpand,
            this.mFilterSum});
      this.mFilter.Name = "mFilter";
      this.mFilter.Size = new System.Drawing.Size(45, 20);
      this.mFilter.Text = "Fi&lter";
      // 
      // mFilterNot
      // 
      this.mFilterNot.Image = global::cubes.Properties.Resources.not;
      this.mFilterNot.Name = "mFilterNot";
      this.mFilterNot.Size = new System.Drawing.Size(125, 22);
      this.mFilterNot.Text = "Not";
      this.mFilterNot.Click += new System.EventHandler(this.mFilterNot_Click);
      // 
      // mFilterBoundary
      // 
      this.mFilterBoundary.Image = global::cubes.Properties.Resources.boundary;
      this.mFilterBoundary.Name = "mFilterBoundary";
      this.mFilterBoundary.Size = new System.Drawing.Size(125, 22);
      this.mFilterBoundary.Text = "Boundary";
      this.mFilterBoundary.Click += new System.EventHandler(this.mFilterBoundary_Click);
      // 
      // mFilterExpand
      // 
      this.mFilterExpand.Image = global::cubes.Properties.Resources.expand;
      this.mFilterExpand.Name = "mFilterExpand";
      this.mFilterExpand.Size = new System.Drawing.Size(125, 22);
      this.mFilterExpand.Text = "Expand";
      this.mFilterExpand.Click += new System.EventHandler(this.mFilterExpand_Click);
      // 
      // mFilterImpand
      // 
      this.mFilterImpand.Image = global::cubes.Properties.Resources.impand;
      this.mFilterImpand.Name = "mFilterImpand";
      this.mFilterImpand.Size = new System.Drawing.Size(125, 22);
      this.mFilterImpand.Text = "Impand";
      this.mFilterImpand.Click += new System.EventHandler(this.mFilterImpand_Click);
      // 
      // mFilterSum
      // 
      this.mFilterSum.Enabled = false;
      this.mFilterSum.Name = "mFilterSum";
      this.mFilterSum.Size = new System.Drawing.Size(125, 22);
      this.mFilterSum.Text = "Sum";
      this.mFilterSum.Visible = false;
      this.mFilterSum.Click += new System.EventHandler(this.mFilterSum_Click);
      // 
      // mMesh
      // 
      this.mMesh.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mViewMesh,
            this.mMeshRotoid,
            this.toolStripSeparator17,
            this.mMeshRelax,
            this.mMeshTriangulation,
            this.mMeshPrecise,
            this.mMeshScale,
            this.toolStripSeparator10,
            this.mMeshCutY,
            this.mMeshReverse});
      this.mMesh.Name = "mMesh";
      this.mMesh.Size = new System.Drawing.Size(48, 20);
      this.mMesh.Text = "&Mesh";
      // 
      // mViewMesh
      // 
      this.mViewMesh.Image = global::cubes.Properties.Resources.mesh;
      this.mViewMesh.Name = "mViewMesh";
      this.mViewMesh.Size = new System.Drawing.Size(162, 22);
      this.mViewMesh.Text = "&Mesh (M)";
      this.mViewMesh.Click += new System.EventHandler(this.mViewMesh_Click);
      // 
      // mMeshRotoid
      // 
      this.mMeshRotoid.Image = global::cubes.Properties.Resources.rotoid;
      this.mMeshRotoid.Name = "mMeshRotoid";
      this.mMeshRotoid.Size = new System.Drawing.Size(162, 22);
      this.mMeshRotoid.Text = "Rotoid (O)";
      this.mMeshRotoid.Click += new System.EventHandler(this.mMeshRotoid_Click);
      // 
      // toolStripSeparator17
      // 
      this.toolStripSeparator17.Name = "toolStripSeparator17";
      this.toolStripSeparator17.Size = new System.Drawing.Size(159, 6);
      // 
      // mMeshRelax
      // 
      this.mMeshRelax.Name = "mMeshRelax";
      this.mMeshRelax.Size = new System.Drawing.Size(162, 22);
      this.mMeshRelax.Text = "&Relax (R)";
      this.mMeshRelax.Click += new System.EventHandler(this.mMeshRelax_Click);
      // 
      // mMeshTriangulation
      // 
      this.mMeshTriangulation.Image = global::cubes.Properties.Resources.triangulation;
      this.mMeshTriangulation.Name = "mMeshTriangulation";
      this.mMeshTriangulation.Size = new System.Drawing.Size(162, 22);
      this.mMeshTriangulation.Text = "&Triangulation (T)";
      this.mMeshTriangulation.Click += new System.EventHandler(this.mMeshTriangulation_Click);
      // 
      // mMeshPrecise
      // 
      this.mMeshPrecise.Image = global::cubes.Properties.Resources.precise;
      this.mMeshPrecise.Name = "mMeshPrecise";
      this.mMeshPrecise.Size = new System.Drawing.Size(162, 22);
      this.mMeshPrecise.Text = "&Precise (P)";
      this.mMeshPrecise.Click += new System.EventHandler(this.mMeshPrecise_Click);
      // 
      // mMeshScale
      // 
      this.mMeshScale.Name = "mMeshScale";
      this.mMeshScale.Size = new System.Drawing.Size(162, 22);
      this.mMeshScale.Text = "&Scale";
      this.mMeshScale.Click += new System.EventHandler(this.mMeshScale_Click);
      // 
      // toolStripSeparator10
      // 
      this.toolStripSeparator10.Name = "toolStripSeparator10";
      this.toolStripSeparator10.Size = new System.Drawing.Size(159, 6);
      // 
      // mMeshCutY
      // 
      this.mMeshCutY.Name = "mMeshCutY";
      this.mMeshCutY.Size = new System.Drawing.Size(162, 22);
      this.mMeshCutY.Text = "Cut Y";
      this.mMeshCutY.Click += new System.EventHandler(this.mMeshCutY_Click);
      // 
      // mMeshReverse
      // 
      this.mMeshReverse.Name = "mMeshReverse";
      this.mMeshReverse.Size = new System.Drawing.Size(162, 22);
      this.mMeshReverse.Text = "Reverse";
      this.mMeshReverse.Click += new System.EventHandler(this.mMeshReverse_Click);
      // 
      // mView
      // 
      this.mView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMeshWires,
            this.mViewWireFron,
            this.mViewFaceFilter,
            this.mViewCross,
            this.mViewAnaglyph,
            this.mViewCrossEye,
            this.toolStripSeparator13,
            this.mMeshColor,
            this.mMeshLight,
            this.mViewNormalRGB,
            this.mViewNormalRadial,
            this.toolStripSeparator16,
            this.mViewShadows,
            this.toolStripSeparator6,
            this.mViewFullscreen});
      this.mView.Name = "mView";
      this.mView.Size = new System.Drawing.Size(44, 20);
      this.mView.Text = "&View";
      // 
      // mMeshWires
      // 
      this.mMeshWires.Checked = true;
      this.mMeshWires.CheckState = System.Windows.Forms.CheckState.Checked;
      this.mMeshWires.Name = "mMeshWires";
      this.mMeshWires.Size = new System.Drawing.Size(152, 22);
      this.mMeshWires.Tag = "ViewWires";
      this.mMeshWires.Text = "Wires";
      this.mMeshWires.Click += new System.EventHandler(this.Command_Click);
      // 
      // mViewWireFron
      // 
      this.mViewWireFron.Name = "mViewWireFron";
      this.mViewWireFron.Size = new System.Drawing.Size(152, 22);
      this.mViewWireFron.Tag = "ViewWireFron";
      this.mViewWireFron.Text = "Wire front";
      this.mViewWireFron.Click += new System.EventHandler(this.Command_Click);
      // 
      // mViewFaceFilter
      // 
      this.mViewFaceFilter.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFilterReset,
            this.mFilterFast,
            this.mFilterBack,
            this.mFilterLevels,
            this.mFilterUpper,
            this.toolStripSeparator5,
            this.mFilterInvert});
      this.mViewFaceFilter.Name = "mViewFaceFilter";
      this.mViewFaceFilter.Size = new System.Drawing.Size(152, 22);
      this.mViewFaceFilter.Text = "&Face filter";
      // 
      // mFilterReset
      // 
      this.mFilterReset.Name = "mFilterReset";
      this.mFilterReset.Size = new System.Drawing.Size(152, 22);
      this.mFilterReset.Tag = "FilterReset";
      this.mFilterReset.Text = "&Reset";
      this.mFilterReset.Click += new System.EventHandler(this.Command_Click);
      // 
      // mFilterFast
      // 
      this.mFilterFast.Name = "mFilterFast";
      this.mFilterFast.Size = new System.Drawing.Size(152, 22);
      this.mFilterFast.Tag = "FilterFast";
      this.mFilterFast.Text = "&Fast";
      this.mFilterFast.Click += new System.EventHandler(this.Command_Click);
      // 
      // mFilterBack
      // 
      this.mFilterBack.Name = "mFilterBack";
      this.mFilterBack.Size = new System.Drawing.Size(152, 22);
      this.mFilterBack.Tag = "FilterBack";
      this.mFilterBack.Text = "&Back";
      this.mFilterBack.Click += new System.EventHandler(this.Command_Click);
      // 
      // mFilterLevels
      // 
      this.mFilterLevels.Name = "mFilterLevels";
      this.mFilterLevels.Size = new System.Drawing.Size(152, 22);
      this.mFilterLevels.Tag = "FilterLevels";
      this.mFilterLevels.Text = "&Levels";
      this.mFilterLevels.Click += new System.EventHandler(this.Command_Click);
      // 
      // mFilterUpper
      // 
      this.mFilterUpper.Name = "mFilterUpper";
      this.mFilterUpper.Size = new System.Drawing.Size(152, 22);
      this.mFilterUpper.Tag = "FilterUpper";
      this.mFilterUpper.Text = "&Upper";
      this.mFilterUpper.Click += new System.EventHandler(this.Command_Click);
      // 
      // toolStripSeparator5
      // 
      this.toolStripSeparator5.Name = "toolStripSeparator5";
      this.toolStripSeparator5.Size = new System.Drawing.Size(149, 6);
      // 
      // mFilterInvert
      // 
      this.mFilterInvert.Name = "mFilterInvert";
      this.mFilterInvert.Size = new System.Drawing.Size(152, 22);
      this.mFilterInvert.Tag = "FilterInvert";
      this.mFilterInvert.Text = "Invert";
      this.mFilterInvert.Click += new System.EventHandler(this.Command_Click);
      // 
      // mViewCross
      // 
      this.mViewCross.Name = "mViewCross";
      this.mViewCross.Size = new System.Drawing.Size(152, 22);
      this.mViewCross.Text = "&Cross";
      this.mViewCross.Click += new System.EventHandler(this.mViewCross_Click);
      // 
      // mViewAnaglyph
      // 
      this.mViewAnaglyph.Image = global::cubes.Properties.Resources.anaglyph;
      this.mViewAnaglyph.Name = "mViewAnaglyph";
      this.mViewAnaglyph.Size = new System.Drawing.Size(152, 22);
      this.mViewAnaglyph.Text = "Anaglyph";
      this.mViewAnaglyph.Click += new System.EventHandler(this.mViewAnaglyph_Click);
      // 
      // mViewCrossEye
      // 
      this.mViewCrossEye.Image = global::cubes.Properties.Resources.crosseye;
      this.mViewCrossEye.Name = "mViewCrossEye";
      this.mViewCrossEye.Size = new System.Drawing.Size(152, 22);
      this.mViewCrossEye.Text = "Cross eye";
      this.mViewCrossEye.Click += new System.EventHandler(this.mViewCrossEye_Click);
      // 
      // toolStripSeparator13
      // 
      this.toolStripSeparator13.Name = "toolStripSeparator13";
      this.toolStripSeparator13.Size = new System.Drawing.Size(149, 6);
      // 
      // mMeshColor
      // 
      this.mMeshColor.Name = "mMeshColor";
      this.mMeshColor.Size = new System.Drawing.Size(152, 22);
      this.mMeshColor.Text = "&Color (C)";
      this.mMeshColor.Click += new System.EventHandler(this.mMeshColor_Click);
      // 
      // mMeshLight
      // 
      this.mMeshLight.Image = global::cubes.Properties.Resources.light;
      this.mMeshLight.Name = "mMeshLight";
      this.mMeshLight.Size = new System.Drawing.Size(152, 22);
      this.mMeshLight.Text = "Light (L)";
      this.mMeshLight.Click += new System.EventHandler(this.mMeshLight_Click);
      // 
      // mViewNormalRGB
      // 
      this.mViewNormalRGB.Name = "mViewNormalRGB";
      this.mViewNormalRGB.Size = new System.Drawing.Size(152, 22);
      this.mViewNormalRGB.Text = "Normal RGB";
      this.mViewNormalRGB.Click += new System.EventHandler(this.mViewNormalRGB_Click);
      // 
      // mViewNormalRadial
      // 
      this.mViewNormalRadial.Name = "mViewNormalRadial";
      this.mViewNormalRadial.Size = new System.Drawing.Size(152, 22);
      this.mViewNormalRadial.Text = "Normal Radial";
      this.mViewNormalRadial.Click += new System.EventHandler(this.mViewNormalRadial_Click);
      // 
      // toolStripSeparator16
      // 
      this.toolStripSeparator16.Name = "toolStripSeparator16";
      this.toolStripSeparator16.Size = new System.Drawing.Size(149, 6);
      // 
      // mViewShadows
      // 
      this.mViewShadows.Image = global::cubes.Properties.Resources.shadows;
      this.mViewShadows.Name = "mViewShadows";
      this.mViewShadows.Size = new System.Drawing.Size(152, 22);
      this.mViewShadows.Text = "Shadows";
      this.mViewShadows.Click += new System.EventHandler(this.mViewShadows_Click);
      // 
      // toolStripSeparator6
      // 
      this.toolStripSeparator6.Name = "toolStripSeparator6";
      this.toolStripSeparator6.Size = new System.Drawing.Size(149, 6);
      // 
      // mViewFullscreen
      // 
      this.mViewFullscreen.Name = "mViewFullscreen";
      this.mViewFullscreen.ShortcutKeys = System.Windows.Forms.Keys.F11;
      this.mViewFullscreen.Size = new System.Drawing.Size(152, 22);
      this.mViewFullscreen.Text = "F&ullscreen";
      this.mViewFullscreen.Click += new System.EventHandler(this.mViewFullscreen_Click);
      // 
      // mCamera
      // 
      this.mCamera.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mViewReset,
            this.miViewCenter,
            this.toolStripSeparator12,
            this.mViewAlign,
            this.mViewHeadReset,
            this.mViewBodyReset,
            this.mViewHeadOnly,
            this.toolStripSeparator11,
            this.mViewResolution,
            this.mViewRecord,
            this.toolStripSeparator15,
            this.mViewPovrayCamera});
      this.mCamera.Name = "mCamera";
      this.mCamera.Size = new System.Drawing.Size(60, 20);
      this.mCamera.Text = "&Camera";
      // 
      // mViewReset
      // 
      this.mViewReset.Name = "mViewReset";
      this.mViewReset.Size = new System.Drawing.Size(152, 22);
      this.mViewReset.Text = "Reset";
      this.mViewReset.Click += new System.EventHandler(this.mViewReset_Click);
      // 
      // miViewCenter
      // 
      this.miViewCenter.Name = "miViewCenter";
      this.miViewCenter.Size = new System.Drawing.Size(152, 22);
      this.miViewCenter.Text = "&Center";
      this.miViewCenter.Click += new System.EventHandler(this.miViewCenter_Click);
      // 
      // toolStripSeparator12
      // 
      this.toolStripSeparator12.Name = "toolStripSeparator12";
      this.toolStripSeparator12.Size = new System.Drawing.Size(149, 6);
      // 
      // mViewAlign
      // 
      this.mViewAlign.Name = "mViewAlign";
      this.mViewAlign.Size = new System.Drawing.Size(152, 22);
      this.mViewAlign.Text = "&Align Y";
      this.mViewAlign.Click += new System.EventHandler(this.mViewAlign_Click);
      // 
      // mViewHeadReset
      // 
      this.mViewHeadReset.Name = "mViewHeadReset";
      this.mViewHeadReset.Size = new System.Drawing.Size(152, 22);
      this.mViewHeadReset.Text = "Head reset";
      this.mViewHeadReset.Click += new System.EventHandler(this.mViewHeadReset_Click);
      // 
      // mViewBodyReset
      // 
      this.mViewBodyReset.Name = "mViewBodyReset";
      this.mViewBodyReset.Size = new System.Drawing.Size(152, 22);
      this.mViewBodyReset.Text = "Body reset";
      this.mViewBodyReset.Click += new System.EventHandler(this.mViewBodyReset_Click);
      // 
      // mViewHeadOnly
      // 
      this.mViewHeadOnly.Name = "mViewHeadOnly";
      this.mViewHeadOnly.Size = new System.Drawing.Size(152, 22);
      this.mViewHeadOnly.Text = "Head only";
      this.mViewHeadOnly.Click += new System.EventHandler(this.mViewHeadOnly_Click);
      // 
      // toolStripSeparator11
      // 
      this.toolStripSeparator11.Name = "toolStripSeparator11";
      this.toolStripSeparator11.Size = new System.Drawing.Size(149, 6);
      // 
      // mViewResolution
      // 
      this.mViewResolution.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mViewRes640w,
            this.mViewRes1280w,
            this.mViewRes1920w,
            this.toolStripSeparator14,
            this.mViewRes320,
            this.mViewRes480,
            this.mViewRes640,
            this.mViewRes800,
            this.mViewRes1024,
            this.mViewRes1280,
            this.mViewRes1600});
      this.mViewResolution.Name = "mViewResolution";
      this.mViewResolution.Size = new System.Drawing.Size(152, 22);
      this.mViewResolution.Text = "Resolution";
      // 
      // mViewRes640w
      // 
      this.mViewRes640w.Name = "mViewRes640w";
      this.mViewRes640w.Size = new System.Drawing.Size(127, 22);
      this.mViewRes640w.Text = "640x360";
      this.mViewRes640w.Click += new System.EventHandler(this.mViewRes640w_Click);
      // 
      // mViewRes1280w
      // 
      this.mViewRes1280w.Name = "mViewRes1280w";
      this.mViewRes1280w.Size = new System.Drawing.Size(127, 22);
      this.mViewRes1280w.Text = "1280x720";
      this.mViewRes1280w.Click += new System.EventHandler(this.mViewRes1280w_Click);
      // 
      // mViewRes1920w
      // 
      this.mViewRes1920w.Name = "mViewRes1920w";
      this.mViewRes1920w.Size = new System.Drawing.Size(127, 22);
      this.mViewRes1920w.Text = "1920x1080";
      this.mViewRes1920w.Click += new System.EventHandler(this.mViewRes1920w_Click);
      // 
      // toolStripSeparator14
      // 
      this.toolStripSeparator14.Name = "toolStripSeparator14";
      this.toolStripSeparator14.Size = new System.Drawing.Size(124, 6);
      // 
      // mViewRes320
      // 
      this.mViewRes320.Name = "mViewRes320";
      this.mViewRes320.Size = new System.Drawing.Size(127, 22);
      this.mViewRes320.Text = "&320x240";
      this.mViewRes320.Click += new System.EventHandler(this.mViewRes320_Click);
      // 
      // mViewRes480
      // 
      this.mViewRes480.Name = "mViewRes480";
      this.mViewRes480.Size = new System.Drawing.Size(127, 22);
      this.mViewRes480.Text = "&480x360";
      this.mViewRes480.Click += new System.EventHandler(this.mViewRes480_Click);
      // 
      // mViewRes640
      // 
      this.mViewRes640.Name = "mViewRes640";
      this.mViewRes640.Size = new System.Drawing.Size(127, 22);
      this.mViewRes640.Text = "&640x480";
      this.mViewRes640.Click += new System.EventHandler(this.mViewRes640_Click);
      // 
      // mViewRes800
      // 
      this.mViewRes800.Name = "mViewRes800";
      this.mViewRes800.Size = new System.Drawing.Size(127, 22);
      this.mViewRes800.Text = "&800x600";
      this.mViewRes800.Click += new System.EventHandler(this.x600ToolStripMenuItem_Click);
      // 
      // mViewRes1024
      // 
      this.mViewRes1024.Name = "mViewRes1024";
      this.mViewRes1024.Size = new System.Drawing.Size(127, 22);
      this.mViewRes1024.Text = "&1024x768";
      this.mViewRes1024.Click += new System.EventHandler(this.mViewRes1024_Click);
      // 
      // mViewRes1280
      // 
      this.mViewRes1280.Name = "mViewRes1280";
      this.mViewRes1280.Size = new System.Drawing.Size(127, 22);
      this.mViewRes1280.Text = "1&280x1024";
      this.mViewRes1280.Click += new System.EventHandler(this.mViewRes1280_Click);
      // 
      // mViewRes1600
      // 
      this.mViewRes1600.Name = "mViewRes1600";
      this.mViewRes1600.Size = new System.Drawing.Size(127, 22);
      this.mViewRes1600.Text = "1600x1200";
      this.mViewRes1600.Click += new System.EventHandler(this.mViewRes1600_Click);
      // 
      // mViewRecord
      // 
      this.mViewRecord.Name = "mViewRecord";
      this.mViewRecord.Size = new System.Drawing.Size(152, 22);
      this.mViewRecord.Text = "Record";
      this.mViewRecord.Click += new System.EventHandler(this.mViewRecord_Click);
      // 
      // toolStripSeparator15
      // 
      this.toolStripSeparator15.Name = "toolStripSeparator15";
      this.toolStripSeparator15.Size = new System.Drawing.Size(149, 6);
      // 
      // mViewPovrayCamera
      // 
      this.mViewPovrayCamera.Name = "mViewPovrayCamera";
      this.mViewPovrayCamera.Size = new System.Drawing.Size(152, 22);
      this.mViewPovrayCamera.Text = "Povray camera";
      this.mViewPovrayCamera.Click += new System.EventHandler(this.mViewPovrayCamera_Click);
      // 
      // mHelp
      // 
      this.mHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mHelpHelp,
            this.toolStripSeparator9,
            this.mHelpAbout});
      this.mHelp.Name = "mHelp";
      this.mHelp.Size = new System.Drawing.Size(44, 20);
      this.mHelp.Text = "&Help";
      // 
      // mHelpHelp
      // 
      this.mHelpHelp.Name = "mHelpHelp";
      this.mHelpHelp.Size = new System.Drawing.Size(107, 22);
      this.mHelpHelp.Text = "&Help";
      this.mHelpHelp.Click += new System.EventHandler(this.mHelpHelp_Click);
      // 
      // toolStripSeparator9
      // 
      this.toolStripSeparator9.Name = "toolStripSeparator9";
      this.toolStripSeparator9.Size = new System.Drawing.Size(104, 6);
      // 
      // mHelpAbout
      // 
      this.mHelpAbout.Name = "mHelpAbout";
      this.mHelpAbout.Size = new System.Drawing.Size(107, 22);
      this.mHelpAbout.Text = "&About";
      this.mHelpAbout.Click += new System.EventHandler(this.mHelpAbout_Click);
      // 
      // bZUp
      // 
      this.bZUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bZUp.Location = new System.Drawing.Point(64, 49);
      this.bZUp.Name = "bZUp";
      this.bZUp.Size = new System.Drawing.Size(15, 19);
      this.bZUp.TabIndex = 1;
      this.bZUp.Text = "+";
      this.bZUp.UseVisualStyleBackColor = true;
      this.bZUp.Click += new System.EventHandler(this.bZUp_Click);
      // 
      // eZ
      // 
      this.eZ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eZ.Location = new System.Drawing.Point(31, 48);
      this.eZ.Name = "eZ";
      this.eZ.Size = new System.Drawing.Size(33, 20);
      this.eZ.TabIndex = 2;
      this.eZ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.eZ_KeyDown);
      // 
      // bZDown
      // 
      this.bZDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bZDown.Location = new System.Drawing.Point(16, 49);
      this.bZDown.Name = "bZDown";
      this.bZDown.Size = new System.Drawing.Size(15, 19);
      this.bZDown.TabIndex = 3;
      this.bZDown.Text = "-";
      this.bZDown.UseVisualStyleBackColor = true;
      this.bZDown.Click += new System.EventHandler(this.bZDown_Click);
      // 
      // eSize
      // 
      this.eSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eSize.Location = new System.Drawing.Point(37, 96);
      this.eSize.Name = "eSize";
      this.eSize.Size = new System.Drawing.Size(42, 20);
      this.eSize.TabIndex = 4;
      this.eSize.KeyDown += new System.Windows.Forms.KeyEventHandler(this.eSize_KeyDown);
      // 
      // ePen
      // 
      this.ePen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ePen.Location = new System.Drawing.Point(44, 70);
      this.ePen.Name = "ePen";
      this.ePen.Size = new System.Drawing.Size(34, 20);
      this.ePen.TabIndex = 5;
      this.ePen.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ePen_KeyUp);
      // 
      // bFill3D
      // 
      this.bFill3D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bFill3D.Location = new System.Drawing.Point(35, 221);
      this.bFill3D.Name = "bFill3D";
      this.bFill3D.Size = new System.Drawing.Size(42, 20);
      this.bFill3D.TabIndex = 13;
      this.bFill3D.Text = "Fill 3d";
      this.bFill3D.UseVisualStyleBackColor = true;
      this.bFill3D.Click += new System.EventHandler(this.bFill_Click);
      // 
      // bPen
      // 
      this.bPen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bPen.Location = new System.Drawing.Point(3, 175);
      this.bPen.Name = "bPen";
      this.bPen.Size = new System.Drawing.Size(77, 20);
      this.bPen.TabIndex = 14;
      this.bPen.Text = "Pen";
      this.bPen.UseVisualStyleBackColor = true;
      this.bPen.Click += new System.EventHandler(this.bPen_Click);
      // 
      // bFill2D
      // 
      this.bFill2D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bFill2D.Location = new System.Drawing.Point(5, 221);
      this.bFill2D.Name = "bFill2D";
      this.bFill2D.Size = new System.Drawing.Size(28, 20);
      this.bFill2D.TabIndex = 15;
      this.bFill2D.Text = "Fill";
      this.bFill2D.UseVisualStyleBackColor = true;
      this.bFill2D.Click += new System.EventHandler(this.bFill2D_Click);
      // 
      // bAutoSize
      // 
      this.bAutoSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bAutoSize.Location = new System.Drawing.Point(21, 97);
      this.bAutoSize.Name = "bAutoSize";
      this.bAutoSize.Size = new System.Drawing.Size(16, 19);
      this.bAutoSize.TabIndex = 17;
      this.bAutoSize.Text = "a";
      this.bAutoSize.UseVisualStyleBackColor = true;
      this.bAutoSize.Click += new System.EventHandler(this.bAutoSize_Click);
      // 
      // timer
      // 
      this.timer.Enabled = true;
      this.timer.Tick += new System.EventHandler(this.timer_Tick);
      // 
      // pControl
      // 
      this.pControl.Controls.Add(this.eY);
      this.pControl.Controls.Add(this.eX);
      this.pControl.Controls.Add(this.bCyl);
      this.pControl.Controls.Add(this.bBox);
      this.pControl.Controls.Add(this.bMesh);
      this.pControl.Controls.Add(this.bRotoid);
      this.pControl.Controls.Add(this.bMirrY);
      this.pControl.Controls.Add(this.bMirrX);
      this.pControl.Controls.Add(this.tZ);
      this.pControl.Controls.Add(this.lPen);
      this.pControl.Controls.Add(this.eRotoidCount);
      this.pControl.Controls.Add(this.bDeletePlaneY);
      this.pControl.Controls.Add(this.bDeletePlaneX);
      this.pControl.Controls.Add(this.bDeletePlaneZ);
      this.pControl.Controls.Add(this.bInsertPlaneY);
      this.pControl.Controls.Add(this.bInsertPlaneX);
      this.pControl.Controls.Add(this.bInsertPlaneZ);
      this.pControl.Controls.Add(this.bZUp);
      this.pControl.Controls.Add(this.eZ);
      this.pControl.Controls.Add(this.bAutoSize);
      this.pControl.Controls.Add(this.bZDown);
      this.pControl.Controls.Add(this.bMirrZ);
      this.pControl.Controls.Add(this.bRotXN);
      this.pControl.Controls.Add(this.bFill2D);
      this.pControl.Controls.Add(this.eSize);
      this.pControl.Controls.Add(this.bPen);
      this.pControl.Controls.Add(this.ePen);
      this.pControl.Controls.Add(this.bFill3D);
      this.pControl.Controls.Add(this.bRotXP);
      this.pControl.Controls.Add(this.bRotZN);
      this.pControl.Controls.Add(this.bRotYP);
      this.pControl.Controls.Add(this.bRotZP);
      this.pControl.Controls.Add(this.bRotYN);
      this.pControl.Dock = System.Windows.Forms.DockStyle.Right;
      this.pControl.Location = new System.Drawing.Point(551, 24);
      this.pControl.Name = "pControl";
      this.pControl.Size = new System.Drawing.Size(81, 529);
      this.pControl.TabIndex = 19;
      // 
      // eY
      // 
      this.eY.AcceptsReturn = true;
      this.eY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eY.Location = new System.Drawing.Point(41, 3);
      this.eY.Name = "eY";
      this.eY.ReadOnly = true;
      this.eY.Size = new System.Drawing.Size(38, 20);
      this.eY.TabIndex = 37;
      // 
      // eX
      // 
      this.eX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eX.Location = new System.Drawing.Point(1, 3);
      this.eX.Name = "eX";
      this.eX.ReadOnly = true;
      this.eX.Size = new System.Drawing.Size(38, 20);
      this.eX.TabIndex = 36;
      // 
      // bCyl
      // 
      this.bCyl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCyl.Location = new System.Drawing.Point(37, 198);
      this.bCyl.Name = "bCyl";
      this.bCyl.Size = new System.Drawing.Size(29, 20);
      this.bCyl.TabIndex = 35;
      this.bCyl.Text = "Cyl";
      this.bCyl.UseVisualStyleBackColor = true;
      this.bCyl.Click += new System.EventHandler(this.bPen_Click);
      // 
      // bBox
      // 
      this.bBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bBox.Location = new System.Drawing.Point(3, 198);
      this.bBox.Name = "bBox";
      this.bBox.Size = new System.Drawing.Size(33, 20);
      this.bBox.TabIndex = 34;
      this.bBox.Text = "Box";
      this.bBox.UseVisualStyleBackColor = true;
      this.bBox.Click += new System.EventHandler(this.bPen_Click);
      // 
      // bMesh
      // 
      this.bMesh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bMesh.Image = global::cubes.Properties.Resources.mesh;
      this.bMesh.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bMesh.Location = new System.Drawing.Point(3, 335);
      this.bMesh.Name = "bMesh";
      this.bMesh.Size = new System.Drawing.Size(24, 24);
      this.bMesh.TabIndex = 33;
      this.bMesh.UseVisualStyleBackColor = true;
      this.bMesh.Click += new System.EventHandler(this.bMesh_Click);
      // 
      // bRotoid
      // 
      this.bRotoid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotoid.Image = global::cubes.Properties.Resources.rotoid;
      this.bRotoid.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotoid.Location = new System.Drawing.Point(30, 335);
      this.bRotoid.Name = "bRotoid";
      this.bRotoid.Size = new System.Drawing.Size(24, 24);
      this.bRotoid.TabIndex = 32;
      this.bRotoid.UseVisualStyleBackColor = true;
      this.bRotoid.Click += new System.EventHandler(this.bRotoid_Click);
      // 
      // bMirrY
      // 
      this.bMirrY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bMirrY.Image = global::cubes.Properties.Resources.y_mirror;
      this.bMirrY.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bMirrY.Location = new System.Drawing.Point(30, 246);
      this.bMirrY.Name = "bMirrY";
      this.bMirrY.Size = new System.Drawing.Size(24, 24);
      this.bMirrY.TabIndex = 31;
      this.bMirrY.UseVisualStyleBackColor = true;
      this.bMirrY.Click += new System.EventHandler(this.bMirrY_Click);
      // 
      // bMirrX
      // 
      this.bMirrX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bMirrX.Image = global::cubes.Properties.Resources.x_mirror;
      this.bMirrX.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bMirrX.Location = new System.Drawing.Point(4, 246);
      this.bMirrX.Name = "bMirrX";
      this.bMirrX.Size = new System.Drawing.Size(24, 24);
      this.bMirrX.TabIndex = 30;
      this.bMirrX.UseVisualStyleBackColor = true;
      this.bMirrX.Click += new System.EventHandler(this.bMirrX_Click);
      // 
      // tZ
      // 
      this.tZ.AutoSize = false;
      this.tZ.Location = new System.Drawing.Point(2, 27);
      this.tZ.Maximum = 32;
      this.tZ.Name = "tZ";
      this.tZ.Size = new System.Drawing.Size(76, 20);
      this.tZ.TabIndex = 0;
      this.tZ.TabStop = false;
      this.tZ.TickStyle = System.Windows.Forms.TickStyle.None;
      this.tZ.Value = 32;
      this.tZ.Scroll += new System.EventHandler(this.tZ_Scroll);
      // 
      // lPen
      // 
      this.lPen.AutoSize = true;
      this.lPen.Location = new System.Drawing.Point(3, 73);
      this.lPen.Name = "lPen";
      this.lPen.Size = new System.Drawing.Size(26, 13);
      this.lPen.TabIndex = 29;
      this.lPen.Text = "Pen";
      // 
      // eRotoidCount
      // 
      this.eRotoidCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eRotoidCount.Location = new System.Drawing.Point(56, 339);
      this.eRotoidCount.Name = "eRotoidCount";
      this.eRotoidCount.Size = new System.Drawing.Size(25, 20);
      this.eRotoidCount.TabIndex = 27;
      this.eRotoidCount.Text = "9";
      this.eRotoidCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // bDeletePlaneY
      // 
      this.bDeletePlaneY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneY.Image = global::cubes.Properties.Resources.y_remove;
      this.bDeletePlaneY.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bDeletePlaneY.Location = new System.Drawing.Point(29, 305);
      this.bDeletePlaneY.Name = "bDeletePlaneY";
      this.bDeletePlaneY.Size = new System.Drawing.Size(24, 24);
      this.bDeletePlaneY.TabIndex = 26;
      this.bDeletePlaneY.UseVisualStyleBackColor = true;
      this.bDeletePlaneY.Click += new System.EventHandler(this.bDeletePlaneY_Click);
      // 
      // bDeletePlaneX
      // 
      this.bDeletePlaneX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneX.Image = global::cubes.Properties.Resources.x_remove;
      this.bDeletePlaneX.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bDeletePlaneX.Location = new System.Drawing.Point(3, 305);
      this.bDeletePlaneX.Name = "bDeletePlaneX";
      this.bDeletePlaneX.Size = new System.Drawing.Size(24, 24);
      this.bDeletePlaneX.TabIndex = 25;
      this.bDeletePlaneX.UseVisualStyleBackColor = true;
      this.bDeletePlaneX.Click += new System.EventHandler(this.bDeletePlaneX_Click);
      // 
      // bDeletePlaneZ
      // 
      this.bDeletePlaneZ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneZ.Image = global::cubes.Properties.Resources.z_remove;
      this.bDeletePlaneZ.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bDeletePlaneZ.Location = new System.Drawing.Point(56, 305);
      this.bDeletePlaneZ.Name = "bDeletePlaneZ";
      this.bDeletePlaneZ.Size = new System.Drawing.Size(24, 24);
      this.bDeletePlaneZ.TabIndex = 24;
      this.bDeletePlaneZ.UseVisualStyleBackColor = true;
      this.bDeletePlaneZ.Click += new System.EventHandler(this.bDeletePlaneZ_Click);
      // 
      // bInsertPlaneY
      // 
      this.bInsertPlaneY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneY.Image = global::cubes.Properties.Resources.y_insert;
      this.bInsertPlaneY.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bInsertPlaneY.Location = new System.Drawing.Point(29, 273);
      this.bInsertPlaneY.Name = "bInsertPlaneY";
      this.bInsertPlaneY.Size = new System.Drawing.Size(24, 24);
      this.bInsertPlaneY.TabIndex = 22;
      this.bInsertPlaneY.UseVisualStyleBackColor = true;
      this.bInsertPlaneY.Click += new System.EventHandler(this.bInsertPlaneY_Click);
      // 
      // bInsertPlaneX
      // 
      this.bInsertPlaneX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneX.Image = global::cubes.Properties.Resources.x_insert;
      this.bInsertPlaneX.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bInsertPlaneX.Location = new System.Drawing.Point(3, 273);
      this.bInsertPlaneX.Name = "bInsertPlaneX";
      this.bInsertPlaneX.Size = new System.Drawing.Size(24, 24);
      this.bInsertPlaneX.TabIndex = 21;
      this.bInsertPlaneX.UseVisualStyleBackColor = true;
      this.bInsertPlaneX.Click += new System.EventHandler(this.bInsertPlaneX_Click);
      // 
      // bInsertPlaneZ
      // 
      this.bInsertPlaneZ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneZ.Image = global::cubes.Properties.Resources.z_insert;
      this.bInsertPlaneZ.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bInsertPlaneZ.Location = new System.Drawing.Point(56, 273);
      this.bInsertPlaneZ.Name = "bInsertPlaneZ";
      this.bInsertPlaneZ.Size = new System.Drawing.Size(24, 24);
      this.bInsertPlaneZ.TabIndex = 20;
      this.bInsertPlaneZ.UseVisualStyleBackColor = true;
      this.bInsertPlaneZ.Click += new System.EventHandler(this.bInsertPlaneZ_Click);
      // 
      // bMirrZ
      // 
      this.bMirrZ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bMirrZ.Image = global::cubes.Properties.Resources.z_mirror;
      this.bMirrZ.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bMirrZ.Location = new System.Drawing.Point(56, 246);
      this.bMirrZ.Name = "bMirrZ";
      this.bMirrZ.Size = new System.Drawing.Size(24, 24);
      this.bMirrZ.TabIndex = 16;
      this.bMirrZ.UseVisualStyleBackColor = true;
      this.bMirrZ.Click += new System.EventHandler(this.bMirrZ_Click);
      // 
      // bRotXN
      // 
      this.bRotXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotXN.Image = global::cubes.Properties.Resources.x_rot_0;
      this.bRotXN.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotXN.Location = new System.Drawing.Point(29, 145);
      this.bRotXN.Name = "bRotXN";
      this.bRotXN.Size = new System.Drawing.Size(24, 24);
      this.bRotXN.TabIndex = 7;
      this.bRotXN.UseVisualStyleBackColor = true;
      this.bRotXN.Click += new System.EventHandler(this.bRotXN_Click);
      // 
      // bRotXP
      // 
      this.bRotXP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotXP.Image = global::cubes.Properties.Resources.x_rot_1;
      this.bRotXP.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotXP.Location = new System.Drawing.Point(29, 119);
      this.bRotXP.Name = "bRotXP";
      this.bRotXP.Size = new System.Drawing.Size(24, 24);
      this.bRotXP.TabIndex = 6;
      this.bRotXP.UseVisualStyleBackColor = true;
      this.bRotXP.Click += new System.EventHandler(this.bRotXP_Click);
      // 
      // bRotZN
      // 
      this.bRotZN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotZN.Image = global::cubes.Properties.Resources.z_rot_0;
      this.bRotZN.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotZN.Location = new System.Drawing.Point(55, 145);
      this.bRotZN.Name = "bRotZN";
      this.bRotZN.Size = new System.Drawing.Size(24, 24);
      this.bRotZN.TabIndex = 11;
      this.bRotZN.UseVisualStyleBackColor = true;
      this.bRotZN.Click += new System.EventHandler(this.bRotZN_Click);
      // 
      // bRotYP
      // 
      this.bRotYP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotYP.Image = global::cubes.Properties.Resources.y_rot_1;
      this.bRotYP.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotYP.Location = new System.Drawing.Point(3, 119);
      this.bRotYP.Name = "bRotYP";
      this.bRotYP.Size = new System.Drawing.Size(24, 24);
      this.bRotYP.TabIndex = 8;
      this.bRotYP.UseVisualStyleBackColor = true;
      this.bRotYP.Click += new System.EventHandler(this.bRotYP_Click);
      // 
      // bRotZP
      // 
      this.bRotZP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotZP.Image = global::cubes.Properties.Resources.z_rot_1;
      this.bRotZP.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotZP.Location = new System.Drawing.Point(3, 145);
      this.bRotZP.Name = "bRotZP";
      this.bRotZP.Size = new System.Drawing.Size(24, 24);
      this.bRotZP.TabIndex = 10;
      this.bRotZP.UseVisualStyleBackColor = true;
      this.bRotZP.Click += new System.EventHandler(this.bRotZP_Click);
      // 
      // bRotYN
      // 
      this.bRotYN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRotYN.Image = global::cubes.Properties.Resources.y_rot_0;
      this.bRotYN.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
      this.bRotYN.Location = new System.Drawing.Point(55, 119);
      this.bRotYN.Name = "bRotYN";
      this.bRotYN.Size = new System.Drawing.Size(24, 24);
      this.bRotYN.TabIndex = 9;
      this.bRotYN.UseVisualStyleBackColor = true;
      this.bRotYN.Click += new System.EventHandler(this.bRotYN_Click);
      // 
      // pMain
      // 
      this.pMain.AutoScroll = true;
      this.pMain.CausesValidation = false;
      this.pMain.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pMain.Location = new System.Drawing.Point(0, 24);
      this.pMain.Margin = new System.Windows.Forms.Padding(0);
      this.pMain.Name = "pMain";
      this.pMain.Size = new System.Drawing.Size(551, 529);
      this.pMain.TabIndex = 20;
      this.pMain.Scroll += new System.Windows.Forms.ScrollEventHandler(this.pMain_Scroll);
      this.pMain.Paint += new System.Windows.Forms.PaintEventHandler(this.fmain_Paint);
      this.pMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pMain_MouseDoubleClick);
      this.pMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pMain_MouseDown);
      this.pMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pMain_MouseMove);
      this.pMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pMain_MouseUp);
      this.pMain.Resize += new System.EventHandler(this.pMain_Resize);
      // 
      // fmain
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CausesValidation = false;
      this.ClientSize = new System.Drawing.Size(632, 553);
      this.Controls.Add(this.pMain);
      this.Controls.Add(this.pControl);
      this.Controls.Add(this.menu);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MainMenuStrip = this.menu;
      this.Name = "fmain";
      this.Text = "cubes";
      this.menu.ResumeLayout(false);
      this.menu.PerformLayout();
      this.pControl.ResumeLayout(false);
      this.pControl.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tZ)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menu;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem mFileNew;
    private System.Windows.Forms.ToolStripMenuItem mFileOpen;
    private System.Windows.Forms.ToolStripMenuItem mFileSave;
    private System.Windows.Forms.ToolStripMenuItem mFileSaveAs;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem mFileExportOff;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripMenuItem mFileExit;
    private System.Windows.Forms.ToolStripMenuItem mEdit;
    private System.Windows.Forms.ToolStripMenuItem mEditCut;
    private System.Windows.Forms.ToolStripMenuItem mEditCopy;
    private System.Windows.Forms.ToolStripMenuItem mEditPaste;
    private System.Windows.Forms.ToolStripMenuItem operationToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem mOpFloodFill;
    private System.Windows.Forms.ToolStripMenuItem mOpDoubleSize;
    private System.Windows.Forms.ToolStripMenuItem mOpHalfSize;
    private System.Windows.Forms.ToolStripMenuItem mFilter;
    private System.Windows.Forms.ToolStripMenuItem mFilterNot;
    private System.Windows.Forms.ToolStripMenuItem mOpExtend;
    private System.Windows.Forms.ToolStripMenuItem mFilterBoundary;
    private System.Windows.Forms.ToolStripMenuItem mFilterExpand;
    private System.Windows.Forms.ToolStripMenuItem mFilterImpand;
    private System.Windows.Forms.ToolStripMenuItem mFilterSum;
    private System.Windows.Forms.Button bZUp;
    private System.Windows.Forms.TextBox eZ;
    private System.Windows.Forms.Button bZDown;
    private System.Windows.Forms.TextBox eSize;
    private System.Windows.Forms.TextBox ePen;
    private System.Windows.Forms.ToolStripMenuItem mEditUndo;
    private System.Windows.Forms.ToolStripMenuItem mEditRedo;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.Button bRotXP;
    private System.Windows.Forms.Button bRotXN;
    private System.Windows.Forms.Button bRotYN;
    private System.Windows.Forms.Button bRotYP;
    private System.Windows.Forms.Button bRotZN;
    private System.Windows.Forms.Button bRotZP;
    private System.Windows.Forms.Button bFill3D;
    private System.Windows.Forms.Button bPen;
    private System.Windows.Forms.Button bFill2D;
    private System.Windows.Forms.Button bMirrZ;
    private System.Windows.Forms.Button bAutoSize;
    private System.Windows.Forms.Timer timer;
    private System.Windows.Forms.ToolStripMenuItem mFileExportBmp;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripMenuItem mEditDelete;
    private System.Windows.Forms.ToolStripMenuItem mMesh;
    private System.Windows.Forms.ToolStripMenuItem mFileExportSVG;
    private System.Windows.Forms.ToolStripMenuItem mFilePrint;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
    private System.Windows.Forms.ToolStripMenuItem mFileViewMesh;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
    private System.Windows.Forms.Panel pControl;
    private System.Windows.Forms.Panel pMain;
    private System.Windows.Forms.Button bInsertPlaneZ;
    private System.Windows.Forms.Button bInsertPlaneY;
    private System.Windows.Forms.Button bInsertPlaneX;
    private System.Windows.Forms.Button bDeletePlaneY;
    private System.Windows.Forms.Button bDeletePlaneX;
    private System.Windows.Forms.Button bDeletePlaneZ;
    private System.Windows.Forms.ToolStripMenuItem mMeshTriangulation;
    private System.Windows.Forms.ToolStripMenuItem mMeshPrecise;
    private System.Windows.Forms.ToolStripMenuItem mMeshScale;
    private System.Windows.Forms.ToolStripMenuItem mMeshRotoid;
    private System.Windows.Forms.TextBox eRotoidCount;
    private System.Windows.Forms.Label lPen;
    private System.Windows.Forms.ToolStripMenuItem mMeshRelax;
    private System.Windows.Forms.ToolStripMenuItem mHelp;
    private System.Windows.Forms.ToolStripMenuItem mHelpHelp;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
    private System.Windows.Forms.ToolStripMenuItem mHelpAbout;
    private System.Windows.Forms.TrackBar tZ;
    private System.Windows.Forms.Button bMirrX;
    private System.Windows.Forms.Button bMirrY;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
    private System.Windows.Forms.ToolStripMenuItem mMeshCutY;
    private System.Windows.Forms.Button bRotoid;
    private System.Windows.Forms.Button bMesh;
    private System.Windows.Forms.ToolStripMenuItem mMeshReverse;
    private System.Windows.Forms.ToolStripMenuItem mView;
    private System.Windows.Forms.ToolStripMenuItem mMeshWires;
    private System.Windows.Forms.ToolStripMenuItem mViewWireFron;
    private System.Windows.Forms.ToolStripMenuItem mViewAnaglyph;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
    private System.Windows.Forms.ToolStripMenuItem mMeshColor;
    private System.Windows.Forms.ToolStripMenuItem mMeshLight;
    private System.Windows.Forms.ToolStripMenuItem mViewNormalRGB;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    private System.Windows.Forms.ToolStripMenuItem mViewAlign;
    private System.Windows.Forms.ToolStripMenuItem mViewFullscreen;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
    private System.Windows.Forms.ToolStripMenuItem mViewPovrayCamera;
    private System.Windows.Forms.ToolStripMenuItem mViewCross;
    private System.Windows.Forms.ToolStripMenuItem mViewHeadOnly;
    private System.Windows.Forms.ToolStripMenuItem mViewHeadReset;
    private System.Windows.Forms.ToolStripMenuItem mViewBodyReset;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
    private System.Windows.Forms.ToolStripMenuItem mViewResolution;
    private System.Windows.Forms.ToolStripMenuItem mViewRes640w;
    private System.Windows.Forms.ToolStripMenuItem mViewRes1280w;
    private System.Windows.Forms.ToolStripMenuItem mViewRes1920w;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
    private System.Windows.Forms.ToolStripMenuItem mViewRes320;
    private System.Windows.Forms.ToolStripMenuItem mViewRes480;
    private System.Windows.Forms.ToolStripMenuItem mViewRes640;
    private System.Windows.Forms.ToolStripMenuItem mViewRes800;
    private System.Windows.Forms.ToolStripMenuItem mViewRes1024;
    private System.Windows.Forms.ToolStripMenuItem mViewRes1280;
    private System.Windows.Forms.ToolStripMenuItem mViewRes1600;
    private System.Windows.Forms.ToolStripMenuItem mViewRecord;
    private System.Windows.Forms.ToolStripMenuItem mCamera;
    private System.Windows.Forms.ToolStripMenuItem mViewReset;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
    private System.Windows.Forms.ToolStripMenuItem mViewNormalRadial;
    private System.Windows.Forms.ToolStripMenuItem mViewShadows;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
    private System.Windows.Forms.ToolStripMenuItem mViewMesh;
    private System.Windows.Forms.Button bBox;
    private System.Windows.Forms.Button bCyl;
    private System.Windows.Forms.TextBox eX;
    private System.Windows.Forms.TextBox eY;
    private System.Windows.Forms.ToolStripMenuItem mViewCrossEye;
    private System.Windows.Forms.ToolStripMenuItem miViewCenter;
    private System.Windows.Forms.ToolStripMenuItem mOpMirrorX;
    private System.Windows.Forms.ToolStripMenuItem mFilePrintPage;
    private System.Windows.Forms.ToolStripMenuItem mViewFaceFilter;
    private System.Windows.Forms.ToolStripMenuItem mFilterFast;
    private System.Windows.Forms.ToolStripMenuItem mFilterBack;
    private System.Windows.Forms.ToolStripMenuItem mFilterReset;
    private System.Windows.Forms.ToolStripMenuItem mFilterLevels;
    private System.Windows.Forms.ToolStripMenuItem mFilterUpper;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
    private System.Windows.Forms.ToolStripMenuItem mFilterInvert;
  }
}

