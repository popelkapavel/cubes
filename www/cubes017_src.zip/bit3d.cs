﻿using System;
using System.IO;
using Mesh3d;

namespace Math3d {
  public enum bit_op {
    Zero=0
    ,One=1
    ,Not=2
    ,And=3
    ,Or=4
    ,Xor=5
    ,AndN=6
    ,Copy=7
  }
  public delegate double Delegate3DToD(double x,double y,double z);
  public delegate bool DelegateDToB(double x);
  public delegate void DelegateLinePoint(StreamWriter sw,double x,double y,double z);
  public delegate void DelegateLineQuad(StreamWriter sw,int a,int b,int c,int d);
  public class bit3d {
     public int dx,dy,dz;
     uint[] bit;
     int dpl; //dwords per line
          
     public bit3d() {}
     public static int size(int dx,int dy,int dz) {
       return (((dx+31)&~31)>>5)*dy*dz;
     }
     void offset_mask(out int offset,out uint mask,int x,int y,int z) {
       mask=(uint)(1<<(x&31));
       offset=dpl*(y+dy*z)+(x>>5);
     }
     public void alloc(int dx) {alloc(dx,dx,dx);}
     public void alloc(int dx,int dy,int dz) {
       bit=new uint[size(dx,dy,dz)];
       this.dx=dx;this.dy=dy;this.dz=dz;
       dpl=((dx+31)>>5);
     }
     public bit3d Clone() {
       bit3d n=new bit3d();
       n.alloc(dx,dy,dz);
       n.operation(bit_op.Copy,0,0,0,this,0,0,0,dx,dy,dz);
       return n;
     }
     public void swap(bit3d dst) { 
       int r;
       r=dx;dx=dst.dx;dst.dx=r;
       r=dy;dy=dst.dy;dst.dy=r;
       r=dz;dz=dst.dz;dst.dz=r;
       r=dpl;dpl=dst.dpl;dst.dpl=r;
       uint[] r2;
       r2=bit;bit=dst.bit;dst.bit=r2;
     }
     public void set(int x,int y,int z,bool bit) {
       int offset;
       uint mask;
       offset_mask(out offset,out mask,x,y,z);
       this.bit[offset]=(this.bit[offset]&~mask)|(bit?mask:0);
     }
     public bool get(int x,int y,int z) {
       int offset;
       uint mask;
       offset_mask(out offset,out mask,x,y,z);
       return 0!=(bit[offset]&mask);
     }
     public bool get2(int x,int y,int z) {
      if(x<0||x>=dx||y<0||y>=dy||z<0||z>=dz)
        return false;     
       int offset;
       uint mask;
       offset_mask(out offset,out mask,x,y,z);
       return 0!=(bit[offset]&mask);
     }
     public bool flip(int x,int y,int z) {
      if(x<0||x>=dx||y<0||y>=dy||z<0||z>=dz)
        return false;     
       int offset;
       uint mask;
       offset_mask(out offset,out mask,x,y,z);
       return ((bit[offset]^=mask)&mask)!=0;
     }
     public void clear(bool b) {
       uint x=b?0xffffffff:0x0;
       for(int i=0;i<bit.Length;i++)
         bit[i]=x;       
     }
     public long bits() {
       //int[] b16=new int[] {0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4};
       long p=0; 
       for(int i=0;i<bit.Length;i++) {
         uint u=bit[i],m=1,up=0;
         while(m!=0) {
           if(0!=(u&m)) up++;
           m<<=1; 
         }
         p+=up;
       }
       return p;
     }
     public void boundary() {
       bit3d tmp=new bit3d();
       int x,y,z;
       
       tmp.alloc(dx+2,dy+2,dz+2);
       tmp.copy(1,1,1,this,0,0,0,dx,dy,dz);
       clear(false);
       for(z=1;z<=dz;z++)
         for(y=1;y<=dy;y++)
           for(x=1;x<=dx;x++)
             if(tmp.get(x,y,z)&&!(
                 tmp.get(x,y,z-1)&&tmp.get(x,y,z+1)
                 &&tmp.get(x,y-1,z)&&tmp.get(x,y+1,z)
                 &&tmp.get(x-1,y,z)&&tmp.get(x+1,y,z)))
               set(x-1,y-1,z-1,true);  // nastaveni pouze okrajovych bitu
       
     }
     public void expand() {
       bit3d tmp=new bit3d();
       int x,y,z;
       tmp.alloc(dx+2,dy+2,dz+2);
       tmp.clear(false);
       tmp.operation(bit_op.Copy,1,1,1,this,0,0,0,dx,dy,dz);
       for(z=1;z<=dz;z++)
         for(y=1;y<=dy;y++)
           for(x=1;x<=dx;x++)
             if(tmp.get(x,y,z)||tmp.get(x,y,z-1)||tmp.get(x,y,z+1)
                 ||tmp.get(x,y-1,z)||tmp.get(x,y+1,z)
                 ||tmp.get(x-1,y,z)||tmp.get(x+1,y,z))
               set(x-1,y-1,z-1,true);  // nastaveni pouze okrajovych bitu
     }
     
     public void inv() {
       for(int i=0;i<bit.Length;i++)
         bit[i]=~bit[i];
     }
     static public bool operation(bit_op op,bool a,bool b) {
       switch(op) {
        case bit_op.Zero:return false;
        case bit_op.One:return true;
        case bit_op.Not:return !a;
        case bit_op.And:return a&&b;
        case bit_op.AndN:return a&&!b;
        case bit_op.Or:return a||b;
        case bit_op.Xor:return a^b;
        case bit_op.Copy:return b;
        default:return false;
      }
     }
     static public uint operation(bit_op op,uint a,uint b) {
       switch(op) {
        case bit_op.Zero:return 0u;
        case bit_op.One:return ~0u;
        case bit_op.Not:return ~a;
        case bit_op.And:return a&b;
        case bit_op.AndN:return a&~b;
        case bit_op.Or:return a|b;
        case bit_op.Xor:return a^b;
        case bit_op.Copy:return b;
        default:return 0;
      }
     }
     public bool operation(bit_op op,int x,int y,int z,bool b) {
       int offset;
       uint mask;
       offset_mask(out offset,out mask,x,y,z);
       bool a=(bit[offset]&mask)!=0;
       bool c=operation(op,a,b);
       if(c!=a) bit[offset]^=mask;
       return a;       
     }
     void clip_low(int min,ref int x,int smin,ref int sx,ref int width) {
       int r0=min-x,r1=smin-sx;
       if(r1>r0) r0=r1;
       if(r0<1) return;
       width-=r0;
       x+=r0;
       sx+=r0;
     }
     void clip_high(int max,int x,int smax,int sx,ref int width) {
       int r0=x+width-max,r1=sx+width-smax;
       if(r1>r0) r0=r1;
       if(r0>0) width-=r0;       
     }
     void clip_high(int max,int x,ref int width) {
       int r0=x+width-max;
       if(r0>0) width-=r0;       
     }
     public void Clip(int axis,ref int value,ref int length) {
       if(length<0) length=0;
       int d=axis<1?dx:axis>1?dz:dy;
       if(value+length<=0||value>=d) {
         length=0;
         return;
       }
       if(value<0) {
         length+=value;
         value=0;
       }  
       if(value+length>d)
         length=d-value;     
     }
     public void Clip(int axis,ref int v) {
       if(v<0) v=0;if(v<0) v=0;
       int d=axis<1?dx:axis>1?dz:dy;
       if(v>=d) v=d-1;
     }
     public void Clip2(int axis,ref int u,ref int v) {
       Clip(axis,ref u);
       Clip(axis,ref v);
       if(v<u) {
         int r=u;u=v;v=r;
       }       
     }
     public void Clip(ref int x0,ref int x1,ref int y0,ref int y1,ref int z0,ref int z1) {
       Clip2(0,ref x0,ref x1);
       Clip2(1,ref y0,ref y1);
       Clip2(2,ref z0,ref z1);
     }
     public void operation(bit_op op,int x,int y,int z,bit3d src,int sx,int sy,int sz,int width,int height,int depth) {
       clip_low(0,ref x,0,ref sx,ref width);
       clip_low(0,ref y,0,ref sy,ref height);
       clip_low(0,ref z,0,ref sz,ref depth);
       if(op==bit_op.Zero||op==bit_op.One||op==bit_op.Not ) {
         clip_high(dx,x,ref width);
         clip_high(dy,y,ref height);
         clip_high(dz,z,ref depth);         
       } else {
         clip_high(dx,x,src.dx,sx,ref width);
         clip_high(dy,y,src.dy,sy,ref height);
         clip_high(dz,z,src.dz,sz,ref depth);
       }  
       if(op==bit_op.Copy&&x==0&&y==0&&sx==0&&sy==0&&width==dx&&height==dy&&src.dx==dx&&src.dy==dy) {
         Array.Copy(src.bit,sz*dpl*dy,bit,z*dpl*dy,depth*dpl*dy);  
         return;
       }       
       if(op==bit_op.One||op==bit_op.Zero) {
         for(int k=0;k<depth;k++)
           for(int j=0;j<height;j++)
             for(int i=0;i<width;i++)          
               set(x+i,y+j,z+k,op==bit_op.One);
       } else if(op==bit_op.Not) {
         for(int k=0;k<depth;k++)
           for(int j=0;j<height;j++)
             for(int i=0;i<width;i++)          
               flip(x+i,y+j,z+k);         
       } else       
         for(int k=0;k<depth;k++)
           for(int j=0;j<height;j++)
             for(int i=0;i<width;i++)
               operation(op,x+i,y+j,z+k,src.get(sx+i,sy+j,sz+k));
     }
     public void copy(int x,int y,int z,bit3d src,int sx,int sy,int sz,int dx,int dy,int dz) {
       operation(bit_op.Copy,x,y,z,src,sx,sy,sz,dx,dy,dz);
     }
     public void clear(bool value,int x,int y,int z,int dx,int dy,int dz) {
       operation(value?bit_op.One:bit_op.Zero,x,y,z,null,0,0,0,dx,dy,dz);
     }     
     public void eval(double xmin,double ymin,double zmin,double xmax,double ymax,double zmax,Delegate3DToD f3d,DelegateDToB f1d) {
       double[] rx=new double[dx],ry=new double[dy];
       int x,y,z;
       for(x=0;x<dx;x++)
         rx[x]=(x*xmax+(dx-1-x)*xmin)/(dx-1);
       for(y=0;y<dy;y++)
         ry[y]=(y*ymax+(dy-1-y)*ymin)/(dy-1);
       for(z=0;z<dz;z++) {
         double rz=(z*zmax+(dz-1-z)*zmin)/(dz-1);
         for(y=0;y<dy;y++)
           for(x=0;x<dx;x++)
             set(x,y,z,f1d(f3d(rx[x],ry[y],rz)));
       }
     } 
     
     public void mirror(int axis) {
       int x,y,z,r2;
       bool r;

       switch(axis) {
        case 0:
         for(z=0;z<dz;z++)
           for(y=0;y<dy;y++)
             for(x=0,r2=dx-1;x<r2;x++,r2--) {
               r=get(x,y,z);
               set(x,y,z,get(r2,y,z));
               set(r2,y,z,r);
             }  
         break;
        case 1:
         for(z=0;z<dz;z++)
           for(y=0,r2=dy-1;y<r2;y++,r2--)
             for(x=0;x<dx;x++) {
               r=get(x,y,z);
               set(x,y,z,get(x,r2,z));
               set(x,r2,z,r);
             }               
         break;
        case 2:
         for(z=0,r2=dz-1;z<r2;z++,r2--)
           for(y=0;y<dy;y++)
             for(x=0;x<dx;x++) {
               r=get(x,y,z);
               set(x,y,z,get(x,y,r2));
               set(x,y,r2,r);
             }  
         break;
       }
     }

     public void rotate(int axis,bool dir) {
       bit3d tmp;
       int x,y,z;

       switch(axis) {
        case 0:
         tmp=new bit3d();
         tmp.alloc(dx,dz,dy);         
         for(z=0;z<dz;z++)
           for(y=0;y<dy;y++)
             if(dir)
               for(x=0;x<dx;x++)
                 tmp.set(x,z,dy-y-1,get(x,y,z));
             else
               for(x=0;x<dx;x++)
                 tmp.set(x,dz-z-1,y,get(x,y,z));
         swap(tmp);
         break;
        case 1:
         tmp=new bit3d();
         tmp.alloc(dz,dy,dx);
         for(z=0;z<dz;z++)
           for(y=0;y<dy;y++)
             if(dir) 
               for(x=0;x<dx;x++)
                  tmp.set(dz-z-1,y,x,get(x,y,z));
             else     
               for(x=0;x<dx;x++)
                  tmp.set(z,y,dx-x-1,get(x,y,z));
         swap(tmp);
         break;
        case 2:
         tmp=new bit3d();
         tmp.alloc(dy,dx,dz);
         for(z=0;z<dz;z++)
           for(y=0;y<dy;y++)
             if(dir)
               for(x=0;x<dx;x++)               
                 tmp.set(dy-y-1,x,z,get(x,y,z));
             else      
               for(x=0;x<dx;x++)               
                 tmp.set(y,dx-x-1,z,get(x,y,z));
         swap(tmp);
         break;
       }                 
     }
     internal class flood_state { internal int s,xi,xa,yi,ya,zi,za;};
     static void flood_seed(bit3d bound,bit3d fill,bool black,flood_state ns,int x,int y,int z) {
       bound.set(x,y,z,black);
       fill.set(x,y,z,black);
       if(x<ns.xi) ns.xi=x;
       if(x>ns.xa) ns.xa=x;
       if(y<ns.yi) ns.yi=y;
       if(y>ns.ya) ns.ya=y;
       if(z<ns.zi) ns.zi=z;
       if(z>ns.za) ns.za=z;
       ns.s++;
     }
     public void floodfill(int sx,int sy,int sz,bool black) {
       bit3d tmp=new bit3d();
       int x,y,z;
       flood_state os,ns=new flood_state();// old step and new step
       tmp.alloc(dx+2,dy+2,dz+2);
       tmp.clear(black);
       tmp.operation(bit_op.Copy,1,1,1,this,0,0,0,dx,dy,dz);
       alloc(dx+2,dy+2,dz+2);
       clear(!black);
       set(sx+1,sy+1,sz+1,black);
       tmp.set(sx+1,sy+1,sz+1,black);
       ns.xi=ns.xa=sx+1;
       ns.yi=ns.ya=sy+1;
       ns.zi=ns.za=sz+1;
       ns.s=1;
       while(ns.s>0) {
         os=ns;
         ns=new flood_state();
         ns.s=0;
         ns.xi=dx;ns.xa=-1;
         ns.yi=dy;ns.ya=-1;
         ns.zi=dz;ns.za=-1;
         if(os.xi<1) os.xi=0;
         if(os.xa>dx-2) os.xa=dx-2;
         if(os.yi<1) os.yi=0;
         if(os.ya>dy-2) os.ya=dy-2;
         if(os.zi<1) os.zi=0;
         if(os.za>dz-2) os.za=dz-2;
         for(z=os.zi;z<=os.za;z++) 
           for(y=os.yi;y<=os.ya;y++) 
             for(x=os.xi;x<=os.xa;x++)
               if(black==get(x,y,z)) {
                 set(x,y,z,!black);
                 if(black!=tmp.get(x-1,y,z))
                   flood_seed(this,tmp,black,ns,x-1,y,z);
                 if(black!=tmp.get(x+1,y,z))
                   flood_seed(this,tmp,black,ns,x+1,y,z);
                 if(black!=tmp.get(x,y-1,z))
                   flood_seed(this,tmp,black,ns,x,y-1,z);
                 if(black!=tmp.get(x,y+1,z))
                   flood_seed(this,tmp,black,ns,x,y+1,z);
                 if(black!=tmp.get(x,y,z-1))
                   flood_seed(this,tmp,black,ns,x,y,z-1);
                 if(black!=tmp.get(x,y,z+1))
                   flood_seed(this,tmp,black,ns,x,y,z+1);
               }
       }
       alloc(dx-2,dy-2,dz-2);
       operation(bit_op.Copy,0,0,0,tmp,1,1,1,dx,dy,dz);
     }
    public void floodfill2d(int sx,int sy,int sz,bool black) {
      bit3d tmp=new bit3d();
       tmp.alloc(dx,dy,1);
       tmp.clear(true);
       tmp.operation(bit_op.Copy,0,0,0,this,0,0,sz,dx,dy,1);
       tmp.floodfill(sx,sy,0,black);
       operation(bit_op.Copy,0,0,sz,tmp,0,0,0,dx,dy,1);
    }               
    public void resize(int nx,int ny,int nz) {
      int x,y,z,z2;
      int[] x2=new int[nx],y2=new int [ny];
      bit3d tmp=new bit3d();
      tmp.alloc(nx,ny,nz);
      for(y=0;y<ny;y++)
        y2[y]=y*dy/ny;
      for(x=0;x<nx;x++)
        x2[x]=x*dx/nx;  
      for(z=0;z<nz;z++) {
        z2=z*dz/nz;
        for(y=0;y<ny;y++)
          for(x=0;x<nx;x++) 
            tmp.set(x,y,z,get(x2[x],y2[y],z2));
      }
      swap(tmp);
    }
    public void extend(bool bit,int size) {
      int x,y,z;
      bit3d tmp=new bit3d();
      tmp.alloc(dx+2*size,dy+2*size,dz+2*size);
      tmp.clear(bit);
      for(z=0;z<dz;z++) 
        for(y=0;y<dy;y++)
          for(x=0;x<dx;x++) 
            tmp.set(x+size,y+size,z+size,get(x,y,z));
      swap(tmp);
    }
    public void insertplane(int axis,int d) {
      if(d<0) return;
      if(axis==2) {
        if(d>=dz) return;
        dz++;
        uint[] bit2=new uint[size(dx,dy,dz)];
        int h=dpl*dy*(d+1),he=bit2.Length;
        while(h<he) {
          he--;
          bit2[he]=bit[he-dpl*dy];
        }  
        Array.Copy(bit,bit2,h);
        bit=bit2;
      } else if(axis==1) {
        if(d>dy) return;
        dy++;
        uint[] bit2=new uint[size(dx,dy,dz)];
        int h=dpl*d,g=h+dpl,b=dpl*dy;
        Array.Copy(bit,0,bit2,0,g);
        for(int z=1;z<dz;z++) {
          Array.Copy(bit,h,bit2,g,b);
          h+=b-dpl;
          g+=b;
        }  
        Array.Copy(bit,h,bit2,g,(dy-d-1)*dpl);        
        bit=bit2;
      } else {
        if(d>dx) return;
        dx++;
        if((dx&31)==1) {
          uint[] bit2=new uint[size(dx,dy,dz)];
          int h=0,g=0;
          while(g<bit2.Length) {
            switch(dpl) {
             case 1:bit2[g++]=bit[h++];break;
             case 2:bit2[g++]=bit[h++];bit2[g++]=bit[h++];break;
             default:
              for(int x=0;x<dpl;x++) bit2[g++]=bit[h++];
              break;
            }  
            bit2[g++]=0;
          }  
          dpl++;
          bit=bit2;
        }
        int nl=d>>5,nr=dpl-nl-1;
        int m=1<<(d&31),ml=m|(m-1),mr=~ml|m;
        for(int p=bit.Length-1;p>=0;p-=nl) {
          for(int n=nr;n>0;n--) {
            bit[p]=(uint)((bit[p]<<1)|((bit[p-1]&0x80000000)==0?0:1));
            p--;
          }
          bit[p]=(uint)(((bit[p]&mr)<<1)|(bit[p]&ml));
          p--;
       }
      }
    }
    public void deleteplane(int axis,int d) {
      if(d<0) return;
      if(axis==2) {  
        if(d>=dz) return;      
        for(int h=dpl*dy*(d+1);h<bit.Length;h++)
          bit[h-dpl*dy]=bit[h];
        dz--;
        Array.Resize(ref bit,size(dx,dy,dz));
      } else if(axis==1) {
        if(d>=dy) return;
        int b=dy-1,g=dpl*d,h=g+dpl,he=dpl*dy*dz;
        while(h<he) {
          for(int n=dpl;n>0;n--) 
            bit[g++]=bit[h++];
          b--;  
          if(b==0) {
            b=dy-1;
            h+=dpl;
          }
        }
        //Array.Copy(bit,g,bit,h,(dy-d-1)*dpl);
        dy--;        
        Array.Resize(ref bit,size(dx,dy,dz));
      } else {
        if(d>=dx) return;
        dx--;
        int nl=d>>5,nr=dpl-nl-1;
        int m=1<<(d&31),ml=(m-1),mr=~ml&~m;
        int pe=dpl*dy*dz;
        for(int p=0;p<bit.Length;) {
          p+=nl;
          bit[p]=(uint)(((bit[p]&mr)>>1)|(bit[p]&ml)|(nr<1?0:(bit[p+1]&1)==0?0:0x80000000));
          p++;
          for(int n=nr;n-->0;p++)
            bit[p]=(uint)((bit[p]>>1)|(n<1?0:(bit[p+1]&1)==0?0:0x80000000));
        }
        if((dx&31)==0) {
          int h=0,g=0;
          dpl--;
          for(int yz=dy*dz;yz>0;yz--) {
            switch(dpl) {
             case 1:bit[g++]=bit[h++];break;
             case 2:bit[g++]=bit[h++];bit[g++]=bit[h++];break;
             default:for(int x=dpl;x>0;x--) bit[g++]=bit[h++];break;
            }
            h++;
          }
          Array.Resize(ref bit,size(dx,dy,dz));
        }
      }
    }        
    public void random(double p,Random rnd) {
      int x,y,z,l=(int)(p*int.MaxValue);
      if(rnd==null) rnd=new Random();
      for(z=0;z<dz;z++)
        for(y=0;y<dy;y++)
          for(x=0;x<dx;x++)
            set(x,y,z,l>rnd.Next());      
    }
    public void sumfilter(int rule) {
      bit3d tmp=new bit3d();
      int x,y,z;
      int x2,y2,z2,s;
      tmp.alloc(dx+2,dy+2,dz+2);
      tmp.clear(false);
      tmp.operation(bit_op.Copy,1,1,1,this,0,0,0,dx,dy,dz);
      for(z=0;z<dz;z++)
        for(y=0;y<dy;y++)
          for(x=0;x<dx;x++) {
            s=0;
            for(z2=0;z2<=2;z2++)
              for(y2=0;y2<=2;y2++)
                for(x2=0;x2<=2;x2++)
                  if(tmp.get(x+x2,y+y2,z+z2))
                    s++;
            set(x,y,z,((1<<s)&rule)!=0);
          } 
      return;
    }
    public void open(string filename) {
      BinaryReader br=null;
     try { br=new BinaryReader(new FileStream(filename,FileMode.Open,FileAccess.Read));
      int i0=br.ReadInt32(),i1=br.ReadInt32(),i2=br.ReadInt32(),i3=br.ReadInt32();
      if(i3==0) {
        dx=i0;dy=i1;dz=i2;
      } else {
        dx=i1;dy=i2;dz=i3;
      }
      alloc(dx,dy,dz);
      for(int i=0;i<bit.Length;i++)
        bit[i]=br.ReadUInt32();
      br.Close();
      br=null;
     } finally {
       if(br!=null) br.Close();
     } 
    }
    public void save(string filename) {       
      FileStream fs=new FileStream(filename,FileMode.OpenOrCreate,FileAccess.Write);
      BinaryWriter bw=new BinaryWriter(fs);
      bw.Write(0x627563);//cub\0 
      bw.Write(dx);
      bw.Write(dy);
      bw.Write(dz);
      //bw.Write(0);
      for(int i=0;i<bit.Length;i++)
        bw.Write(bit[i]);
      bw.Flush();
      fs.SetLength(fs.Position);
      bw.Close();
    }
    void PTS_MIRROR(int[] pts,int x,int y) {
      int r=pts[y];
      pts[y]=pts[x];
      pts[x]=r;
    }
    void cube_mirror(int[] pts,int axis,ref byte mask) {
      switch(axis) {
       case 0: // x
        PTS_MIRROR(pts,0,2);PTS_MIRROR(pts,4,7);PTS_MIRROR(pts,5,6);PTS_MIRROR(pts,8,10);
        mask=(byte)(((mask&0x11)<<3)|((mask&0x22)<<1)|((mask&0x44)>>1)|((mask&0x88)>>3));
       break;
       case 1: // y
        PTS_MIRROR(pts,1,3);PTS_MIRROR(pts,4,5);PTS_MIRROR(pts,6,7);PTS_MIRROR(pts,9,11);
        mask=(byte)(((mask&0x11)<<1)|((mask&0x22)>>1)|((mask&0x44)<<1)|((mask&0x88)>>1));
       break;
       case 2: // z
        PTS_MIRROR(pts,0,8);PTS_MIRROR(pts,1,9);PTS_MIRROR(pts,2,10);PTS_MIRROR(pts,3,11);
        mask=(byte)(((mask&0x0f)<<4)|((mask&0xf0)>>4));
       break;
       case 3: // x+y
        PTS_MIRROR(pts,0,1);PTS_MIRROR(pts,2,3);PTS_MIRROR(pts,4,6);PTS_MIRROR(pts,8,9);PTS_MIRROR(pts,10,11);
        mask=(byte)((mask&0xaa)|((mask&0x11)<<2)|((mask&0x44)>>2));
       break;
       case 4: // x-y
        PTS_MIRROR(pts,0,3);PTS_MIRROR(pts,1,2);PTS_MIRROR(pts,5,7);PTS_MIRROR(pts,8,11);PTS_MIRROR(pts,9,10);
        mask=(byte)((mask&0x55)|((mask&0x22)<<2)|((mask&0x88)>>2));
       break;
      }            
    }
    void bitrotate(ref byte mask,byte[] rot,byte[] rot2) {
      byte m=mask,m2=0;
      if(0!=(m&rot[0])) m2|=rot[3];
      if(0!=(m&rot[1])) m2|=rot[0];
      if(0!=(m&rot[2])) m2|=rot[1];
      if(0!=(m&rot[3])) m2|=rot[2];
      if(0!=(m&rot2[0])) m2|=rot2[3];
      if(0!=(m&rot2[1])) m2|=rot2[0];
      if(0!=(m&rot2[2])) m2|=rot2[1];
      if(0!=(m&rot2[3])) m2|=rot2[2];
      mask=m2;
    } 
    void PTS_ROTATE(int[] pts,int a,int b,int c,int d) {
      int r=pts[a];
      pts[a]=pts[b];
      pts[b]=pts[c];
      pts[c]=pts[d];
      pts[d]=r;
    }  
    void PTS_SWAP(int[] pts,int a,int b) {
      int r=pts[a];
      pts[a]=pts[b];
      pts[b]=r;
    }
    static byte[] xrot=new byte[] {1,16,128,8},xrot2=new byte[] {2,32,64,4};
    static byte[] yrot=new byte[] {1,2,32,16},yrot2=new byte[] {8,4,64,128};
    static byte[] zrot=new byte[] {1,2,4,8},zrot2=new byte[] {16,32,64,128};

    void cube_rotate(int[] pts,int axis,ref byte mask) {
      switch(axis) {
       case 0: // x
        PTS_ROTATE(pts,0,8,10,2);PTS_ROTATE(pts,1,5,9,6);PTS_ROTATE(pts,3,4,11,7);
        bitrotate(ref mask,xrot,xrot2); 
        break;
       case 1: // y
        PTS_ROTATE(pts,0,5,8,4);PTS_ROTATE(pts,1,9,11,3);PTS_ROTATE(pts,2,6,10,7);
        bitrotate(ref mask,yrot,yrot2);
        break;
       case 2: // z
        PTS_ROTATE(pts,0,1,2,3);PTS_ROTATE(pts,4,5,6,7);PTS_ROTATE(pts,8,9,10,11);
        bitrotate(ref mask,zrot,zrot2);
       break; 
      }
    }
           
    int max(int x,int y) {return x<y?y:x;}
    static int[] bc=new int[] {0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,7};
    int bitcount(int n) {
      return bc[n&15]+bc[n>>4];
    }    
    static void tria(mesh msh,int[] pts,bool inv,int a,int b,int c) {
      if(inv) {
        int r;
        r=a;a=c;c=r;
      }
      msh.fcs.Triangle(pts[a]-1,pts[b]-1,pts[c]-1,POINTS.None);
    }
    static void quad(mesh msh,int[] pts,bool inv,int a,int b,int c,int d) {
      if(inv) {
        int r;
        r=a;a=d;d=r;r=b;b=c;c=r;
      }
      msh.fcs.Quad(pts[a]-1,pts[b]-1,pts[c]-1,pts[d]-1,POINTS.None);
    } 
    int cube_poly(int n,byte mask,int[] pts,mesh msh) {
      int lns=0;
      bool inv=false,neg;
      int xmax,ymax,zmax;

      if((neg=n>4)) {
        mask=(byte)~mask;
        inv^=true;
        n=8-n;
      }  
      xmax=max(bitcount(mask&0xcc),bitcount(mask&0x33));
      ymax=max(bitcount(mask&0x66),bitcount(mask&0x99));
      zmax=max(bitcount(mask&0xf0),bitcount(mask&0x0f));

      if(xmax>zmax||ymax>zmax) 
        cube_rotate(pts,xmax>ymax?0:1,ref mask);
      if(bitcount(mask&0xf0)>bitcount(mask&0x0f)) {
        inv^=true;
        cube_mirror(pts,2,ref mask);
      }     
      if(mask!=15)
        while((0==(mask&1))||(0!=(mask&8)))
          cube_rotate(pts,2,ref mask); 
      if(((mask&5)==5)) {
        if((0!=(mask&64))&&(0==(mask&16))) {
          inv^=true;
          cube_mirror(pts,3,ref mask);
        }  
        if((0==(mask&2))&&(0!=(mask&128))&&(0==(mask&32))) {
          inv^=true;
          cube_mirror(pts,4,ref mask);
        }  
      }
      if((mask&15)==3) {
        byte rb0=(byte)(bitcount(mask&0x90));
        byte rb1=(byte)(bitcount(mask&0x60));
        if(rb0>rb1||(mask&0xf0)==0xa0) {
          inv^=true;
          cube_mirror(pts,1,ref mask);
        }  
      }
  
      switch(mask) {
       case 1:
        tria(msh,pts,inv,0,3,4);
        lns++;
        break;
       case 3:
        quad(msh,pts,inv,4,5,1,3);
        /* tria(lnsfile,lprf,pts,inv,4,5,1);
          tria(lnsfile,lprf,pts,inv,4,1,3); */
        lns+=1;
        break;
       case 5:
        if(neg) {
          quad(msh,pts,inv,4,6,2,3);
          quad(msh,pts,inv,6,4,0,1);
          /* tria(lnsfile,lprf,pts,inv,4,6,2);
          tria(lnsfile,lprf,pts,inv,4,2,3);
          tria(lnsfile,lprf,pts,inv,6,4,0);
          tria(lnsfile,lprf,pts,inv,6,0,1); */
          lns+=2;
        } else {
          tria(msh,pts,inv,0,3,4);
          tria(msh,pts,inv,2,1,6);
          lns+=2;
        }
        break;
       case 7:
        tria(msh,pts,inv,4,5,6);
        quad(msh,pts,inv,4,6,2,3);
        /* tria(msh,pts,inv,4,6,2);
        tria(msh,pts,inv,4,2,3); */
        lns+=2;
        break;  
       case 15:
        quad(msh,pts,inv,4,5,6,7);
        /* tria(msh,pts,inv,4,5,6);
        tria(msh,pts,inv,4,6,7); */
        lns+=1;
        break;
       case 21:
        if(neg) {
          tria(msh,pts,inv,11,2,3);
          tria(msh,pts,inv,11,6,2);
          tria(msh,pts,inv,11,8,6);
          tria(msh,pts,inv,8,1,6);
          tria(msh,pts,inv,8,0,1);
          lns+=5;
        } else {
          tria(msh,pts,inv,0,3,11);
          tria(msh,pts,inv,0,11,8);
          tria(msh,pts,inv,2,1,6);
          lns+=3;
        }
        break; 
       case 23:
        tria(msh,pts,inv,8,5,6);
        tria(msh,pts,inv,11,8,6);
        tria(msh,pts,inv,11,6,2);
        tria(msh,pts,inv,11,2,3);
        lns+=4;
        break;
       case 37:
        if(neg) {
          tria(msh,pts,inv,4,8,9);
          tria(msh,pts,inv,4,9,6);
          tria(msh,pts,inv,4,6,2);
          tria(msh,pts,inv,4,2,3);
          tria(msh,pts,inv,1,5,0);
          lns+=5;
        } else {
          tria(msh,pts,inv,0,3,4);
          tria(msh,pts,inv,2,1,6);
          tria(msh,pts,inv,5,8,9);
          lns+=3;
        }
        break; 
       case 39:
        tria(msh,pts,inv,4,6,2);
        tria(msh,pts,inv,4,2,3);
        tria(msh,pts,inv,4,8,6);
        tria(msh,pts,inv,6,8,9);
        lns+=4;
        break;
       case 65:
        tria(msh,pts,inv,0,3,4);
        tria(msh,pts,inv,9,10,6);
        lns+=2;
        break;
       case 67:
        if(neg) {
          tria(msh,pts,inv,1,3,6);
          tria(msh,pts,inv,3,10,6);
          tria(msh,pts,inv,3,4,10);
          tria(msh,pts,inv,4,9,10);
          tria(msh,pts,inv,4,5,9);
          lns+=5; 
        } else {
          tria(msh,pts,inv,4,5,1);
          tria(msh,pts,inv,4,1,3);
          tria(msh,pts,inv,6,9,10);
          lns+=3;
        }
        break;
       case 85:
        tria(msh,pts,inv,0,3,11);
        tria(msh,pts,inv,0,11,8);
        tria(msh,pts,inv,2,1,9);
        tria(msh,pts,inv,2,9,10);
        lns+=4;
        break;
       case 135:
        tria(msh,pts,inv,4,5,6);
        tria(msh,pts,inv,4,6,2);
        tria(msh,pts,inv,4,2,3);
        tria(msh,pts,inv,10,11,7);
        lns+=4;
        break;
       case 165:
        tria(msh,pts,inv,0,3,4);
        tria(msh,pts,inv,2,1,6);
        tria(msh,pts,inv,10,11,7);
        tria(msh,pts,inv,8,9,5);
        lns+=4;
        break;
       case 195:
        tria(msh,pts,inv,4,5,1);
        tria(msh,pts,inv,4,1,3);
        tria(msh,pts,inv,7,6,11);
        tria(msh,pts,inv,11,6,9);
        lns+=4;
        break;
       default: 
        //printf("mask=%d\n",mask);
        break;
      }
      return lns;
    }       
    void mesh_poly2(mesh msh,bool cyclic) {
      int i,h,g,f,x,y,z,pts2,lns2;//*h,*g,*f,*xy
      int[] gxy,xy,xy1=new int[2*dx*dy],xy2=new int[2*dx*dy],zz=new int[dx*dy];
      h=0;xy=xy1;
      lns2=pts2=0;
      for(y=0;y<dy;y++) {// create flat array
        for(x=0;x<dx-1;x++) {
          if(get(x,y,0)^get(x+1,y,0)) {
            i=++pts2;
            msh.pts.Add(2*x+1,2*y,0);
          } else 
            i=0;
          xy[h++]=i;
        }
        h++;
        if(y<dy-1) 
          for(x=0;x<dx;x++) {
            if(get(x,y+1,0)^get(x,y,0)) {
              i=++pts2;
              msh.pts.Add(2*x,2*y+1,0);
            } else 
              i=0;
            xy[h++]=i;
          }
      }
      for(z=1;z<=dz;z++) { 
        int z1=z-1,z2=z;
        if(z==dz) {
          if(!cyclic) break;
          z2=0; 
        }  
        xy=xy==xy1?xy2:xy1; // switch plates
        h=0;
        for(y=0;y<dy;y++) { // create flat array
          for(x=0;x<dx-1;x++) {
            if(get(x,y,z2)^get(x+1,y,z2)) {
              i=++pts2;
              msh.pts.Add(2*x+1,2*y,2*z);
            } else 
              i=0;
            xy[h++]=i;
          }
          h++;
          if(y<dy-1) 
            for(x=0;x<dx;x++) {
              if(get(x,y+1,z2)^get(x,y,z2)) {
                i=++pts2;
                msh.pts.Add(2*x,2*y+1,2*z);
              } else 
                i=0;
              xy[h++]=i;
            }
       }
       h=0; // make inter array
       for(y=0;y<dy;y++)
         for(x=0;x<dx;x++) {
           if(get(x,y,z1)^get(x,y,z2)) {
             i=++pts2;
             msh.pts.Add(2*x,2*y,2*z-1);
           } else 
             i=0;
           zz[h++]=i;
         }
       h=0;f=0;g=0;
       gxy=xy==xy1?xy2:xy1;
       for(y=0;y<dy-1;y++) {
         //int ci,cn;
         int[] cp=new int[12];
         byte mn,mb;
         for(x=0;x<dx-1;x++,h++,g++,f++) { // go through cubes
           mn=mb=0;
           if(get(x,y,z1)) {mn++;mb|=1;}
           if(get(x+1,y,z1)) {mn++;mb|=2;}
           if(get(x+1,y+1,z1)) {mn++;mb|=4;}
           if(get(x,y+1,z1)) {mn++;mb|=8;}
           if(get(x,y,z2)) {mn++;mb|=16;}
           if(get(x+1,y,z2)) {mn++;mb|=32;}
           if(get(x+1,y+1,z2)) {mn++;mb|=64;}
           if(get(x,y+1,z2)) {mn++;mb|=128;}
           if(mn>0&&mn<8) {
             //cn=0;
             cp[0]=gxy[g];
             cp[1]=gxy[g+dx+1];
             cp[2]=gxy[g+2*dx];
             cp[3]=gxy[g+dx];
             cp[4]=zz[f];
             cp[5]=zz[f+1];
             cp[6]=zz[f+dx+1];
             cp[7]=zz[f+dx];
             cp[8]=xy[h];
             cp[9]=xy[h+dx+1];
             cp[10]=xy[h+2*dx];
             cp[11]=xy[h+dx];
             lns2+=cube_poly(mn,mb,cp,msh);
             // h[0],h[dx],h[dx+1],h[2*dx]
             // f[0],f[1],f[dx],f[dx+1]
             // g[0],g[dx],g[dx+1],g[2*dx]
           }
         }
         h+=dx+1;
         f++;
         g+=dx+1;
       }
     }
   }
   static void stream_copy(Stream d,Stream s) {
     byte[] buf=new byte[4096];
     int r;     
      while(0<(r=s.Read(buf,0,buf.Length)))
        d.Write(buf,0,r);
   }

   class plg_s {
     internal int pt,pl;//*p;
     internal int[] p;
     internal int s1,s2,z;
     internal mesh msh;
   }; 

   void test_point(plg_s p,int p1) {
     if(p.p[p1]==0) {
       int i=p1;
       p.msh.pts.Add(i%p.s1,i%p.s2/p.s1,p.z+(i>=p.s2?1:0));
       p.p[p1]=++p.pt;
     }
   }

   void poly(plg_s p,int p1,int p2,int p3,int p4) {
     test_point(p,p1);
     test_point(p,p2);
     test_point(p,p3);
     test_point(p,p4);
     p.msh.fcs.Quad(p.p[p1]-1,p.p[p2]-1,p.p[p3]-1,p.p[p4]-1,POINTS.None);
     //p.lprf(p.plf,p.p[p1]-1,p.p[p2]-1,p.p[p3]-1,p.p[p4]-1);
     p.pl++;
   }

   void mesh_poly(mesh msh,bool cyclic,bool sides) {
     plg_s p=new plg_s();
     //StreamWriter f;
     int x,y,r;//,*r;
     int s1=dx+1,s2=s1*(dy+1);
     int pt_idx_size=s2;
     bit3d b1=new bit3d(),b2=new bit3d();  // buffer for 2 cuts
     bool l0,l1;

     p.msh=msh;
     p.s1=s1;p.s2=s2;
     p.pt=p.pl=0;
     p.p=new int[2*pt_idx_size];
     //p2=s2;

     b1.alloc(2+dx,2+dy,1);
     b2.alloc(2+dx,2+dy,1);
     //memset(p2,0,pt_idx_size);
     if(cyclic)
       b2.operation(bit_op.Copy,1,1,0,this,0,0,dz-1,dx,dy,1);
     else
       b2.clear(false);
     for(p.z=0;p.z<=dz;p.z++) {
       Array.Copy(p.p,pt_idx_size,p.p,0,pt_idx_size);
       //memcpy(p.p,p2,pt_idx_size);	// nove indexy do starych
       b1.operation(bit_op.Copy,0,0,0,b2,0,0,0,b2.dx,b2.dy,b2.dz);
       //memcpy(b1.bit,b2.bit,b1.size());
       Array.Clear(p.p,pt_idx_size,pt_idx_size);
       //memset(p.p2,0,pt_idx_size);         // nove vynulovat
       b2.clear(false);
       if(p.z<dz)
         for(y=0;y<dy;y++)
           for(x=0;x<dx;x++) {
             b2.set(x+1,y+1,0,get(x,y,p.z));
           }
       else if(cyclic)
         b2.operation(bit_op.Copy,1,1,0,this,0,0,0,dx,dy,1);    
       for(y=0;y<=dy;y++)
         for(x=0;x<=dx;x++) {
           r=y*s1+x;
           if(sides||x>0&&x<dx) {
             l0=b2.get(x+1,y+1,0);
             l1=b2.get(x,y+1,0);                       //leva/prava
             if(l0&&!l1) poly(p,r,r+s1,r+s1+s2,r+s2);
             if(l1&&!l0) poly(p,r+s2,r+s1+s2,r+s1,r);
           }
           if(sides||y>0&&y<dy) {  
             l0=b2.get(x+1,y+1,0);
             l1=b2.get(x+1,y,0);			// horni/dolni
             if(l0&&!l1) poly(p,r+s2,r+1+s2,r+1,r);
             if(l1&&!l0) poly(p,r,r+1,r+1+s2,r+s2);  
           }
           if(sides||cyclic||p.z>0&&p.z<dz) {  
             l0=b2.get(x+1,y+1,0);
             l1=b1.get(x+1,y+1,0);                   // predni zadni OK
             if(l0&&!l1) poly(p,r,r+1,r+1+s1,r+s1); 
             if(l1&&!l0) poly(p,r+s1,r+1+s1,r+1,r);
           }  
         }
     }
   } 
   

   public mesh Mesh(bool cubes,bool cyclic) {
     mesh msh=new mesh();
     if(cubes) {
       mesh_poly(msh,cyclic,false);
       msh.fcs.Reverse();
     } else
       mesh_poly2(msh,cyclic);
     return msh;
   }

  }
}
