﻿namespace cubes {
  partial class fnew {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components=null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if(disposing&&(components!=null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.eX=new System.Windows.Forms.TextBox();
      this.eY=new System.Windows.Forms.TextBox();
      this.eZ=new System.Windows.Forms.TextBox();
      this.bOK=new System.Windows.Forms.Button();
      this.bCube=new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // eX
      // 
      this.eX.Location=new System.Drawing.Point(12,12);
      this.eX.Name="eX";
      this.eX.Size=new System.Drawing.Size(67,20);
      this.eX.TabIndex=0;
      this.eX.Text="32";
      // 
      // eY
      // 
      this.eY.Location=new System.Drawing.Point(85,12);
      this.eY.Name="eY";
      this.eY.Size=new System.Drawing.Size(67,20);
      this.eY.TabIndex=1;
      this.eY.Text="32";
      // 
      // eZ
      // 
      this.eZ.Location=new System.Drawing.Point(158,12);
      this.eZ.Name="eZ";
      this.eZ.Size=new System.Drawing.Size(67,20);
      this.eZ.TabIndex=2;
      this.eZ.Text="32";
      // 
      // bOK
      // 
      this.bOK.Location=new System.Drawing.Point(158,38);
      this.bOK.Name="bOK";
      this.bOK.Size=new System.Drawing.Size(67,21);
      this.bOK.TabIndex=3;
      this.bOK.Text="OK";
      this.bOK.UseVisualStyleBackColor=true;
      this.bOK.Click+=new System.EventHandler(this.bOK_Click);
      // 
      // bCube
      // 
      this.bCube.Location=new System.Drawing.Point(45,38);
      this.bCube.Name="bCube";
      this.bCube.Size=new System.Drawing.Size(59,21);
      this.bCube.TabIndex=4;
      this.bCube.Text="Cube";
      this.bCube.UseVisualStyleBackColor=true;
      this.bCube.Click+=new System.EventHandler(this.bCube_Click);
      // 
      // fnew
      // 
      this.AutoScaleDimensions=new System.Drawing.SizeF(6F,13F);
      this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize=new System.Drawing.Size(237,64);
      this.Controls.Add(this.bCube);
      this.Controls.Add(this.bOK);
      this.Controls.Add(this.eZ);
      this.Controls.Add(this.eY);
      this.Controls.Add(this.eX);
      this.Name="fnew";
      this.Text="New";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox eX;
    private System.Windows.Forms.TextBox eY;
    private System.Windows.Forms.TextBox eZ;
    private System.Windows.Forms.Button bOK;
    private System.Windows.Forms.Button bCube;
  }
}