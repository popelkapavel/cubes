﻿namespace cubes {
  partial class fmain {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components=null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if(disposing&&(components!=null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components=new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources=new System.ComponentModel.ComponentResourceManager(typeof(fmain));
      this.menu=new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileNew=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileOpen=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileSave=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileSaveAs=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilePrint=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1=new System.Windows.Forms.ToolStripSeparator();
      this.mFileExportOff=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileExportBmp=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileExport3D=new System.Windows.Forms.ToolStripMenuItem();
      this.mFileExportSVG=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator8=new System.Windows.Forms.ToolStripSeparator();
      this.mFileViewMesh=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2=new System.Windows.Forms.ToolStripSeparator();
      this.mFileExit=new System.Windows.Forms.ToolStripMenuItem();
      this.mEdit=new System.Windows.Forms.ToolStripMenuItem();
      this.mEditUndo=new System.Windows.Forms.ToolStripMenuItem();
      this.mEditRedo=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator3=new System.Windows.Forms.ToolStripSeparator();
      this.mEditCut=new System.Windows.Forms.ToolStripMenuItem();
      this.mEditCopy=new System.Windows.Forms.ToolStripMenuItem();
      this.mEditPaste=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator4=new System.Windows.Forms.ToolStripSeparator();
      this.mEditDelete=new System.Windows.Forms.ToolStripMenuItem();
      this.operationToolStripMenuItem=new System.Windows.Forms.ToolStripMenuItem();
      this.mOpFloodFill=new System.Windows.Forms.ToolStripMenuItem();
      this.mOpExtend=new System.Windows.Forms.ToolStripMenuItem();
      this.mOpDoubleSize=new System.Windows.Forms.ToolStripMenuItem();
      this.mOpHalfSize=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator7=new System.Windows.Forms.ToolStripSeparator();
      this.mOpInsertPlane=new System.Windows.Forms.ToolStripMenuItem();
      this.mOpDeletePlane=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilter=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterNot=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterBoundary=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterExpand=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterImpand=new System.Windows.Forms.ToolStripMenuItem();
      this.mFilterSum=new System.Windows.Forms.ToolStripMenuItem();
      this.mView=new System.Windows.Forms.ToolStripMenuItem();
      this.mViewMesh=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator5=new System.Windows.Forms.ToolStripSeparator();
      this.mMeshColor=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshLight=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshWires=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator6=new System.Windows.Forms.ToolStripSeparator();
      this.mViewAlign=new System.Windows.Forms.ToolStripMenuItem();
      this.mViewFullscreen=new System.Windows.Forms.ToolStripMenuItem();
      this.mMesh=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshRelax=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshTriangulation=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshPrecise=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshScale=new System.Windows.Forms.ToolStripMenuItem();
      this.mMeshRotoid=new System.Windows.Forms.ToolStripMenuItem();
      this.mHelp=new System.Windows.Forms.ToolStripMenuItem();
      this.mHelpHelp=new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator9=new System.Windows.Forms.ToolStripSeparator();
      this.mHelpAbout=new System.Windows.Forms.ToolStripMenuItem();
      this.bZUp=new System.Windows.Forms.Button();
      this.eZ=new System.Windows.Forms.TextBox();
      this.bZDown=new System.Windows.Forms.Button();
      this.eSize=new System.Windows.Forms.TextBox();
      this.ePen=new System.Windows.Forms.TextBox();
      this.bRotXP=new System.Windows.Forms.Button();
      this.bRotXN=new System.Windows.Forms.Button();
      this.bRotYN=new System.Windows.Forms.Button();
      this.bRotYP=new System.Windows.Forms.Button();
      this.bRotZN=new System.Windows.Forms.Button();
      this.bRotZP=new System.Windows.Forms.Button();
      this.bFill3D=new System.Windows.Forms.Button();
      this.bPen=new System.Windows.Forms.Button();
      this.bFill2D=new System.Windows.Forms.Button();
      this.bMirrZ=new System.Windows.Forms.Button();
      this.bAutoSize=new System.Windows.Forms.Button();
      this.timer=new System.Windows.Forms.Timer(this.components);
      this.pControl=new System.Windows.Forms.Panel();
      this.lPen=new System.Windows.Forms.Label();
      this.lRotoid=new System.Windows.Forms.Label();
      this.eRotoidCount=new System.Windows.Forms.TextBox();
      this.bDeletePlaneY=new System.Windows.Forms.Button();
      this.bDeletePlaneX=new System.Windows.Forms.Button();
      this.bDeletePlaneZ=new System.Windows.Forms.Button();
      this.lDeletePlane=new System.Windows.Forms.Label();
      this.bInsertPlaneY=new System.Windows.Forms.Button();
      this.bInsertPlaneX=new System.Windows.Forms.Button();
      this.bInsertPlaneZ=new System.Windows.Forms.Button();
      this.lInsertPlane=new System.Windows.Forms.Label();
      this.pMain=new System.Windows.Forms.Panel();
      this.menu.SuspendLayout();
      this.pControl.SuspendLayout();
      this.SuspendLayout();
      // 
      // menu
      // 
      this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mEdit,
            this.operationToolStripMenuItem,
            this.mFilter,
            this.mView,
            this.mMesh,
            this.mHelp});
      this.menu.Location=new System.Drawing.Point(0,0);
      this.menu.Name="menu";
      this.menu.Size=new System.Drawing.Size(714,24);
      this.menu.TabIndex=0;
      this.menu.Text="menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFileNew,
            this.mFileOpen,
            this.mFileSave,
            this.mFileSaveAs,
            this.mFilePrint,
            this.toolStripSeparator1,
            this.mFileExportOff,
            this.mFileExportBmp,
            this.mFileExport3D,
            this.mFileExportSVG,
            this.toolStripSeparator8,
            this.mFileViewMesh,
            this.toolStripSeparator2,
            this.mFileExit});
      this.fileToolStripMenuItem.Name="fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size=new System.Drawing.Size(35,20);
      this.fileToolStripMenuItem.Text="&File";
      // 
      // mFileNew
      // 
      this.mFileNew.Name="mFileNew";
      this.mFileNew.Size=new System.Drawing.Size(171,22);
      this.mFileNew.Text="New";
      this.mFileNew.Click+=new System.EventHandler(this.newToolStripMenuItem_Click);
      // 
      // mFileOpen
      // 
      this.mFileOpen.Name="mFileOpen";
      this.mFileOpen.Size=new System.Drawing.Size(171,22);
      this.mFileOpen.Text="&Open ...";
      this.mFileOpen.Click+=new System.EventHandler(this.openToolStripMenuItem_Click);
      // 
      // mFileSave
      // 
      this.mFileSave.Name="mFileSave";
      this.mFileSave.Size=new System.Drawing.Size(171,22);
      this.mFileSave.Text="Save";
      this.mFileSave.Click+=new System.EventHandler(this.mFileSave_Click);
      // 
      // mFileSaveAs
      // 
      this.mFileSaveAs.Name="mFileSaveAs";
      this.mFileSaveAs.Size=new System.Drawing.Size(171,22);
      this.mFileSaveAs.Text="Save as ...";
      this.mFileSaveAs.Click+=new System.EventHandler(this.mFileSaveAs_Click);
      // 
      // mFilePrint
      // 
      this.mFilePrint.Name="mFilePrint";
      this.mFilePrint.ShortcutKeys=((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control|System.Windows.Forms.Keys.P)));
      this.mFilePrint.Size=new System.Drawing.Size(171,22);
      this.mFilePrint.Text="&Print";
      this.mFilePrint.Click+=new System.EventHandler(this.mFilePrint_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name="toolStripSeparator1";
      this.toolStripSeparator1.Size=new System.Drawing.Size(168,6);
      // 
      // mFileExportOff
      // 
      this.mFileExportOff.Name="mFileExportOff";
      this.mFileExportOff.Size=new System.Drawing.Size(171,22);
      this.mFileExportOff.Text="Export mesh ...";
      this.mFileExportOff.Click+=new System.EventHandler(this.mFileExportOff_Click);
      // 
      // mFileExportBmp
      // 
      this.mFileExportBmp.Name="mFileExportBmp";
      this.mFileExportBmp.Size=new System.Drawing.Size(171,22);
      this.mFileExportBmp.Text="Export bmp";
      this.mFileExportBmp.Click+=new System.EventHandler(this.mFileExportBmp_Click);
      // 
      // mFileExport3D
      // 
      this.mFileExport3D.Name="mFileExport3D";
      this.mFileExport3D.ShortcutKeys=((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control|System.Windows.Forms.Keys.D3)));
      this.mFileExport3D.Size=new System.Drawing.Size(171,22);
      this.mFileExport3D.Text="Export 3D";
      this.mFileExport3D.Click+=new System.EventHandler(this.mFileExport3D_Click);
      // 
      // mFileExportSVG
      // 
      this.mFileExportSVG.Name="mFileExportSVG";
      this.mFileExportSVG.Size=new System.Drawing.Size(171,22);
      this.mFileExportSVG.Text="Export vector ...";
      this.mFileExportSVG.Click+=new System.EventHandler(this.mFileExportVector_Click);
      // 
      // toolStripSeparator8
      // 
      this.toolStripSeparator8.Name="toolStripSeparator8";
      this.toolStripSeparator8.Size=new System.Drawing.Size(168,6);
      // 
      // mFileViewMesh
      // 
      this.mFileViewMesh.Name="mFileViewMesh";
      this.mFileViewMesh.Size=new System.Drawing.Size(171,22);
      this.mFileViewMesh.Text="View mesh ...";
      this.mFileViewMesh.Click+=new System.EventHandler(this.mFileViewMesh_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name="toolStripSeparator2";
      this.toolStripSeparator2.Size=new System.Drawing.Size(168,6);
      // 
      // mFileExit
      // 
      this.mFileExit.Name="mFileExit";
      this.mFileExit.Size=new System.Drawing.Size(171,22);
      this.mFileExit.Text="Exit";
      this.mFileExit.Click+=new System.EventHandler(this.mFileExit_Click);
      // 
      // mEdit
      // 
      this.mEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mEditUndo,
            this.mEditRedo,
            this.toolStripSeparator3,
            this.mEditCut,
            this.mEditCopy,
            this.mEditPaste,
            this.toolStripSeparator4,
            this.mEditDelete});
      this.mEdit.Name="mEdit";
      this.mEdit.Size=new System.Drawing.Size(37,20);
      this.mEdit.Text="&Edit";
      // 
      // mEditUndo
      // 
      this.mEditUndo.Name="mEditUndo";
      this.mEditUndo.Size=new System.Drawing.Size(116,22);
      this.mEditUndo.Text="&Undo";
      this.mEditUndo.Click+=new System.EventHandler(this.bEditUndo_Click);
      // 
      // mEditRedo
      // 
      this.mEditRedo.Enabled=false;
      this.mEditRedo.Name="mEditRedo";
      this.mEditRedo.Size=new System.Drawing.Size(116,22);
      this.mEditRedo.Text="&Redo";
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name="toolStripSeparator3";
      this.toolStripSeparator3.Size=new System.Drawing.Size(113,6);
      // 
      // mEditCut
      // 
      this.mEditCut.Name="mEditCut";
      this.mEditCut.Size=new System.Drawing.Size(116,22);
      this.mEditCut.Text="Cut";
      this.mEditCut.Click+=new System.EventHandler(this.mEditCut_Click);
      // 
      // mEditCopy
      // 
      this.mEditCopy.Name="mEditCopy";
      this.mEditCopy.Size=new System.Drawing.Size(116,22);
      this.mEditCopy.Text="Copy";
      this.mEditCopy.Click+=new System.EventHandler(this.mEditCopy_Click);
      // 
      // mEditPaste
      // 
      this.mEditPaste.Name="mEditPaste";
      this.mEditPaste.Size=new System.Drawing.Size(116,22);
      this.mEditPaste.Text="Paste";
      this.mEditPaste.Click+=new System.EventHandler(this.mEditPaste_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name="toolStripSeparator4";
      this.toolStripSeparator4.Size=new System.Drawing.Size(113,6);
      // 
      // mEditDelete
      // 
      this.mEditDelete.Name="mEditDelete";
      this.mEditDelete.Size=new System.Drawing.Size(116,22);
      this.mEditDelete.Text="Delete";
      this.mEditDelete.Click+=new System.EventHandler(this.mEditDelete_Click);
      // 
      // operationToolStripMenuItem
      // 
      this.operationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mOpFloodFill,
            this.mOpExtend,
            this.mOpDoubleSize,
            this.mOpHalfSize,
            this.toolStripSeparator7,
            this.mOpInsertPlane,
            this.mOpDeletePlane});
      this.operationToolStripMenuItem.Name="operationToolStripMenuItem";
      this.operationToolStripMenuItem.Size=new System.Drawing.Size(67,20);
      this.operationToolStripMenuItem.Text="&Operation";
      // 
      // mOpFloodFill
      // 
      this.mOpFloodFill.Name="mOpFloodFill";
      this.mOpFloodFill.Size=new System.Drawing.Size(149,22);
      this.mOpFloodFill.Text="Flood fill";
      // 
      // mOpExtend
      // 
      this.mOpExtend.Name="mOpExtend";
      this.mOpExtend.Size=new System.Drawing.Size(149,22);
      this.mOpExtend.Text="Extend";
      this.mOpExtend.Click+=new System.EventHandler(this.mFilterExtend_Click);
      // 
      // mOpDoubleSize
      // 
      this.mOpDoubleSize.Name="mOpDoubleSize";
      this.mOpDoubleSize.Size=new System.Drawing.Size(149,22);
      this.mOpDoubleSize.Text="Double size";
      this.mOpDoubleSize.Click+=new System.EventHandler(this.mOpDoubleSize_Click);
      // 
      // mOpHalfSize
      // 
      this.mOpHalfSize.Name="mOpHalfSize";
      this.mOpHalfSize.Size=new System.Drawing.Size(149,22);
      this.mOpHalfSize.Text="Half size";
      this.mOpHalfSize.Click+=new System.EventHandler(this.mOpHalfSize_Click);
      // 
      // toolStripSeparator7
      // 
      this.toolStripSeparator7.Name="toolStripSeparator7";
      this.toolStripSeparator7.Size=new System.Drawing.Size(146,6);
      // 
      // mOpInsertPlane
      // 
      this.mOpInsertPlane.Name="mOpInsertPlane";
      this.mOpInsertPlane.Size=new System.Drawing.Size(149,22);
      this.mOpInsertPlane.Text="InsertPlane Z";
      this.mOpInsertPlane.Click+=new System.EventHandler(this.mOpInsertPlane_Click);
      // 
      // mOpDeletePlane
      // 
      this.mOpDeletePlane.Name="mOpDeletePlane";
      this.mOpDeletePlane.Size=new System.Drawing.Size(149,22);
      this.mOpDeletePlane.Text="DeletePlane";
      this.mOpDeletePlane.Click+=new System.EventHandler(this.mOpDeletePlane_Click);
      // 
      // mFilter
      // 
      this.mFilter.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFilterNot,
            this.mFilterBoundary,
            this.mFilterExpand,
            this.mFilterImpand,
            this.mFilterSum});
      this.mFilter.Name="mFilter";
      this.mFilter.Size=new System.Drawing.Size(43,20);
      this.mFilter.Text="&Filter";
      // 
      // mFilterNot
      // 
      this.mFilterNot.Name="mFilterNot";
      this.mFilterNot.Size=new System.Drawing.Size(131,22);
      this.mFilterNot.Text="Not";
      this.mFilterNot.Click+=new System.EventHandler(this.mFilterNot_Click);
      // 
      // mFilterBoundary
      // 
      this.mFilterBoundary.Name="mFilterBoundary";
      this.mFilterBoundary.Size=new System.Drawing.Size(131,22);
      this.mFilterBoundary.Text="Boundary";
      this.mFilterBoundary.Click+=new System.EventHandler(this.mFilterBoundary_Click);
      // 
      // mFilterExpand
      // 
      this.mFilterExpand.Name="mFilterExpand";
      this.mFilterExpand.Size=new System.Drawing.Size(131,22);
      this.mFilterExpand.Text="Expand";
      this.mFilterExpand.Click+=new System.EventHandler(this.mFilterExpand_Click);
      // 
      // mFilterImpand
      // 
      this.mFilterImpand.Name="mFilterImpand";
      this.mFilterImpand.Size=new System.Drawing.Size(131,22);
      this.mFilterImpand.Text="Impand";
      this.mFilterImpand.Click+=new System.EventHandler(this.mFilterImpand_Click);
      // 
      // mFilterSum
      // 
      this.mFilterSum.Enabled=false;
      this.mFilterSum.Name="mFilterSum";
      this.mFilterSum.Size=new System.Drawing.Size(131,22);
      this.mFilterSum.Text="Sum";
      this.mFilterSum.Visible=false;
      this.mFilterSum.Click+=new System.EventHandler(this.mFilterSum_Click);
      // 
      // mView
      // 
      this.mView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mViewMesh,
            this.toolStripSeparator5,
            this.mMeshColor,
            this.mMeshLight,
            this.mMeshWires,
            this.toolStripSeparator6,
            this.mViewAlign,
            this.mViewFullscreen});
      this.mView.Name="mView";
      this.mView.Size=new System.Drawing.Size(41,20);
      this.mView.Text="&View";
      // 
      // mViewMesh
      // 
      this.mViewMesh.Name="mViewMesh";
      this.mViewMesh.Size=new System.Drawing.Size(158,22);
      this.mViewMesh.Text="&Mesh (M)";
      this.mViewMesh.Click+=new System.EventHandler(this.mViewMesh_Click);
      // 
      // toolStripSeparator5
      // 
      this.toolStripSeparator5.Name="toolStripSeparator5";
      this.toolStripSeparator5.Size=new System.Drawing.Size(155,6);
      // 
      // mMeshColor
      // 
      this.mMeshColor.Name="mMeshColor";
      this.mMeshColor.Size=new System.Drawing.Size(158,22);
      this.mMeshColor.Text="&Color (C)";
      this.mMeshColor.Click+=new System.EventHandler(this.mMeshColor_Click);
      // 
      // mMeshLight
      // 
      this.mMeshLight.Name="mMeshLight";
      this.mMeshLight.Size=new System.Drawing.Size(158,22);
      this.mMeshLight.Text="Light (L)";
      this.mMeshLight.Click+=new System.EventHandler(this.mMeshLight_Click);
      // 
      // mMeshWires
      // 
      this.mMeshWires.Checked=true;
      this.mMeshWires.CheckState=System.Windows.Forms.CheckState.Checked;
      this.mMeshWires.Name="mMeshWires";
      this.mMeshWires.Size=new System.Drawing.Size(158,22);
      this.mMeshWires.Text="Wires";
      this.mMeshWires.Click+=new System.EventHandler(this.mMeshVires_Click);
      // 
      // toolStripSeparator6
      // 
      this.toolStripSeparator6.Name="toolStripSeparator6";
      this.toolStripSeparator6.Size=new System.Drawing.Size(155,6);
      // 
      // mViewAlign
      // 
      this.mViewAlign.Name="mViewAlign";
      this.mViewAlign.Size=new System.Drawing.Size(158,22);
      this.mViewAlign.Text="&Align Y";
      this.mViewAlign.Click+=new System.EventHandler(this.mViewAlign_Click);
      // 
      // mViewFullscreen
      // 
      this.mViewFullscreen.Name="mViewFullscreen";
      this.mViewFullscreen.ShortcutKeys=System.Windows.Forms.Keys.F11;
      this.mViewFullscreen.Size=new System.Drawing.Size(158,22);
      this.mViewFullscreen.Text="&Fullscreen";
      this.mViewFullscreen.Click+=new System.EventHandler(this.mViewFullscreen_Click);
      // 
      // mMesh
      // 
      this.mMesh.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMeshRelax,
            this.mMeshTriangulation,
            this.mMeshPrecise,
            this.mMeshScale,
            this.mMeshRotoid});
      this.mMesh.Name="mMesh";
      this.mMesh.Size=new System.Drawing.Size(44,20);
      this.mMesh.Text="&Mesh";
      // 
      // mMeshRelax
      // 
      this.mMeshRelax.Name="mMeshRelax";
      this.mMeshRelax.Size=new System.Drawing.Size(164,22);
      this.mMeshRelax.Text="&Relax (R)";
      this.mMeshRelax.Click+=new System.EventHandler(this.mMeshRelax_Click);
      // 
      // mMeshTriangulation
      // 
      this.mMeshTriangulation.Name="mMeshTriangulation";
      this.mMeshTriangulation.Size=new System.Drawing.Size(164,22);
      this.mMeshTriangulation.Text="&Triangulation (T)";
      this.mMeshTriangulation.Click+=new System.EventHandler(this.mMeshTriangulation_Click);
      // 
      // mMeshPrecise
      // 
      this.mMeshPrecise.Name="mMeshPrecise";
      this.mMeshPrecise.Size=new System.Drawing.Size(164,22);
      this.mMeshPrecise.Text="&Precise (P)";
      this.mMeshPrecise.Click+=new System.EventHandler(this.mMeshPrecise_Click);
      // 
      // mMeshScale
      // 
      this.mMeshScale.Name="mMeshScale";
      this.mMeshScale.Size=new System.Drawing.Size(164,22);
      this.mMeshScale.Text="&Scale";
      this.mMeshScale.Click+=new System.EventHandler(this.mMeshScale_Click);
      // 
      // mMeshRotoid
      // 
      this.mMeshRotoid.Name="mMeshRotoid";
      this.mMeshRotoid.Size=new System.Drawing.Size(164,22);
      this.mMeshRotoid.Text="Rotoid (O)";
      this.mMeshRotoid.Click+=new System.EventHandler(this.mMeshRotoid_Click);
      // 
      // mHelp
      // 
      this.mHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mHelpHelp,
            this.toolStripSeparator9,
            this.mHelpAbout});
      this.mHelp.Name="mHelp";
      this.mHelp.Size=new System.Drawing.Size(40,20);
      this.mHelp.Text="&Help";
      // 
      // mHelpHelp
      // 
      this.mHelpHelp.Name="mHelpHelp";
      this.mHelpHelp.Size=new System.Drawing.Size(152,22);
      this.mHelpHelp.Text="&Help";
      this.mHelpHelp.Click+=new System.EventHandler(this.mHelpHelp_Click);
      // 
      // toolStripSeparator9
      // 
      this.toolStripSeparator9.Name="toolStripSeparator9";
      this.toolStripSeparator9.Size=new System.Drawing.Size(149,6);
      // 
      // mHelpAbout
      // 
      this.mHelpAbout.Name="mHelpAbout";
      this.mHelpAbout.Size=new System.Drawing.Size(152,22);
      this.mHelpAbout.Text="&About";
      this.mHelpAbout.Click+=new System.EventHandler(this.mHelpAbout_Click);
      // 
      // bZUp
      // 
      this.bZUp.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bZUp.Location=new System.Drawing.Point(51,3);
      this.bZUp.Name="bZUp";
      this.bZUp.Size=new System.Drawing.Size(15,19);
      this.bZUp.TabIndex=1;
      this.bZUp.Text="+";
      this.bZUp.UseVisualStyleBackColor=true;
      this.bZUp.Click+=new System.EventHandler(this.bZUp_Click);
      // 
      // eZ
      // 
      this.eZ.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.eZ.Location=new System.Drawing.Point(18,2);
      this.eZ.Name="eZ";
      this.eZ.Size=new System.Drawing.Size(33,20);
      this.eZ.TabIndex=2;
      this.eZ.KeyDown+=new System.Windows.Forms.KeyEventHandler(this.eZ_KeyDown);
      // 
      // bZDown
      // 
      this.bZDown.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bZDown.Location=new System.Drawing.Point(3,3);
      this.bZDown.Name="bZDown";
      this.bZDown.Size=new System.Drawing.Size(15,19);
      this.bZDown.TabIndex=3;
      this.bZDown.Text="-";
      this.bZDown.UseVisualStyleBackColor=true;
      this.bZDown.Click+=new System.EventHandler(this.bZDown_Click);
      // 
      // eSize
      // 
      this.eSize.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.eSize.Location=new System.Drawing.Point(24,50);
      this.eSize.Name="eSize";
      this.eSize.Size=new System.Drawing.Size(42,20);
      this.eSize.TabIndex=4;
      this.eSize.KeyDown+=new System.Windows.Forms.KeyEventHandler(this.eSize_KeyDown);
      // 
      // ePen
      // 
      this.ePen.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.ePen.Location=new System.Drawing.Point(31,24);
      this.ePen.Name="ePen";
      this.ePen.Size=new System.Drawing.Size(34,20);
      this.ePen.TabIndex=5;
      this.ePen.KeyUp+=new System.Windows.Forms.KeyEventHandler(this.ePen_KeyUp);
      // 
      // bRotXP
      // 
      this.bRotXP.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotXP.Location=new System.Drawing.Point(9,76);
      this.bRotXP.Name="bRotXP";
      this.bRotXP.Size=new System.Drawing.Size(28,19);
      this.bRotXP.TabIndex=6;
      this.bRotXP.Text="X^";
      this.bRotXP.UseVisualStyleBackColor=true;
      this.bRotXP.Click+=new System.EventHandler(this.bRotXP_Click);
      // 
      // bRotXN
      // 
      this.bRotXN.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotXN.Location=new System.Drawing.Point(37,76);
      this.bRotXN.Name="bRotXN";
      this.bRotXN.Size=new System.Drawing.Size(27,19);
      this.bRotXN.TabIndex=7;
      this.bRotXN.Text="Xv";
      this.bRotXN.UseVisualStyleBackColor=true;
      this.bRotXN.Click+=new System.EventHandler(this.bRotXN_Click);
      // 
      // bRotYN
      // 
      this.bRotYN.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotYN.Location=new System.Drawing.Point(37,101);
      this.bRotYN.Name="bRotYN";
      this.bRotYN.Size=new System.Drawing.Size(29,19);
      this.bRotYN.TabIndex=9;
      this.bRotYN.Text="Y>";
      this.bRotYN.UseVisualStyleBackColor=true;
      this.bRotYN.Click+=new System.EventHandler(this.bRotYN_Click);
      // 
      // bRotYP
      // 
      this.bRotYP.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotYP.Location=new System.Drawing.Point(8,101);
      this.bRotYP.Name="bRotYP";
      this.bRotYP.Size=new System.Drawing.Size(29,19);
      this.bRotYP.TabIndex=8;
      this.bRotYP.Text="Y<";
      this.bRotYP.UseVisualStyleBackColor=true;
      this.bRotYP.Click+=new System.EventHandler(this.bRotYP_Click);
      // 
      // bRotZN
      // 
      this.bRotZN.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotZN.Location=new System.Drawing.Point(37,126);
      this.bRotZN.Name="bRotZN";
      this.bRotZN.Size=new System.Drawing.Size(29,19);
      this.bRotZN.TabIndex=11;
      this.bRotZN.Text="Z>";
      this.bRotZN.UseVisualStyleBackColor=true;
      this.bRotZN.Click+=new System.EventHandler(this.bRotZN_Click);
      // 
      // bRotZP
      // 
      this.bRotZP.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bRotZP.Location=new System.Drawing.Point(8,126);
      this.bRotZP.Name="bRotZP";
      this.bRotZP.Size=new System.Drawing.Size(29,19);
      this.bRotZP.TabIndex=10;
      this.bRotZP.Text="Z<";
      this.bRotZP.UseVisualStyleBackColor=true;
      this.bRotZP.Click+=new System.EventHandler(this.bRotZP_Click);
      // 
      // bFill3D
      // 
      this.bFill3D.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bFill3D.Location=new System.Drawing.Point(2,177);
      this.bFill3D.Name="bFill3D";
      this.bFill3D.Size=new System.Drawing.Size(42,20);
      this.bFill3D.TabIndex=13;
      this.bFill3D.Text="Fill 3d";
      this.bFill3D.UseVisualStyleBackColor=true;
      this.bFill3D.Click+=new System.EventHandler(this.bFill_Click);
      // 
      // bPen
      // 
      this.bPen.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bPen.Location=new System.Drawing.Point(26,151);
      this.bPen.Name="bPen";
      this.bPen.Size=new System.Drawing.Size(40,20);
      this.bPen.TabIndex=14;
      this.bPen.Text="Pen";
      this.bPen.UseVisualStyleBackColor=true;
      this.bPen.Click+=new System.EventHandler(this.bPen_Click);
      // 
      // bFill2D
      // 
      this.bFill2D.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bFill2D.Location=new System.Drawing.Point(24,203);
      this.bFill2D.Name="bFill2D";
      this.bFill2D.Size=new System.Drawing.Size(43,20);
      this.bFill2D.TabIndex=15;
      this.bFill2D.Text="Fill 2d";
      this.bFill2D.UseVisualStyleBackColor=true;
      this.bFill2D.Click+=new System.EventHandler(this.bFill2D_Click);
      // 
      // bMirrZ
      // 
      this.bMirrZ.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bMirrZ.Location=new System.Drawing.Point(20,229);
      this.bMirrZ.Name="bMirrZ";
      this.bMirrZ.Size=new System.Drawing.Size(43,19);
      this.bMirrZ.TabIndex=16;
      this.bMirrZ.Text="Z|Z";
      this.bMirrZ.UseVisualStyleBackColor=true;
      this.bMirrZ.Click+=new System.EventHandler(this.bMirrZ_Click);
      // 
      // bAutoSize
      // 
      this.bAutoSize.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bAutoSize.Location=new System.Drawing.Point(8,51);
      this.bAutoSize.Name="bAutoSize";
      this.bAutoSize.Size=new System.Drawing.Size(16,19);
      this.bAutoSize.TabIndex=17;
      this.bAutoSize.Text="a";
      this.bAutoSize.UseVisualStyleBackColor=true;
      this.bAutoSize.Click+=new System.EventHandler(this.bAutoSize_Click);
      // 
      // timer
      // 
      this.timer.Enabled=true;
      this.timer.Tick+=new System.EventHandler(this.timer_Tick);
      // 
      // pControl
      // 
      this.pControl.Controls.Add(this.lPen);
      this.pControl.Controls.Add(this.lRotoid);
      this.pControl.Controls.Add(this.eRotoidCount);
      this.pControl.Controls.Add(this.bDeletePlaneY);
      this.pControl.Controls.Add(this.bDeletePlaneX);
      this.pControl.Controls.Add(this.bDeletePlaneZ);
      this.pControl.Controls.Add(this.lDeletePlane);
      this.pControl.Controls.Add(this.bInsertPlaneY);
      this.pControl.Controls.Add(this.bInsertPlaneX);
      this.pControl.Controls.Add(this.bInsertPlaneZ);
      this.pControl.Controls.Add(this.lInsertPlane);
      this.pControl.Controls.Add(this.bZUp);
      this.pControl.Controls.Add(this.eZ);
      this.pControl.Controls.Add(this.bAutoSize);
      this.pControl.Controls.Add(this.bZDown);
      this.pControl.Controls.Add(this.bMirrZ);
      this.pControl.Controls.Add(this.bRotXN);
      this.pControl.Controls.Add(this.bFill2D);
      this.pControl.Controls.Add(this.eSize);
      this.pControl.Controls.Add(this.bPen);
      this.pControl.Controls.Add(this.ePen);
      this.pControl.Controls.Add(this.bFill3D);
      this.pControl.Controls.Add(this.bRotXP);
      this.pControl.Controls.Add(this.bRotZN);
      this.pControl.Controls.Add(this.bRotYP);
      this.pControl.Controls.Add(this.bRotZP);
      this.pControl.Controls.Add(this.bRotYN);
      this.pControl.Dock=System.Windows.Forms.DockStyle.Right;
      this.pControl.Location=new System.Drawing.Point(645,24);
      this.pControl.Name="pControl";
      this.pControl.Size=new System.Drawing.Size(69,421);
      this.pControl.TabIndex=19;
      // 
      // lPen
      // 
      this.lPen.AutoSize=true;
      this.lPen.Location=new System.Drawing.Point(2,27);
      this.lPen.Name="lPen";
      this.lPen.Size=new System.Drawing.Size(26,13);
      this.lPen.TabIndex=29;
      this.lPen.Text="Pen";
      // 
      // lRotoid
      // 
      this.lRotoid.AutoSize=true;
      this.lRotoid.Location=new System.Drawing.Point(1,330);
      this.lRotoid.Name="lRotoid";
      this.lRotoid.Size=new System.Drawing.Size(38,13);
      this.lRotoid.TabIndex=28;
      this.lRotoid.Text="Rotoid";
      // 
      // eRotoidCount
      // 
      this.eRotoidCount.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.eRotoidCount.Location=new System.Drawing.Point(26,346);
      this.eRotoidCount.Name="eRotoidCount";
      this.eRotoidCount.Size=new System.Drawing.Size(42,20);
      this.eRotoidCount.TabIndex=27;
      this.eRotoidCount.Text="1";
      this.eRotoidCount.TextAlign=System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // bDeletePlaneY
      // 
      this.bDeletePlaneY.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneY.Location=new System.Drawing.Point(23,307);
      this.bDeletePlaneY.Name="bDeletePlaneY";
      this.bDeletePlaneY.Size=new System.Drawing.Size(20,20);
      this.bDeletePlaneY.TabIndex=26;
      this.bDeletePlaneY.Text="Y";
      this.bDeletePlaneY.UseVisualStyleBackColor=true;
      this.bDeletePlaneY.Click+=new System.EventHandler(this.bDeletePlaneY_Click);
      // 
      // bDeletePlaneX
      // 
      this.bDeletePlaneX.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneX.Location=new System.Drawing.Point(2,307);
      this.bDeletePlaneX.Name="bDeletePlaneX";
      this.bDeletePlaneX.Size=new System.Drawing.Size(20,20);
      this.bDeletePlaneX.TabIndex=25;
      this.bDeletePlaneX.Text="X";
      this.bDeletePlaneX.UseVisualStyleBackColor=true;
      this.bDeletePlaneX.Click+=new System.EventHandler(this.bDeletePlaneX_Click);
      // 
      // bDeletePlaneZ
      // 
      this.bDeletePlaneZ.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bDeletePlaneZ.Location=new System.Drawing.Point(44,307);
      this.bDeletePlaneZ.Name="bDeletePlaneZ";
      this.bDeletePlaneZ.Size=new System.Drawing.Size(20,20);
      this.bDeletePlaneZ.TabIndex=24;
      this.bDeletePlaneZ.Text="Z";
      this.bDeletePlaneZ.UseVisualStyleBackColor=true;
      this.bDeletePlaneZ.Click+=new System.EventHandler(this.bDeletePlaneZ_Click);
      // 
      // lDeletePlane
      // 
      this.lDeletePlane.AutoSize=true;
      this.lDeletePlane.Location=new System.Drawing.Point(0,291);
      this.lDeletePlane.Name="lDeletePlane";
      this.lDeletePlane.Size=new System.Drawing.Size(67,13);
      this.lDeletePlane.TabIndex=23;
      this.lDeletePlane.Text="Delete plane";
      // 
      // bInsertPlaneY
      // 
      this.bInsertPlaneY.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneY.Location=new System.Drawing.Point(24,267);
      this.bInsertPlaneY.Name="bInsertPlaneY";
      this.bInsertPlaneY.Size=new System.Drawing.Size(20,20);
      this.bInsertPlaneY.TabIndex=22;
      this.bInsertPlaneY.Text="Y";
      this.bInsertPlaneY.UseVisualStyleBackColor=true;
      this.bInsertPlaneY.Click+=new System.EventHandler(this.bInsertPlaneY_Click);
      // 
      // bInsertPlaneX
      // 
      this.bInsertPlaneX.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneX.Location=new System.Drawing.Point(3,267);
      this.bInsertPlaneX.Name="bInsertPlaneX";
      this.bInsertPlaneX.Size=new System.Drawing.Size(20,20);
      this.bInsertPlaneX.TabIndex=21;
      this.bInsertPlaneX.Text="X";
      this.bInsertPlaneX.UseVisualStyleBackColor=true;
      this.bInsertPlaneX.Click+=new System.EventHandler(this.bInsertPlaneX_Click);
      // 
      // bInsertPlaneZ
      // 
      this.bInsertPlaneZ.Anchor=((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Right)));
      this.bInsertPlaneZ.Location=new System.Drawing.Point(45,267);
      this.bInsertPlaneZ.Name="bInsertPlaneZ";
      this.bInsertPlaneZ.Size=new System.Drawing.Size(20,20);
      this.bInsertPlaneZ.TabIndex=20;
      this.bInsertPlaneZ.Text="Z";
      this.bInsertPlaneZ.UseVisualStyleBackColor=true;
      this.bInsertPlaneZ.Click+=new System.EventHandler(this.bInsertPlaneZ_Click);
      // 
      // lInsertPlane
      // 
      this.lInsertPlane.AutoSize=true;
      this.lInsertPlane.Location=new System.Drawing.Point(1,251);
      this.lInsertPlane.Name="lInsertPlane";
      this.lInsertPlane.Size=new System.Drawing.Size(62,13);
      this.lInsertPlane.TabIndex=19;
      this.lInsertPlane.Text="Insert plane";
      // 
      // pMain
      // 
      this.pMain.CausesValidation=false;
      this.pMain.Dock=System.Windows.Forms.DockStyle.Fill;
      this.pMain.Location=new System.Drawing.Point(0,24);
      this.pMain.Margin=new System.Windows.Forms.Padding(0);
      this.pMain.Name="pMain";
      this.pMain.Size=new System.Drawing.Size(645,421);
      this.pMain.TabIndex=20;
      this.pMain.Paint+=new System.Windows.Forms.PaintEventHandler(this.fmain_Paint);
      this.pMain.MouseMove+=new System.Windows.Forms.MouseEventHandler(this.fmain_MouseMove);
      this.pMain.MouseDown+=new System.Windows.Forms.MouseEventHandler(this.fmain_MouseDown);
      this.pMain.MouseUp+=new System.Windows.Forms.MouseEventHandler(this.fmain_MouseUp);
      // 
      // fmain
      // 
      this.AutoScaleDimensions=new System.Drawing.SizeF(6F,13F);
      this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;
      this.CausesValidation=false;
      this.ClientSize=new System.Drawing.Size(714,445);
      this.Controls.Add(this.pMain);
      this.Controls.Add(this.pControl);
      this.Controls.Add(this.menu);
      this.Icon=((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MainMenuStrip=this.menu;
      this.Name="fmain";
      this.Text="cubes";
      this.menu.ResumeLayout(false);
      this.menu.PerformLayout();
      this.pControl.ResumeLayout(false);
      this.pControl.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menu;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem mFileNew;
    private System.Windows.Forms.ToolStripMenuItem mFileOpen;
    private System.Windows.Forms.ToolStripMenuItem mFileSave;
    private System.Windows.Forms.ToolStripMenuItem mFileSaveAs;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem mFileExportOff;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripMenuItem mFileExit;
    private System.Windows.Forms.ToolStripMenuItem mEdit;
    private System.Windows.Forms.ToolStripMenuItem mEditCut;
    private System.Windows.Forms.ToolStripMenuItem mEditCopy;
    private System.Windows.Forms.ToolStripMenuItem mEditPaste;
    private System.Windows.Forms.ToolStripMenuItem operationToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem mOpFloodFill;
    private System.Windows.Forms.ToolStripMenuItem mOpDoubleSize;
    private System.Windows.Forms.ToolStripMenuItem mOpHalfSize;
    private System.Windows.Forms.ToolStripMenuItem mFilter;
    private System.Windows.Forms.ToolStripMenuItem mFilterNot;
    private System.Windows.Forms.ToolStripMenuItem mOpExtend;
    private System.Windows.Forms.ToolStripMenuItem mFilterBoundary;
    private System.Windows.Forms.ToolStripMenuItem mFilterExpand;
    private System.Windows.Forms.ToolStripMenuItem mFilterImpand;
    private System.Windows.Forms.ToolStripMenuItem mFilterSum;
    private System.Windows.Forms.Button bZUp;
    private System.Windows.Forms.TextBox eZ;
    private System.Windows.Forms.Button bZDown;
    private System.Windows.Forms.TextBox eSize;
    private System.Windows.Forms.TextBox ePen;
    private System.Windows.Forms.ToolStripMenuItem mEditUndo;
    private System.Windows.Forms.ToolStripMenuItem mEditRedo;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.ToolStripMenuItem mView;
    private System.Windows.Forms.Button bRotXP;
    private System.Windows.Forms.Button bRotXN;
    private System.Windows.Forms.Button bRotYN;
    private System.Windows.Forms.Button bRotYP;
    private System.Windows.Forms.Button bRotZN;
    private System.Windows.Forms.Button bRotZP;
    private System.Windows.Forms.Button bFill3D;
    private System.Windows.Forms.Button bPen;
    private System.Windows.Forms.Button bFill2D;
    private System.Windows.Forms.Button bMirrZ;
    private System.Windows.Forms.Button bAutoSize;
    private System.Windows.Forms.Timer timer;
    private System.Windows.Forms.ToolStripMenuItem mFileExportBmp;
    private System.Windows.Forms.ToolStripMenuItem mFileExport3D;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripMenuItem mEditDelete;
    private System.Windows.Forms.ToolStripMenuItem mMesh;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
    private System.Windows.Forms.ToolStripMenuItem mMeshColor;
    private System.Windows.Forms.ToolStripMenuItem mFileExportSVG;
    private System.Windows.Forms.ToolStripMenuItem mMeshLight;
    private System.Windows.Forms.ToolStripMenuItem mMeshWires;
    private System.Windows.Forms.ToolStripMenuItem mViewAlign;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    private System.Windows.Forms.ToolStripMenuItem mOpInsertPlane;
    private System.Windows.Forms.ToolStripMenuItem mFilePrint;
    private System.Windows.Forms.ToolStripMenuItem mOpDeletePlane;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
    private System.Windows.Forms.ToolStripMenuItem mFileViewMesh;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
    private System.Windows.Forms.Panel pControl;
    private System.Windows.Forms.Panel pMain;
    private System.Windows.Forms.ToolStripMenuItem mViewFullscreen;
    private System.Windows.Forms.Button bInsertPlaneZ;
    private System.Windows.Forms.Label lInsertPlane;
    private System.Windows.Forms.Button bInsertPlaneY;
    private System.Windows.Forms.Button bInsertPlaneX;
    private System.Windows.Forms.Button bDeletePlaneY;
    private System.Windows.Forms.Button bDeletePlaneX;
    private System.Windows.Forms.Button bDeletePlaneZ;
    private System.Windows.Forms.Label lDeletePlane;
    private System.Windows.Forms.ToolStripMenuItem mViewMesh;
    private System.Windows.Forms.ToolStripMenuItem mMeshTriangulation;
    private System.Windows.Forms.ToolStripMenuItem mMeshPrecise;
    private System.Windows.Forms.ToolStripMenuItem mMeshScale;
    private System.Windows.Forms.ToolStripMenuItem mMeshRotoid;
    private System.Windows.Forms.TextBox eRotoidCount;
    private System.Windows.Forms.Label lRotoid;
    private System.Windows.Forms.Label lPen;
    private System.Windows.Forms.ToolStripMenuItem mMeshRelax;
    private System.Windows.Forms.ToolStripMenuItem mHelp;
    private System.Windows.Forms.ToolStripMenuItem mHelpHelp;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
    private System.Windows.Forms.ToolStripMenuItem mHelpAbout;
  }
}

