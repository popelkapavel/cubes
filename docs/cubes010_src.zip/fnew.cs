﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace cubes {
  public partial class fnew:Form {
    fmain f;
    public fnew(fmain f) {
      InitializeComponent();
      this.f=f;
    }

    private void bOK_Click(object sender,EventArgs e) {
      int x,y,z;
      if(int.TryParse(eX.Text,out x)&&int.TryParse(eY.Text,out y)&&int.TryParse(eZ.Text,out z)) 
        New(x,y,z);
    }

    private void bCube_Click(object sender,EventArgs e) {
      int x;
      if(int.TryParse(eX.Text,out x)) 
        New(x,x,x);
    }
    void New(int x,int y,int z) {    
      f.New(x,y,z);
      f.SetMode(ViewModes.Edit,Conversion.Normal);
      Close();  
    }
  }
}
