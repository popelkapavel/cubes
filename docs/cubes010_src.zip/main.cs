﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

[assembly: AssemblyVersion("0.10.0.0")]

namespace cubes {
  static class main {
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main(string[] arg) {      
      string filename=arg.Length>0?arg[0]:null;
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new fmain(filename));
    }
  }
}
