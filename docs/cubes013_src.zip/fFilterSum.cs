﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace cubes {
  public partial class fFilterSum:Form {
    fmain f;
    public fFilterSum(fmain f) {
      InitializeComponent();
      this.f=f;
    }

    private void bOK_Click(object sender,EventArgs e) {
      int rule,count;
      if(int.TryParse(eRule.Text,out rule)&&int.TryParse(eCount.Text,out count)) {      
        if(count<1) count=1;
        while(count-->0)
          f.b3d.sumfilter(rule);
        f.lazydraw=true;
      }  
      Close();  
    }

    private void bCube_Click(object sender,EventArgs e) {
      Close();
    }
  }
}
