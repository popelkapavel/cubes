﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.IO;
using Math3d;

namespace Mesh3d {
  public class mesh {
    public points pts;
    public faces fcs;
    public mesh() {
      pts=new points(8);
      fcs=new faces(16);
    }    
    public mesh(mesh m) {
      pts=new points(m.pts);
      fcs=new faces(m.fcs);
    }
    public void Append(mesh m) {
      int p2=pts.Count;
      pts.Append(m.pts);
      fcs.Append(m.fcs,p2);      
    }
    public void Join(double dist) {
      fcs.Join(pts.Join(dist));      
    }
    public void FaceCenter(int f,double[] center) {
      center[0]=center[1]=center[2]=0;
      for(int i=1;i<=fcs.f[f];i++) 
        d3.add(center,0,center,0,pts.p,3*fcs.f[f+i]);
      d3.mul_d(center,center,1.0/fcs.f[f]);  
    }
    public void FaceNormal(int f,double[] normal) {
      FaceNormal(pts.p,f,normal);
      /*double[] d1=new double[3],d2=new double[3];
      d3.sub(d1,0,pts.p,3*fcs.f[f+2],pts.p,3*fcs.f[f+1]);
      d3.sub(d2,0,pts.p,3*fcs.f[f+3],pts.p,3*fcs.f[f+1]);
      d3.normal(normal,d3.cross(d1,d1,d2));*/
    }
    public void FaceNormal(double[] pts,int f,double[] normal) {
      double[] d1=new double[3],d2=new double[3];
      d3.sub(d1,0,pts,3*fcs.f[f+2],pts,3*fcs.f[f+1]);
      d3.sub(d2,0,pts,3*fcs.f[f+3],pts,3*fcs.f[f+1]);
      d3.normal(normal,d3.cross(d1,d1,d2));
    }
    
    public double[] PointsNormals() {
      double[] normals=new double[3*pts.Count],vp=new double[3],vn=new double[3],fn=new double[3];
      int[] w=new int[pts.Count];
      for(int h=0;h<fcs.N;h+=fcs.A) {
        int n=fcs.f[h++];
        int i1=fcs.f[h],ip=fcs.f[h+n-1];
        int in_=i1;
        while(n-->0) {
          int i=fcs.f[h++];
          in_=n>0?fcs.f[h]:i1;
          d3.sub(vp,0,pts.p,ip*3,pts.p,i*3);
          d3.sub(vn,0,pts.p,in_*3,pts.p,i*3);
          d3.normal(fn,d3.cross(fn,vn,vp));
          w[i]++;
          d3.normal(normals,3*i,d3.linear_interpol(normals,3*i,1.0/w[i],normals,3*i,fn,0),0);
          ip=i;
        }        
      }
      return normals;
    }

    internal class PointComparer:IComparer<int> {
      double[] pts;
      int axis;
      internal PointComparer(int axis,double[] pts) {
        this.axis=axis;this.pts=pts;
      }
      public int Compare(int a,int b) {
        double da=pts[3*a+axis],db=pts[3*b+axis];
        return da<db?-1:da>db?1:0;
      }
    }
    
    public bool[] PointsInShadow(double[] light) {
      double[] rota=d33.M(1),l=d3.V(),a=d3.V(),b=d3.V(),c=d3.V();
      d3.normal(l,d3.mul_d(l,light,-1));
      d33.rotation_vv(rota,d3.VZ,l);
            
      bool[] sha=new bool[pts.Count];
      int[] idx=new int[sha.Length];
      double[] p=new double[pts.Count*3];
      for(int i=0;i<sha.Length;i++) {
        d3.mul_d33(p,3*i,pts.p,3*i,rota);
        idx[i]=i; 
      }
      Array.Sort(idx,0,idx.Length,new PointComparer(0,p));      
      for(int h=0;h<fcs.N;h+=fcs.A) {
        int n=fcs.f[h++];
        if(n<3) {h+=n;continue;}
        int p1=3*fcs.f[h++],p2,p3=3*fcs.f[h++];
        n-=2;
        while(n-->0) {
          p2=p3;
          p3=3*fcs.f[h++];
          double x1=p[p2]-p[p1],y1=p[p2+1]-p[p1+1];
          double x2=p[p3]-p[p2],y2=p[p3+1]-p[p2+1];
          double x3=p[p1]-p[p3],y3=p[p1+1]-p[p3+1];
          double t,lr=(p[p3]-p[p1])*y1-(p[p3+1]-p[p1+1])*x1;
          if(lr==0) continue;          
          double r,ix=p[p1],ax=ix,iy=p[p1+1],ay=iy,iz=p[p1+2];
          r=p[p2];if(r<ix) ix=r;else if(r>ax) ax=r;
          r=p[p2+1];if(r<iy) iy=r;else if(r>ay) ay=r;
          r=p[p2+2];if(r<iz) iz=r;
          r=p[p3];if(r<ix) ix=r;else if(r>ax) ax=r;
          r=p[p3+1];if(r<iy) iy=r;else if(r>ay) ay=r;
          r=p[p3+2];if(r<iz) iz=r;
          bool blr=lr<0;
          int ib=0,ie=sha.Length-1,im;
          while(ib<ie) {
            im=(ib+ie)/2;
            double mx=p[3*idx[im]];
            if(mx<ix) ib=im+1;
            else ie=im-1;
          }
          for(int i=ib;i<sha.Length;i++) {      
            int pi=3*idx[i];            
            if(p[pi]>ax) break;
            if(sha[idx[i]]) continue;
            if(p1==pi||p2==pi||p3==pi) continue;
            //if(p[pi]<ix||p[pi]>ax) continue;
            //if(p[pi+1]<iy||p[pi+1]>ay) continue;
            if(iz>p[pi+2]) continue;
            //if(p[p1+2]>p[pi+2]&&p[p2+2]>p[pi+2]&&p[p3+2]>p[pi+2]) continue;
            t=(p[pi]-p[p1])*y1-(p[pi+1]-p[p1+1])*x1;
            if(blr?t>0:t<0) continue;
            t=(p[pi]-p[p2])*y2-(p[pi+1]-p[p2+1])*x2;
            if(blr?t>0:t<0) continue;
            t=(p[pi]-p[p3])*y3-(p[pi+1]-p[p3+1])*x3;
            if(blr?t>0:t<0) continue;
            sha[idx[i]]=true;
          }
        }
      }
      return sha;
    }
/*        
    public bool[] PointsInShadow2(double[] light) {
      double[] rota=d33.M(1),l=d3.V(),a=d3.V(),b=d3.V(),c=d3.V();
      d3.normal(l,d3.mul_d(l,light,-1));
      d33.rotation_vv(rota,d3.VZ,l);
            
      bool[] sha=new bool[pts.Count];
      double[] p=new double[pts.Count*3];
      for(int i=0;i<sha.Length;i++)
        d3.mul_d33(p,3*i,pts.p,3*i,rota);
      for(int i=0;i<sha.Length;i++) {      
        bool sh=false;
        int pi=3*i;
        for(int h=0;h<fcs.N;h+=fcs.A) {
          int n=fcs.f[h++];
          if(n<3) {h+=n;continue;}
          int p1=3*fcs.f[h++],p2,p3=3*fcs.f[h++];
          n-=2;
          while(n-->0) {
            p2=p3;
            p3=3*fcs.f[h++];
            if(p1==pi||p2==pi||p3==pi) continue;
            if(p[p1+2]>p[pi+2]&&p[p2+2]>p[pi+2]&&p[p3+2]>p[pi+2]) continue;
            double cx=p[p2]-p[p1],cy=p[p2+1]-p[p1+1];
            double t,lr=(p[p3]-p[p1])*cy-(p[p3+1]-p[p1+1])*cx;
            if(lr==0) continue;
            t=(p[pi]-p[p1])*cy-(p[pi+1]-p[p1+1])*cx;
            if(lr<0?t>0:t<0) continue;
            t=(p[pi]-p[p2])*(p[p3+1]-p[p2+1])-(p[pi+1]-p[p2+1])*(p[p3]-p[p2]);
            if(lr<0?t>0:t<0) continue;
            t=(p[pi]-p[p3])*(p[p1+1]-p[p3+1])-(p[pi+1]-p[p3+1])*(p[p1]-p[p3]);
            if(lr<0?t>0:t<0) continue;
            sh=true;
            goto shadow;
          }
        }
       shadow: 
        sha[i]=sh;
      }
      return sha;
    }*/
    
    public void Shadows(double[] light,double weight) {
      bool[] sha=PointsInShadow(light);
      for(int h=0;h<fcs.N;h+=fcs.A) {
        int s=0,n=fcs.f[h++];
        for(int i=0;i<n;i++)
          if(sha[fcs.f[h++]]) s++;
        if(s>0) {
          double d=1-weight*(double)s/n;
          fcs.f[h]=faces.RGBd(fcs.f[h],d);
        }  
          
      }
    }
    
    public string ExportOff(string filename) {
     StreamWriter sw=null;
     try { 
      sw=new StreamWriter(filename);
      int n,h;
      sw.WriteLine("{0} {1}",pts.Count,fcs.Faces());
      pts.Write(sw,"{0} {1} {2}\r\n");
      sw.WriteLine();
      for(h=0;h<fcs.N;) {
        n=fcs.f[h++];
        sw.Write(""+n);
        while(n-->0) sw.Write(" "+fcs.f[h++]);
        h+=fcs.A;
        sw.WriteLine();
      }
      return null;
     } catch(Exception ex) {
      return ex.Message; 
     } finally {
      if(sw!=null) sw.Close();     
     }
    }
    public string ExportObj(string filename) {
     StreamWriter sw=null;
     try { 
      sw=new StreamWriter(filename);
      int n,h;
      sw.WriteLine("# wavefront {0} points  {1} faces",pts.Count,fcs.Faces());
      pts.Write(sw,"v {0} {1} {2}\r\n");
      sw.WriteLine();
      for(h=0;h<fcs.N;) {
        n=fcs.f[h++];
        sw.Write("f");
        while(n-->0) sw.Write(" "+(fcs.f[h++]+1));
        h+=fcs.A;
        sw.WriteLine();
      }
      return null;
     } catch(Exception ex) {
      return ex.Message; 
     } finally {
      if(sw!=null) sw.Close();     
     }
    }
    public string ExportVrml(string filename,int color,double[] light) {
      StreamWriter sw=null;
     try {
      sw=new StreamWriter(filename);
      sw.WriteLine("#VRML V1.0 ascii\nSeparator {");
      sw.WriteLine("Material {{ diffuseColor {0} {1} {2}}}",(color&255)/255.0,((color>>8)&255)/255.0,((color>>16)&255)/255.0);
      sw.WriteLine("DirectionalLight {{ direction {0} {1} {2} }}",light[0],light[1],light[2]);
      sw.WriteLine("Coordinate3 {");
      sw.WriteLine("point [");
      pts.Write(sw,"{0} {1} {2}\r\n");
      sw.WriteLine("  0 0 0]\n }\n IndexedFaceSet {\n  coordIndex [");
      int h,n;
      for(h=0;h<fcs.N;) {
        n=fcs.f[h++];
        while(n-->0) sw.Write(" "+fcs.f[h++]+",");
        h+=fcs.A;
        sw.WriteLine("-1,");
      }
      sw.WriteLine(" 0,0,0,-1]\n  }\n}\n");
      return null;
     } catch(Exception ex) {
      return ex.Message;
     } finally {
       if(sw!=null) sw.Close();
     }
    }
    public string ExportPov(string filename,bool normals,bool colors) {
     StreamWriter sw=null;
     try { 
      sw=new StreamWriter(filename);
      int n,h;
      sw.WriteLine("vertex_vectors {{ {0}\r\n",pts.Count);
      pts.Write(sw," ,<{0},{1},{2}>\r\n");
      sw.WriteLine("}");
      
      if(normals) {
        double[] vn=PointsNormals();
        sw.WriteLine("normal_vectors {{ {0}\r\n",pts.Count);
        for(h=0;h<vn.Length;h+=3)
          sw.WriteLine(" ,<{0},{1},{2}>",vn[h],vn[h+1],vn[h+2]);
        sw.WriteLine("}");
      }
      if(colors) {
        sw.WriteLine("texture_list {{ {0}",fcs.Faces());
        for(h=0;h<fcs.N;h+=fcs.A) {
          h+=1+fcs.f[h];
          int rgb=fcs.f[h];
          sw.WriteLine("texture{{pigment{{rgb<{0},{1},{2}>/255}}}}",rgb&255,(rgb>>8)&255,(rgb>>16)&255);
        }
        sw.WriteLine("}");
      }
      
      sw.WriteLine("face_indices {{ {0}",fcs.Triangles());
      int i=0;
      for(h=0;h<fcs.N;i++) {
        n=fcs.f[h++];
        //sw.Write("f");
        for(int j=1;j<n-1;j++) {
          sw.Write(",<{0},{1},{2}>",fcs.f[h],fcs.f[h+j],fcs.f[h+j+1]);
          if(colors)
            sw.Write(",{0}",i);
        }
        h+=n+fcs.A;
        sw.WriteLine();
      }      
      sw.WriteLine("}");
      return null;
     } catch(Exception ex) {
      return ex.Message; 
     } finally {
      if(sw!=null) sw.Close();     
     }
    }
    
    internal double PainterDepth(int h,double[] pts,out double depth2,out double depth3) {
      double depth=0;
      depth2=depth3=depth;
      int n=fcs.f[h++];
      while(n-->0) {
        int p=3*fcs.f[h++];
        double d=pts[p]*pts[p]+pts[p+1]*pts[p+1]+pts[p+2]*pts[p+2];
        if(d>=depth) depth=d;
        else if(d>=depth2) depth2=d;
        else if(d>=depth3) depth3=d;
      }      
      return depth;
    }
    internal class PainterComparer:IComparer<int> {
      mesh m;
      double[] pts;
      internal PainterComparer(mesh m,double[] pts) {
        this.m=m;this.pts=pts;
      }
      public int Compare(int a,int b) {
        double a2,a3,da=m.PainterDepth(a,pts,out a2,out a3),b2,b3,db=m.PainterDepth(b,pts,out b2,out b3);
        return da<db?1:da>db?-1:a2<b2?1:a2>b2?-1:a3<b3?1:a3>b3?-1:0;
      }
    }
    
    internal int PainterSort(double[] pts,double zmin,out int[] fa) {
      fa=new int[fcs.N];
      int fe,h,n;
      for(fe=0,h=0;h<fcs.N;h+=fcs.A) {
        bool ok=true;
        fa[fe]=h;
        n=fcs.f[h++];
        while(n-->0) {
          int p=3*(fcs.f[h++]);
          if(pts[p+2]<zmin) ok=false;
        } 
        if(ok) fe++;
      }
      Array.Sort(fa,0,fe,new PainterComparer(this,pts));
      return fe;
    }
    string Int2HtmlColor(int c) {
      char[] cha=new char[7];
      c=((c>>16)&255)|(c&0xff00)|((c&255)<<16);
      cha[0]='#';
      for(int i=6;i>0;i--) {
        int x=c&15;
        cha[i]=(char)(x<10?'0'+x:'A'+x-10);
        c>>=4;
      }        
      return new string(cha);
    }
    string atof(double x) {
      return x.ToString(System.Globalization.CultureInfo.InvariantCulture);
    }
    
    public string ExportSVG(double[] pts,int color,bool wirefront,int width,int height,double angle,double zmin,string filename) {
      StreamWriter sw=null;
     try {
      sw=new StreamWriter(filename);
      sw.Write("<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n"
        +"<svg xmlns:svg='http://www.w3.org/2000/svg' xmlns='http://www.w3.org/2000/svg' version='1.0' width='"+width+"' height='"+height+"' id='xx'>\n"
        +(color==-1?" <rect width='632' height='529' style='fill:#000000;stroke:#000000;' />":null)
        +" <g  d='layer1' style='stroke-linejoin:round;stroke-width:0.25;fill:none"+(color==-1?null:";stroke:"+Int2HtmlColor(color))+"'>\n");
      
      int[] fa;
      int fh,h,n,fe=PainterSort(pts,zmin,out fa);
      double c=width/2.0/Math.Tan(angle/2*Math.PI/180);
      double[] normal=null,normal2=null;
      for(fh=0;fh<fe;fh++) {
        h=fa[fh];
        int fill=0xffffff;
        sw.Write("  <path d='M");
        n=fcs.f[h++];
        while(n-->0) {
          int p=3*(fcs.f[h++]);
          double x=width/2+c*pts[p]/pts[p+2],y=height/2.0+c*pts[p+1]/pts[p+2];
          sw.Write("{0:.0} {1:.0} {2}",x,y,(n>0?'L':'z'));
          //sw.Write(atof(x)+','+atof(y)+' '+(n>0?'L':'z'));
        }
        fill=fcs.f[h];
        bool solid=true;
        if(wirefront) {
          if(normal==null) {
            normal=d3.V();
            normal2=d3.V();
          }
          FaceNormal(pts,fa[fh],normal);
          d3.normal(normal2,0,pts,fcs.f[fa[fh]+1]*3);
          double s=d3.scalar(normal,normal2);
          solid=s>=0;
        }
        if(solid)
          sw.Write("' style='fill:"+Int2HtmlColor(fill)+(color==-1?";stroke:"+Int2HtmlColor(fill):null)+";' />\n");
        else
          sw.Write("' style='stroke:"+Int2HtmlColor(fill)+";' />\n");
      }      
      sw.Write(" </g>\n</svg>");  
      return null;
     } catch(Exception ex) {
      return ex.Message;
     } finally {
      if(sw!=null) sw.Close();
     }
    }

    static string PDFColor(int color,bool stroke) {
      return string.Format("{0:.000} {1:.000} {2:.000} {3}",
        (color&255)/255.0,((color>>8)&255)/255.0,((color>>16)&255)/255.0,stroke?"RG":"rg");    
    }
    public string ExportPDF(double[] pts,int color,bool wirefront,int width,int height,double angle,double zmin,string filename) {
      StreamWriter sw=null;
     try {
      sw=new StreamWriter(filename);
      sw.Write(@"%PDF-1.0
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj


2 0 obj
<<
/Type /Pages
/Count 1
/Kids[3 0 R]
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/Resources << /ProcSet 5 0 R>>
/MediaBox[0 0 "+width+" "+height+@"]
/Contents 4 0 R
>>
endobj

4 0 obj
<< /Length "+width+@" >>
stream

1 j
.1 w
");
      bool wires=color!=-1;      
      if(!wires) sw.WriteLine("0 0 0 rg\n-1 -1 "+(width+1)+" "+(height+1)+" re f");
      sw.WriteLine(PDFColor(color,true));
      int[] fa;
      int fh,h,n,fe=PainterSort(pts,zmin,out fa);
      double c=width/2.0/Math.Tan(angle/2*Math.PI/180);
      double[] normal=null,normal2=null;
      bool wire=false;
      for(fh=0;fh<fe;fh++) {
        h=fa[fh];
        int fill=0xffffff;
        n=fcs.f[h++];
        fill=fcs.f[h+n];
        bool solid=true;
        if(wirefront) {
          if(normal==null) {
            normal=d3.V();
            normal2=d3.V();
          }
          FaceNormal(pts,fa[fh],normal);
          d3.normal(normal2,0,pts,fcs.f[fa[fh]+1]*3);
          double s=d3.scalar(normal,normal2);
          solid=s>=0;
        }
        if(solid) {         
          if(wire) sw.WriteLine(PDFColor(color,true));
          sw.WriteLine(PDFColor(fill,false)+(wires?null:" "+PDFColor(fill,true)));
          wire=false;
        } else {
          sw.WriteLine(PDFColor(fill,true));
          wire=true;
        } 
        char ch='m';  
        while(n-->0) {
          int p=3*(fcs.f[h++]);
          double x=width/2+c*pts[p]/pts[p+2],y=height/2.0+c*pts[p+1]/pts[p+2];
          sw.WriteLine("{0:.0} {1:.0} {2}",x,height-y,ch);
          ch='l';
        }
        sw.WriteLine(wire?'s':'b');// 'f' for just fill
      }
sw.Write(@"endstream
endobj

5 0 obj
[
/PDF
]
endobj

xref
0 6
0000000000 65535 f
0000000016 00000 n
0000000086 00000 n
0000000136 00000 n
0000000200 00000 n
0000000328 00000 n
trailer
<<
/Size 8
/Root 1 0 R
>>
startxref
1110
%%EOF");            
      return null;
     } catch(Exception ex) {
      return ex.Message;
     } finally {
      if(sw!=null) sw.Close();
     }
    }

    public void Draw2D(IntPtr fdc,double[] pts,int color,bool wirefront,int width,int height,double angle,double zmin) {
      IntPtr solidpen=GDI.GetStockObject(color==-1?GDI.StockObjects.NULL_PEN:GDI.StockObjects.BLACK_PEN);
      GDI.SelectObject(fdc,solidpen);
      //xdpi=GDI.GetDeviceCaps(fdc,88);
      //ydpi=GDI.GetDeviceCaps(fdc,90);
      //Dictionary<int,IntPtr> brushes=new Dictionary<int,IntPtr>();
      IntPtr brush,brush2=IntPtr.Zero,pen=IntPtr.Zero,pen2=IntPtr.Zero;
      int[] fa;
      int fh,h,n,n2,fe=PainterSort(pts,zmin,out fa),g;
      double c=width/2.0/Math.Tan(angle/2*Math.PI/180);
      POINT[] pt2=new POINT[16];
      double[] normal=null,normal2=null;
      for(fh=0;fh<fe;fh++) {
        h=fa[fh];
        int fill=0xffffff;
        n2=n=fcs.f[h++];
        if(pt2.Length<2*n) Array.Resize(ref pt2,2*n);
        g=0;
        while(n-->0) {
          int p=3*(fcs.f[h++]);
          double x=width/2+c*pts[p]/pts[p+2],y=height/2.0+c*pts[p+1]/pts[p+2];
          pt2[g].x=(int)x;
          pt2[g++].y=(int)y;
        }
        fill=fcs.f[h];
        bool solid=true;
        if(wirefront) {
          if(normal==null) {
            normal=d3.V();
            normal2=d3.V();
          }
          FaceNormal(pts,fa[fh],normal);
          d3.normal(normal2,0,pts,fcs.f[fa[fh]+1]*3);
          double s=d3.scalar(normal,normal2);
          solid=s>=0;
        }
        if(solid) {
          if(pen!=IntPtr.Zero) {
            pen2=GDI.SelectObject(fdc,solidpen);
            GDI.DeleteObject(pen2);
            pen=IntPtr.Zero;
          }
          brush=GDI.CreateSolidBrush(fill);
          brush2=GDI.SelectObject(fdc,brush);
          GDI.Polygon(fdc,pt2,n2);
          GDI.DeleteObject(brush2);
        } else {
          pen=GDI.CreatePen(GDI.PenStyles.PS_SOLID,0,fill);
          pen2=GDI.SelectObject(fdc,pen);
          GDI.Polyline(fdc,pt2,n2);
          GDI.DeleteObject(pen2);          
        }  
      }      
    }
    public string ExportEMF(double[] pts,int color,bool wirefront,int width,int height,double angle,double zmin,string filename,IntPtr hdc) {
      //int xdpi=GDI.GetDeviceCaps(hdc,88),ydpi=GDI.GetDeviceCaps(hdc,90);
      int xsiz=GDI.GetDeviceCaps(hdc,4)*100,xres=GDI.GetDeviceCaps(hdc,8);
      int ysiz=GDI.GetDeviceCaps(hdc,6)*100,yres=GDI.GetDeviceCaps(hdc,10);
      RECT r=new RECT() {Right=width*xsiz/xres,Bottom=height*ysiz/yres};
      IntPtr fdc=GDI.CreateEnhMetaFile(hdc,filename,ref r,null);
      if(color==-1)
        GDI.FillRect(fdc,ref r,GDI.GetStockObject(GDI.StockObjects.BLACK_BRUSH));
     try {   
      Draw2D(fdc,pts,color,wirefront,width,height,angle,zmin);
      return null;
     } catch(Exception ex) {
      return ex.Message;
     } finally {
      IntPtr edc=GDI.CloseEnhMetaFile(fdc);
      if(filename==null) {
        if(WINAPI.OpenClipboard(IntPtr.Zero)) {
          WINAPI.EmptyClipboard();
          WINAPI.SetClipboardData(14/*CF_ENHMETAFILE*/,edc);
          WINAPI.CloseClipboard();
        }  
      }
      GDI.DeleteEnhMetaFile(edc); 
     }
    }
    
/*int MeshExportVRML(Mesh *m,char *filename) {
  FILE *f;
  int n,*h,*he;

  if(!(f=fopen(filename,"w")))
    return 0;

  fputs(
      "#VRML V1.0 ascii\nSeparator {\n"
      "Material { diffuseColor 0.3 0.8 0.9}\n"
      "Coordinate3 {\n"
      "point [\n",f);
  PointsFPrintf(&m->pts,f,"  %f %f %f,\n");

  fputs("  0 0 0]\n }\n IndexedFaceSet {\n  coordIndex [\n",f);

  for(h=m->fcs.r,he=h+m->fcs.n;h<he;) {
    n=*h++;
    while(n--) fprintf(f," %d,",*h++);
    h+=m->fcs.a;
    fputs("-1,\n",f);
  }
  fputs(" 0,0,0,-1]\n  }\n}\n",f);
  fclose(f);
  return 1;
}*/
        
    static bool ParseInt(ref int h,string s,out int i) {
      i=0;
      if(s==null||h<0||h>=s.Length) return false;
      while(h<s.Length&&char.IsWhiteSpace(s[h])) h++;
      bool neg=false;
      if(h<s.Length&&s[h]=='-') {neg=true;h++;}
      while(h<s.Length) {
        char ch=s[h];
        if(ch<'0'||ch>'9') break;
        i=i*10+ch-'0';
        h++;
      }
      if(neg) i=-i;
      return true;
    }
    static double log10=Math.Log(10);
    static bool ParseDouble(ref int h,string s,out double d,out double dec) {
      d=dec=0;
      if(s==null||h<0||h>=s.Length) return false;
      while(h<s.Length&&char.IsWhiteSpace(s[h])) h++;
      if(h<0||h>=s.Length) return false;
      bool neg=s[h]=='-';
      if(neg) h++;
      int digi=0;
      while(h<s.Length) {
        char ch=s[h];
        if(ch>='0'&&ch<='9') {
          d=d*10+(ch-'0');
          dec*=10;
          digi++;
        } else if(ch=='.'||ch==',') 
          dec=1;
         else
          break;
        h++;
      }
      if(digi<1) return false;
      if(dec<1) dec=1;
      if(h<s.Length&&(s[h]=='e'||s[h]=='E')) {
        h++;
        int exp;
        if(!ParseInt(ref h,s,out exp))
          return false;
        if(exp!=0) {  
          double mul;
          switch(exp) {
           case -6:dec*=1000000;break;
           case -5:dec*=100000;break;
           case -4:dec*=10000;break;
           case -3:dec*=1000;break;
           case -2:dec*=100;break;
           case -1:dec*=10;break;
           case 1:dec/=10;break;
           case 2:dec/=100;break;
           case 3:dec/=1000;break;
           case 4:dec/=10000;break;
           case 5:dec/=100000;break;
           case 6:dec/=1000000;break;
           default:dec*=Math.Exp(-log10*exp);break;
          }   
        }  
      }
      if(neg) d=-d;
      return true;
    }    
    static bool ParseDouble(ref int h,string s,out double d) {
      double dec;
      bool ok=ParseDouble(ref h,s,out d,out dec);
      if(ok) d/=dec;
      return ok;
    }
    public string ImportOff(string filename) {
     StreamReader sr=null; 
     try {
      sr=new StreamReader(filename);
      int p=0,pi=0,f=0,fi=0,s=0;
      double[] d=new double[3];
      int[] pt=new int[8];
      string line;
      while(null!=(line=sr.ReadLine())) {        
        int h=0;
        while(h<line.Length&&char.IsWhiteSpace(line[h])) h++;
        if(h>=line.Length) continue;
        if(line[h]=='#') continue;
        switch(s) {
         case 0:
          ParseInt(ref h,line,out p);ParseInt(ref h,line,out f);
          pts.Alloc(p);
          fcs.Alloc(f*(4+fcs.A));
          s=1;
          break;
         case 1:
          ParseDouble(ref h,line,out d[0]);
          ParseDouble(ref h,line,out d[1]);
          ParseDouble(ref h,line,out d[2]);
          pts.Add(d);
          pi++;
          if(pi>=p) s=2;
          break;
         case 2:
          int n;
          ParseInt(ref h,line,out n);
          if(pt.Length<n) pt=new int[n];
          for(int i=0;i<n;i++)
            ParseInt(ref h,line,out pt[i]);
          fcs.Face(n,pt,0,POINTS.None);
          fi++;
          if(fi>=f) s=3;
          break;
        }
      }
      sr.Close();
      return null; 
     } catch(Exception ex) {
       if(sr!=null) sr.Close();
       return ex.Message;
     }
    }
    public string ImportObj(string filename) {
     StreamReader sr=null; 
     try {
      sr=new StreamReader(filename);
      int p=0,pi=0,f=0,fi=0,s=0;
      double[] d=new double[3];
      int[] pt=new int[8];
      string line;
      while(null!=(line=sr.ReadLine())) {        
        int h=0;
        while(h<line.Length&&char.IsWhiteSpace(line[h])) h++;
        if(h>=line.Length-2) continue;
        if(line[h]=='#') continue;
        if(line[h]=='v'&&line[h+1]==' ') {
          h+=2;
          ParseDouble(ref h,line,out d[0]);
          ParseDouble(ref h,line,out d[1]);
          ParseDouble(ref h,line,out d[2]);
          pi=pts.Count*3;
          pts.append_space(1);
          d3.copy(pts.p,pi,d,0);          
        } else if(line[h]=='f'&&line[h+1]==' ') {
          h+=2;
          int n=0,i;
          while(h<line.Length&&ParseInt(ref h,line,out i)) {
            if(n>=pt.Length) Array.Resize(ref pt,pt.Length*2);
            pt[n++]=i-1;
            while(h<line.Length&&!char.IsWhiteSpace(line,h)) h++;
          }
          if(n>2) {
            fcs.Face(n,pt,0,POINTS.None);
          }
        }
      }
      sr.Close();
      return null; 
     } catch(Exception ex) {
       if(sr!=null) sr.Close();
       return ex.Message;
     }
    }
    int PgmNumber(FileStream fs) {
      int n=0,ch;
      bool digi=false;
     again: 
      while((ch=fs.ReadByte())>0) {
        if(!digi&&(ch==' '||ch=='\r'||ch=='\n'))
          continue;
        if(ch=='#') {
          while((ch=fs.ReadByte())>0)
            if(ch=='\n')
              if(n==0) goto again;
            else
              return n;  
          return n;
        }
        if(ch<'0'||ch>'9') return n;
        digi=true;
        n=n*10+(ch-'0');
      }
      return n;
    }
    public string ImportPgm(string filename) {
      FileStream fs=null;
     try {
      fs=new FileStream(filename,FileMode.Open,FileAccess.Read,FileShare.Read);
      int a=fs.ReadByte(),b=fs.ReadByte();
      if(a!='P'||(b!='2'&&b!='5'))
        return "not pgm";      
      bool ascii=b=='2';
      fs.ReadByte();
      int width=PgmNumber(fs),height=PgmNumber(fs),max=PgmNumber(fs);
      pts.Array2D(d3.V0,new double[] {width,0,0},new double[] {0,0,height},width,height);
      int he=width*height;      
      for(int h=0;h<he;h++) {
        double y;
        if(ascii) y=PgmNumber(fs);
        else y=fs.ReadByte();
        pts.p[3*h+1]=y;
      }  
      fcs.Array2D(0,width,height,POINTS.None);
      fs.Close();
      return null;
     } catch(Exception ex) {
      return ex.Message;
     } finally {
       if(fs!=null) fs.Close();
     }
    }
    // primitives
    public bool Sphere(double[] center,double[] rota,double[] scale,int layers,int halfcircles,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Sphere(center,rota,scale,layers,halfcircles)
          ||!fcs.Rotoid(pbase,layers,halfcircles,POINTS.CAP|POINTS.CAP2|(mode&POINTS.REVERSE))) {
        pts.Count=pbase;
        return false;
      }  
      return true;
    }
    public bool Cylinder(double[] center,double[] scale,int layers,int circles,int radials,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Cylinder(center,scale,layers,circles,radials)
          ||!fcs.Rotoid(pbase,layers+2*circles,radials,POINTS.CAP|POINTS.CAP2|(mode&POINTS.REVERSE))) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    public bool Cone(double[] center,double[] scale,int layers,int circles,int radials,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Cone(center,scale,layers,circles,radials)
          ||!fcs.Rotoid(pbase,layers+circles-2,radials,POINTS.CAP|POINTS.CAP2|(mode&POINTS.REVERSE))) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
// box 
    public bool Box(double[] center,double[] scale,int xres,int yres,int zres,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Box(center,scale,xres,yres,zres)
          ||!fcs.Box(pbase,xres,yres,zres,mode&POINTS.REVERSE)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    public bool Tetrahedron(double[] center,double[] scale,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Tetrahedron(center,scale)
           ||!fcs.Tetrahedron(pbase,mode)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }   

    public bool Hexahedron(double[] center,double[] scale,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Hexahedron(center,scale)
          ||!fcs.Hexahedron(pbase,mode)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    public bool Octahedron(double[] center,double[] scale,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Octahedron(center,scale)
          ||!fcs.Octahedron(pbase,mode)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    public bool Dodecahedron(double[] center,double[] scale,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Dodecahedron(center,scale)
          ||!fcs.Dodecahedron(pbase,mode)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    public bool Icosahedron(double[] center,double[] scale,POINTS mode) {
      int pbase=pts.Count;
      if(!pts.Icosahedron(center,scale)
          ||!fcs.Icosahedron(pbase,mode)) {
        pts.Count=pbase;
        return false;
      }
      return true;
    }
    
    struct RelaxPt {
      internal double x,y,z;
      internal int n;
    }
    public void Relax(double weight,double power,int iteration) {
      RelaxPt[] rp=new RelaxPt[pts.Count];
      if(iteration<1) iteration=1;
      double[] rd3=d3.V();
      double rd;
      power--;
      while(iteration-->0) {
        for(int f=0;f<fcs.N;f++) {
          int i,j,n=fcs.f[f++];
          for(j=fcs.f[f+n-1];n>0;n--) {
            i=fcs.f[f++];
            d3.sub(rd3,0,pts.p,3*i,pts.p,3*j);
            rd=d3.radius(rd3);
            rd=rd<1e-20||power==0?1:Math.Pow(rd,power);
            rp[j].x+=rd*rd3[0];rp[i].x-=rd*rd3[0];
            rp[j].y+=rd*rd3[1];rp[i].y-=rd*rd3[1];
            rp[j].z+=rd*rd3[2];rp[i].z-=rd*rd3[2];
            rp[j].n++;rp[i].n++;
            j=i;
          }
        }
        for(int i=0;i<pts.Count;i++) {
          if(rp[i].n>0) {
            int n=rp[i].n;
            rd3[0]=rp[i].x/n;
            rd3[1]=rp[i].y/n;
            rd3[2]=rp[i].z/n;
            rd=d3.radius(rd3);
            rd=rd<1e-20||power==0?1:Math.Pow(rd,power);
            int i3=i*3;
            pts.p[i3++]+=weight*rd*rd3[0];
            pts.p[i3++]+=weight*rd*rd3[1];
            pts.p[i3++]+=weight*rd*rd3[2];
            rp[i].x=rp[i].y=rp[i].z=0;
            rp[i].n=0;
          }
        }
      }      
    }
    
    internal struct Edge {
      internal int from,to,middle;
    }
    
    internal class EdgeComparer:IComparer<Edge> {
      public int Compare(Edge a,Edge b) {
        int r=a.from-b.from;
        if(r==0) r=a.to-b.to;
        return r;
      }
    }
    
    public void Precise(bool faces) { // edge/faces division
      int e,e2,ee,en=faces?fcs.Edges():3*fcs.Triangles(),nf=0;
      // edge array
      Edge[] et=new Edge[en];
      e=0;
      for(int h=0;h<fcs.N;h+=fcs.A) {
        nf++;
        int n=fcs.f[h++];
        if(faces) {
          int a=fcs.f[h+n-1];
          for(int i=0;i<n;i++) {
            int c=a;
            a=fcs.f[h++];
            if(c<a) {et[e].from=c;et[e].to=a;} else {et[e].from=a;et[e].to=c;};
            e++;            
          }
        } else {
          int a=fcs.f[h++],c=fcs.f[h++];
          for(int i=2;i<n;i++) {
            int b=c;
            c=fcs.f[h++];
            if(a<b) {et[e].from=a;et[e].to=b;} else {et[e].from=b;et[e].to=a;};
            e++;
            if(b<c) {et[e].from=b;et[e].to=c;} else {et[e].from=c;et[e].to=b;};
            e++;
            if(c<a) {et[e].from=c;et[e].to=a;} else {et[e].from=a;et[e].to=c;};
            e++;
          }  
        }        
      }
      // unique edges
      Array.Sort(et,new EdgeComparer());
      for(e2=e=0,ee=et.Length;e<ee;e2++) {
        if(e2<e) et[e2]=et[e];
        for(e++;e<ee&&et[e].from==et[e2].from&&et[e].to==et[e2].to;e++);        
      }
      // point index cache
      int[] ps=new int[pts.Count];
      int j=0;
      for(j=0;j<ps.Length;ps[j++]=-1);
      j=-1;
      for(e=0;e<e2;e++)
        if(et[e].from!=j) {
          j=et[e].from;
          ps[j]=e;
        }
      // add middle points
      int pi=pts.Count;
      pts.append_space(e2);
      for(e=0;e<e2;e++) {
        et[e].middle=pi++;
        int pf=3*et[e].from,pt=3*et[e].to,pm=3*et[e].middle;
        pts.p[pm++]=(pts.p[pf++]+pts.p[pt++])/2;
        pts.p[pm++]=(pts.p[pf++]+pts.p[pt++])/2;
        pts.p[pm++]=(pts.p[pf++]+pts.p[pt++])/2;
      }
      // replace big faces with smallers      
      en=faces?en*(1+4+fcs.A):en/3*4*(1+3+fcs.A);
      int[] fcs2=fcs.f;
      fcs.f=new int[en];
      int g=0,f2n=fcs.N;
      fcs.N=en;
      if(faces) {
        int b=pts.Count,pc=3*b;
        pts.append_space(nf);
        for(int h=0;h<f2n;h+=fcs.A,pc+=3,b++) {
          int f,n=fcs2[h++],ha=h+n;
          d3.copy(pts.p,pc,d3.V0,0);
          int a=fcs2[ha-1],d=fcs2[ha-2];
          for(int i=0;i<n;i++) {
            int c=d;
            d=a;a=fcs2[h++];
            if(a<d) {e=ps[a];f=d;} else {e=ps[d];f=a;}
            while(et[e].to!=f) e++;
            int ad=et[e].middle;
            if(c<d) {e=ps[c];f=d;} else {e=ps[d];f=c;}
            while(et[e].to!=f) e++;
            int cd=et[e].middle;            
            
            fcs.f[g++]=4;fcs.f[g++]=ad;fcs.f[g++]=b;fcs.f[g++]=cd;fcs.f[g++]=d;
            for(j=0;j<fcs.A;j++) fcs.f[g++]=fcs2[ha+j];

            d3.add(pts.p,pc,pts.p,pc,pts.p,3*a);            
          }
          d3.mul_d(pts.p,pc,pts.p,pc,1.0/n);
        }
      } else {
        for(int h=0;h<f2n;h+=fcs.A) {
          int f,n=fcs2[h++],ha=h+n;
          int a=fcs2[h++];
          int c=fcs2[h++];
          for(int i=2;i<n;i++) {
            int b=c;
            c=fcs2[h++];
            if(a<b) {e=ps[a];f=b;} else {e=ps[b];f=a;}
            while(et[e].to!=f) e++;
            int ab=et[e].middle;
            if(b<c) {e=ps[b];f=c;} else {e=ps[c];f=b;}
            while(et[e].to!=f) e++;
            int bc=et[e].middle;
            if(c<a) {e=ps[c];f=a;} else {e=ps[a];f=c;}
            while(et[e].to!=f) e++;
            int ca=et[e].middle;
          
            fcs.f[g++]=3;fcs.f[g++]=a;fcs.f[g++]=ab;fcs.f[g++]=ca;
            for(j=0;j<fcs.A;j++) fcs.f[g++]=fcs2[ha+j];
            fcs.f[g++]=3;fcs.f[g++]=ab;fcs.f[g++]=bc;fcs.f[g++]=ca;
            for(j=0;j<fcs.A;j++) fcs.f[g++]=fcs2[ha+j];
            fcs.f[g++]=3;fcs.f[g++]=ab;fcs.f[g++]=b;fcs.f[g++]=bc;
            for(j=0;j<fcs.A;j++) fcs.f[g++]=fcs2[ha+j];
            fcs.f[g++]=3;fcs.f[g++]=bc;fcs.f[g++]=c;fcs.f[g++]=ca;
            for(j=0;j<fcs.A;j++) fcs.f[g++]=fcs2[ha+j];
          }
        }  
      }
    }
    
    
    public void glDraw(double[] colors) {
      opengl.glDisableClientState(GLEnum.GL_NORMAL_ARRAY);
      opengl.glDisableClientState(GLEnum.GL_COLOR_ARRAY);
      opengl.glEnableClientState(GLEnum.GL_VERTEX_ARRAY);
      GCHandle gch=pts.Handle();
      opengl.glVertexPointer(3,GLEnum.GL_DOUBLE,0,gch.AddrOfPinnedObject());
      fcs.glDraw(colors);
      gch.Free();   
    }         
    
    public static int Phong(int ambient,double i01,int diffuse,double j01,int specular,double shine,int light) {
      double sf1=Math.Pow(j01,shine),x;
      x=((ambient&255)*255+(i01*(diffuse&255)+sf1*(specular&255))*(light&255))/255.0;
      byte r=x<255?(byte)x:(byte)255;
      x=(((ambient>>8)&255)*255+(i01*((diffuse>>8)&255)+sf1*((specular>>8)&255))*((light>>8)&255))/255.0;
      byte g=x<255?(byte)x:(byte)255;
      x=(((ambient>>16)&255)*255+(i01*((diffuse>>16)&255)+sf1*((specular>>16)&255))*((light>>16)&255))/255.0;
      byte b=x<255?(byte)x:(byte)255;
      return r|(g<<8)|(b<<16);
    }
    
    public void ColorizePhong(int ambient,int diffuse,int specular,double shine,int light,double[] light_vec) {
      double[] d1=new double[3],d2=new double[3],x=new double[3];
      for(int h=0;h<fcs.N;h+=1+fcs.f[h]+fcs.A) {
        d3.sub(d1,0,pts.p,3*fcs.f[h+2],pts.p,3*fcs.f[h+1]);
        d3.sub(d2,0,pts.p,3*fcs.f[h+3],pts.p,3*fcs.f[h+1]);
        d3.cross(x,d1,d2);
        double f=1-d3.angle(x,light_vec)/Math.PI;
        fcs.f[h+fcs.f[h]+1]=Phong(ambient,f,diffuse,f,specular,shine,light);
      }  
    }
    
    public void ColorizeNormalRGB(double[] rota) { 
      double[] normal=new double[3];
      for(int h=0;h<fcs.N;h+=1+fcs.f[h]+fcs.A) {
        FaceNormal(h,normal);
        d3.div_d33(normal,normal,rota);
        d3.mul_d(normal,normal,-1);
        d3.mul_d(normal,d3.add_d(normal,normal,1),0.5);
        fcs.f[h+fcs.f[h]+1]=faces.RGB2int(normal,0);
      }    
    }
    
    public void ColorizeNormalRadial(double[] rota,int color) {
      double[] normal=new double[3];
      for(int h=0;h<fcs.N;h+=1+fcs.f[h]+fcs.A) {
        FaceNormal(h,normal);                
        d3.div_d33(normal,normal,rota);
        double d=Math.Atan2(normal[0],normal[2]);
        d=Math.Abs(d)/Math.PI;
        fcs.f[h+fcs.f[h]+1]=faces.RGBd(color,d);
      }
    }
    
    // cut plane support
    internal struct inter {
      internal int i,o; // point inside,point outside
      internal int idx; // index of intersection point
      
      internal inter(int i,int o,int idx) {
        this.i=i;this.o=o;this.idx=idx;
      }
    }; // intersections

    internal class intersections {
      internal mesh m;
      internal double a;
      internal double[] normal=new double[3]; 
      internal int idx; // current idx for point
      internal List<inter> inter=new List<inter>(); // table of intersections      
      
      public intersections(mesh m,double[] normal,double a) {
        this.m=m;idx=m.pts.Count;
        d3.copy(this.normal,normal);
        this.a=a;
      }
      
      public int Point(int i,int o) {
        for(int h=0;h<inter.Count;h++)
          if(inter[h].i==i&&inter[h].o==o)
            return inter[h].idx;
        inter.Add(new inter(i,o,idx++));    
        return idx-1;
      }
      
      public void Points() {
        double[] p=m.pts.p,r3=new double[3];
        for(int h=0;h<inter.Count;h++) {
          int p1=inter[h].i*3,p2=inter[h].o*3;
          double f1=p[p1]*normal[0]+p[p1+1]*normal[1]+p[p1+2]*normal[2]+a;
          double f2=p[p2]*normal[0]+p[p2+1]*normal[1]+p[p2+2]*normal[2]+a;
          double w=f1/(f1-f2);
          d3.linear_interpol(r3,0,w,p,p1,p,p2);
          m.pts.Add(r3);          
        }
      }
    };

    public void CutPlane(double[] normal,double a) {
      faces nfcs=new faces(32);
      intersections ins=new intersections(this,normal,a);
      double[] p=pts.p;
      int i,i2,n,n2,pi,g,g2;
      for(int h=0;h<fcs.N;h+=fcs.f[h-1]+fcs.A) {
        n=fcs.f[h++];
        n2=0;
        for(i=0;i<n;i++) {
          pi=3*fcs.f[h+i];
          if(normal[0]*p[pi]+normal[1]*p[pi+1]+normal[2]*p[pi+2]+a>=0) n2++;          
        }
        if(n2==n) goto copy;
        if(n2==0) goto skip;
        i2=fcs.f[h+n-1];
        pi=3*i2;
        bool pf2=normal[0]*p[pi]+normal[1]*p[pi+1]+normal[2]*p[pi+2]+a>=0;
        nfcs.append_space(nfcs.N+1+(n*3/2+1)+nfcs.A,true);
        // table_realloc??
        g2=g=nfcs.N;
        g++;
        for(i=0;i<n;i++) {
          int i1=fcs.f[h+i];
          pi=3*i1;
          bool pf1=normal[0]*p[pi]+normal[1]*p[pi+1]+normal[2]*p[pi+2]+a>=0;
          if(pf1) {
            if(!pf2) nfcs.f[g++]=ins.Point(i1,i2);
            nfcs.f[g++]=i1;
          } else if(pf2) {
            nfcs.f[g++]=ins.Point(i2,i1);
          }
          i2=i1;
          pf2=pf1;
        }
        nfcs.f[g2]=g-g2-1;
        for(i=0;i<fcs.A;i++)
          nfcs.f[g++]=fcs.f[h+i+n];
        nfcs.N=g;    
/*
   // cut some parts of polygon
   i2=h[n-1];
   p=(double*)(pb+pa*i2);
   pf2=normal[0]*p[0]+normal[1]*p[1]+normal[2]*p[2]+a>=0;
   table_realloc((table*)&fcs,fcs.n+1+(n*3/2+1)+fa);
   g2=g=(int*)fcs.r+fcs.n;
   g++;//count
   for(i=0;i<n;i++) {
     i1=h[i];
     p=(double*)(pb+pa*i1);
     pf1=normal[0]*p[0]+normal[1]*p[1]+normal[2]*p[2]+a>=0;
     if(pf1) {
       if(!pf2) *g++=IntersectionsPoint(ins,i1,i2);
       *g++=i1;
     } else if(pf2) {
       *g++=IntersectionsPoint(ins,i2,i1);
     }
     i2=i1;
     pf2=pf1;
   }
   *g2=g-g2-1;
   for(i=0;i<fa;i++)
     *g++=h[i+n];
   fcs.n+=1+*g2+fa;
*/    
        continue;
       copy:
        nfcs.append(fcs.f,h-1,1+n+fcs.A);
       skip:;
      }
      fcs.Clear();
      fcs.Append(nfcs,0);
      n2=pts.Count;
      ins.Points();
      p=pts.p;
      n=pts.Count;
      g=0;
      int[] ra=new int[n];
      for(i2=i=0;i<n2;i++) {
        pi=3*i;
        if(normal[0]*p[pi]+normal[1]*p[pi+1]+normal[2]*p[pi+2]+a>=0) {
          p[3*i2]=p[3*i];p[3*i2+1]=p[3*i+1];p[3*i2+2]=p[3*i+2];          
          ra[g]=i2++;
        } else
          ra[g]=-1;
        g++;
      }
      Array.Copy(p,3*i,p,3*i2,(n-n2)*3);
      while(i<n) {
        ra[g++]=i2++;
        i++;
      }
      pts.Count=i2;
      for(int h=0;h<fcs.N;h+=fcs.A) 
        for(i=fcs.f[h++];i>0;i--) {
          fcs.f[h]=ra[fcs.f[h]];
          h++;
        }  
    }
  }  
}
